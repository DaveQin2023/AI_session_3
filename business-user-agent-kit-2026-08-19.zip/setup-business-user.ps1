# setup-business-user.ps1 - ONE-COMMAND deployment of the Business-User Agent Kit.
#
# Turns any product repo + any business user's machine into a fully guarded
# agentic workspace. Everything the deployment doc's manual steps did by hand
# (T9/T11) is automated here, driven by one JSON config file.
#
# Usage (developer prepares deploy.config.json, business user runs one line):
#   powershell -NoProfile -ExecutionPolicy Bypass -File setup-business-user.ps1 `
#     -ConfigPath deploy.config.json -TargetDir C:\work\my-product
#
# deploy.config.json schema (only productRepoUrl + intentRepoUrl required):
# {
#   "productRepoUrl":  "https://github.com/org/product.git",   // she has READ
#   "intentRepoUrl":   "https://github.com/org/product-intent.git", // she has WRITE
#   "featureRepoUrl":  "https://github.com/org/product-feature.git",// optional, WRITE
#   "prRepo":          "org/product-feature",                   // optional, for draft PRs
#   "createDraftPR":   true,                                     // optional
#   "dailyPublish":    true,                                     // optional
#   "userName":        "Business User",                          // git identity for HER commits
#   "userEmail":       "business.user@example.com",
#   "referenceRepos":  [ { "name": "rules",    "url": "https://github.com/org/rules.git" },
#                        { "name": "database", "url": "https://github.com/org/database.git" } ]
# }
#
# What it does (each step prints PASS/FAIL; script exits non-zero on hard failure):
#   1. Clone the product repo into TargetDir (Read role permits pull).
#   2. Copy the kit (.github/, scripts/, .vscode/) from this script's folder -
#      NEVER committed to the product repo (governing constraint, 2026-08-11).
#   2b. Install the Live Preview extension (ms-vscode.live-server) via the
#      code CLI - warns (does not fail) if the CLI is unavailable.
#   3. Append kit paths to .git/info/exclude (gitignore manual: repo-specific,
#      unshared patterns belong there; tracked files unaffected).
#   4. Set git identity in the clone (T10-proven precondition for publishing).
#   5. Initialize docs/agent/ as a NESTED git repo -> intentRepoUrl (Option A,
#      T7/T11-proven). Pulls existing intent history if the repo is non-empty.
#   6. Write scripts/handoff.config.json from the feature-repo fields (skipped
#      if featureRepoUrl absent -> publishing stays disabled, fail-soft).
#   7. Write scripts/repo-list.txt from referenceRepos + productRepoUrl, run
#      scan-repos.ps1 (catalog) and fetch-repo-context.ps1 per reference repo.
#   8. Verify: git status must show NO kit files; default branch detected.
#
# PS 5.1 rules honoured throughout: BOM-less UTF8 via WriteAllText, no '>'
# redirects, $LASTEXITCODE (not stderr) decides git success.
param(
    [Parameter(Mandatory = $true)][string]$ConfigPath,
    [Parameter(Mandatory = $true)][string]$TargetDir
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$kitRoot = $PSScriptRoot
$utf8 = New-Object System.Text.UTF8Encoding($false)
$failed = $false

function Step([string]$Name, [scriptblock]$Body) {
    Write-Host "== $Name" -ForegroundColor Cyan
    try { & $Body; Write-Host "   PASS" -ForegroundColor Green }
    catch { Write-Host "   FAIL: $_" -ForegroundColor Red; $script:failed = $true; throw }
}
function Invoke-GitChecked([string[]]$GitArgs, [string]$What) {
    $eap = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    & git @GitArgs 2>&1 | Out-Null
    $code = $LASTEXITCODE; $ErrorActionPreference = $eap
    if ($code -ne 0) { throw "git failed ($What): git $($GitArgs -join ' ') [exit $code]" }
}

$cfg = Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $cfg.productRepoUrl) { Write-Error "deploy.config.json: productRepoUrl is required"; exit 1 }
if (-not $cfg.intentRepoUrl)  { Write-Error "deploy.config.json: intentRepoUrl is required"; exit 1 }
$userName  = if ($cfg.userName)  { $cfg.userName }  else { "Business User" }
$userEmail = if ($cfg.userEmail) { $cfg.userEmail } else { "business.user@example.com" }

Step "1. Clone product repo (Read role: pull permitted)" {
    if (Test-Path (Join-Path $TargetDir ".git")) { throw "$TargetDir is already a git repo - refusing to overwrite" }
    Invoke-GitChecked @("clone", $cfg.productRepoUrl, $TargetDir) "clone product"
}

Step "2. Copy kit (never committed to product repo)" {
    foreach ($d in @(".github", "scripts", ".vscode")) {
        $src = Join-Path $kitRoot $d
        if (Test-Path $src) { Copy-Item $src (Join-Path $TargetDir $d) -Recurse -Force }
        else { Write-Warning "kit folder missing: $src (skipped)" }
    }
}

Step "2b. Live Preview extension (auto-refreshing in-editor page view)" {
    $eap = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    & code --install-extension ms-vscode.live-server 2>&1 | Out-Null
    $code = $LASTEXITCODE; $ErrorActionPreference = $eap
    if ($code -ne 0) { Write-Warning "could not install ms-vscode.live-server (code CLI unavailable?) - VS Code will still recommend it via .vscode/extensions.json" }
}

Step "3. Local-only excludes (.git/info/exclude)" {
    $lines = "`n# business-agent kit (deployed by copy, local to this clone)`n.github/`nscripts/`n.vscode/`ndocs/agent/`nhandoff/`nexternal/`n"
    $excl = Join-Path $TargetDir ".git\info\exclude"
    [System.IO.File]::AppendAllText($excl, $lines, $utf8)
}

Step "4. Git identity in her clone (publish precondition, T10)" {
    Invoke-GitChecked @("-C", $TargetDir, "config", "user.name", $userName) "set user.name"
    Invoke-GitChecked @("-C", $TargetDir, "config", "user.email", $userEmail) "set user.email"
}

Step "5. Nested intent repo -> $($cfg.intentRepoUrl)" {
    $agentDir = Join-Path $TargetDir "docs\agent"
    New-Item -ItemType Directory -Force -Path (Join-Path $agentDir "sessions\_capture"), (Join-Path $agentDir "designs") | Out-Null
    Invoke-GitChecked @("-C", $agentDir, "init", "-b", "main") "init intent repo"
    Invoke-GitChecked @("-C", $agentDir, "config", "user.name", $userName) "intent identity name"
    Invoke-GitChecked @("-C", $agentDir, "config", "user.email", $userEmail) "intent identity email"
    Invoke-GitChecked @("-C", $agentDir, "remote", "add", "origin", $cfg.intentRepoUrl) "intent remote"
    # Pull existing history if the intent repo is non-empty; empty repo -> fetch finds no head, that is fine.
    $eap = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    & git -C $agentDir fetch origin main 2>&1 | Out-Null
    if ($LASTEXITCODE -eq 0) {
        & git -C $agentDir reset --hard origin/main 2>&1 | Out-Null
        & git -C $agentDir branch --set-upstream-to=origin/main main 2>&1 | Out-Null
        Write-Host "   (pulled existing intent history)"
    } else {
        # brand-new intent repo: seed the active brief from the kit template if present
        $brief = Join-Path $kitRoot "docs\agent\active-brief.md"
        if (Test-Path $brief) { Copy-Item $brief $agentDir }
        & git -C $agentDir add -A 2>&1 | Out-Null
        & git -C $agentDir commit -m "intent repo init (setup-business-user.ps1)" 2>&1 | Out-Null
        & git -C $agentDir push -u origin main 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { Write-Warning "intent push failed (credentials? empty ok) - commits are local; first sync will retry" }
    }
    $ErrorActionPreference = $eap
}

Step "6. Feature-repo publishing config (optional)" {
    if ($cfg.featureRepoUrl) {
        $hc = [ordered]@{ featureRepoUrl = $cfg.featureRepoUrl }
        if ($null -ne $cfg.createDraftPR) { $hc.createDraftPR = [bool]$cfg.createDraftPR }
        if ($cfg.prRepo)                  { $hc.prRepo = $cfg.prRepo }
        if ($null -ne $cfg.dailyPublish)  { $hc.dailyPublish = [bool]$cfg.dailyPublish }
        $json = ($hc | ConvertTo-Json)
        [System.IO.File]::WriteAllText((Join-Path $TargetDir "scripts\handoff.config.json"), $json, $utf8)
    } else { Write-Host "   (no featureRepoUrl - publishing disabled, handoff stays zip-only)" }
}

Step "7. Reference repos: config file + catalog + local clones" {
    $listLines = "$(($cfg.productRepoUrl -split '/')[-1] -replace '\.git$',''),$($cfg.productRepoUrl)`n"
    if ($cfg.referenceRepos) {
        foreach ($r in $cfg.referenceRepos) { $listLines += "$($r.name),$($r.url)`n" }
    }
    [System.IO.File]::WriteAllText((Join-Path $TargetDir "scripts\repo-list.txt"), $listLines, $utf8)
    Push-Location $TargetDir
    try {
        & powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\scan-repos.ps1" -RepoListFile "scripts\repo-list.txt"
        if ($LASTEXITCODE -ne 0) { Write-Warning "catalog build failed - intent agent will ask for a re-run" }
        if ($cfg.referenceRepos) {
            foreach ($r in $cfg.referenceRepos) {
                & powershell -NoProfile -ExecutionPolicy Bypass -File "scripts\fetch-repo-context.ps1" -Name $r.name -Url $r.url
                if ($LASTEXITCODE -ne 0) { Write-Warning "reference fetch failed for $($r.name)" }
            }
        }
    } finally { Pop-Location }
}

Step "8. Verify guardrails" {
    $status = git -C $TargetDir status --porcelain
    if ($status) { throw "product repo sees unexpected files after deploy:`n$status" }
    $symref = git -C $TargetDir ls-remote --symref origin HEAD 2>$null | Select-String "^ref: refs/heads/(\S+)"
    if (-not $symref) { throw "cannot detect product default branch" }
    Write-Host "   product default branch: $($symref.Matches[0].Groups[1].Value); git status clean"
}

Write-Host ""
Write-Host "DEPLOY COMPLETE. Open $TargetDir as the VS Code workspace root." -ForegroundColor Green
Write-Host "Optional one-time: scripts\capture-history.ps1 (backfill pre-hook prompt history)."
exit 0
