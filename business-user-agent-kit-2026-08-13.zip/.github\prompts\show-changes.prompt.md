---
description: Show and test the current code changes immediately — open the page, run the smoke test, walk her through visual review
---

You run the SHOW-AND-VERIFY step. The Business User (a non-developer) wants to see and validate the current uncommitted code changes right now. Never skip this; never assume she has already seen the page.

## Non-negotiable working rules — apply to every step below

1. Criticize yourself: before presenting any information, re-check it for correctness and accuracy, and state anything you are unsure of.
2. You need proof for all the information you provide: every claim must cite the exact file and quote the line(s) that support it.
3. Go through the code thoroughly — read the actual files in this workspace; never answer from memory, prior sessions, or general knowledge of "typical" codebases.
4. Do not make up things. Be very serious and sincere about what you are doing: if something cannot be verified, say "I could not verify this" instead of guessing.

## Steps — in this exact order

1. Make sure the page is visible beside the chat: if the Live Preview tab is open it has already refreshed on save; otherwise open it (command `Live Preview: Show Preview (Internal Browser)` on the changed page, Simple Browser fallback, or tell her: right-click the HTML file → "Show Preview").
2. Run in the terminal: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/show-changes.ps1`
   - This prints exactly which files changed, smoke-tests every local link/script/style reference in the changed HTML files, and also opens the changed page(s) in her default browser.
3. Report the script output honestly:
   - `RESULT: PASS` → tell her the page is open beside the chat (and in her browser) and that the automated reference check passed (quote the "references checked: N, missing: 0" line).
   - `RESULT: FAIL` → do NOT ask her to review a broken page. Report which reference is missing (quote the FAIL line), fix it, and re-run the script. Only proceed when it passes.
4. Tell her what to look for: open the most recent design document in `docs/agent/designs/` and quote its "How she will verify" section verbatim. If no design document exists for this change, say so and describe the change from the actual diff instead — never invent a verify checklist.
5. Show her the size and shape of the change in plain language from the `git diff --stat` output the script printed (e.g. "2 files, 3 new lines — the banner styling and the banner text").
6. Remind her of her three options, in her words:
   - **Looks right** → next steps are `/document-changes` then `scripts/handoff.ps1` when the whole session's work is done.
   - **Not quite** → she just types what is different in plain language; the change is revised and this show-and-verify step runs again automatically.
   - **Undo it** → nothing is committed; on her explicit request the change can be removed entirely.

## Never

- Never run `git commit`, `git push`, `git merge`, or `git rebase` on the product repository.
- Never edit code in this prompt's flow except to fix a FAIL from the smoke test in step 2.
- Never tell her the page "should look right" without the script having passed — the pass/fail comes from the script output, not from your reading of the code.
