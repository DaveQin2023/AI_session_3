# capture-history.ps1 - RETROACTIVE capture: mine VS Code's on-disk Copilot chat
# transcripts for past user prompts in THIS workspace and backfill ideas.jsonl.
#
# WHY THIS EXISTS: the UserPromptSubmit hook only captures prompts from the moment
# it is installed. Anything she did in Copilot BEFORE that lives only in VS Code's
# internal storage. This script recovers it.
#
# DATA SOURCE (empirically verified 2026-08-10 on this machine, VS Code stable, Windows):
#   %APPDATA%\Code\User\workspaceStorage\<hash>\workspace.json
#       -> maps hash folder to workspace folder URI (e.g. file:///c%3A/Users/...)
#   %APPDATA%\Code\User\workspaceStorage\<hash>\GitHub.copilot-chat\transcripts\*.jsonl
#       -> one JSONL per chat session; entries have {type, data, id, timestamp, parentId};
#          user prompts are type == "user.message" with data.content and ISO timestamp.
#
# HONEST LIMITS - read before trusting output:
#   1. This format is INTERNAL and UNDOCUMENTED. It was reverse-engineered from disk,
#      not from an API contract. A VS Code / Copilot extension update may change or
#      remove it. Script fails soft (skips unparseable lines) for that reason.
#   2. Only locally persisted history is recoverable. Cleared chats, other machines,
#      other VS Code profiles ("Code - Insiders", portable mode) are not covered.
#   3. Only data.content of user.message entries is extracted. Transcripts also hold
#      assistant output and tool results - deliberately NOT extracted, to keep
#      handoff packages small and free of noise.
#
# Usage:
#   .\scripts\capture-history.ps1                      # workspace = git top-level of cwd
#   .\scripts\capture-history.ps1 -WorkspaceFolder C:\path\to\repo -OutRoot C:\tmp\out

param(
    [string]$WorkspaceFolder = "",
    [string]$OutRoot = "docs/agent/sessions/_capture"
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# --- 1. Resolve the workspace folder we are mining history FOR ---
if (-not $WorkspaceFolder) {
    $WorkspaceFolder = (git rev-parse --show-toplevel 2>$null)
    if (-not $WorkspaceFolder) { $WorkspaceFolder = (Get-Location).Path }
}
$WorkspaceFolder = (Resolve-Path $WorkspaceFolder).Path.TrimEnd('\')
Write-Host "Mining Copilot history for workspace: $WorkspaceFolder"

# --- 2. Find matching workspaceStorage folder(s) via workspace.json ---
$storageRoot = Join-Path $env:APPDATA "Code\User\workspaceStorage"
if (-not (Test-Path $storageRoot)) { Write-Host "No workspaceStorage found at $storageRoot"; exit 0 }

$matches = @()
foreach ($wsJson in Get-ChildItem $storageRoot -Directory | ForEach-Object { Join-Path $_.FullName "workspace.json" } | Where-Object { Test-Path $_ }) {
    try {
        $meta = Get-Content $wsJson -Encoding UTF8 -Raw | ConvertFrom-Json
        $uri = if ($meta.folder) { $meta.folder } elseif ($meta.workspace) { $meta.workspace } else { $null }
        if (-not $uri) { continue }
        # file:///c%3A/Users/... -> c:\Users\...
        $path = [System.Uri]::UnescapeDataString(($uri -replace '^file:///', '')) -replace '/', '\'
        if ($path.TrimEnd('\') -ieq $WorkspaceFolder) { $matches += (Split-Path $wsJson -Parent) }
    } catch { continue }  # unreadable workspace.json -> skip
}
if ($matches.Count -eq 0) { Write-Host "No VS Code storage folder maps to this workspace. Nothing to recover."; exit 0 }
Write-Host "Matched storage folder(s): $($matches -join '; ')"

# --- 3. Build dedupe set from existing ideas.jsonl (hook-captured or prior runs) ---
$seen = @{}
if (Test-Path $OutRoot) {
    foreach ($f in Get-ChildItem $OutRoot -Recurse -Filter ideas.jsonl) {
        foreach ($line in Get-Content $f.FullName -Encoding UTF8) {
            try { $o = $line | ConvertFrom-Json; $seen["$($o.ts)|$($o.prompt)"] = $true } catch { }
        }
    }
}

# --- 4. Mine transcripts: extract user.message entries, backfill by prompt date ---
$recovered = 0; $skipped = 0
foreach ($storage in $matches) {
    $tDir = Join-Path $storage "GitHub.copilot-chat\transcripts"
    if (-not (Test-Path $tDir)) { continue }
    foreach ($tf in Get-ChildItem $tDir -Filter *.jsonl) {
        $sessionId = [IO.Path]::GetFileNameWithoutExtension($tf.Name)
        foreach ($line in Get-Content $tf.FullName -Encoding UTF8) {
            try { $e = $line | ConvertFrom-Json } catch { continue }   # defensive: format may change
            if ($e.type -ne 'user.message' -or -not $e.data.content) { continue }
            $key = "$($e.timestamp)|$($e.data.content)"
            if ($seen.ContainsKey($key)) { $skipped++; continue }
            $seen[$key] = $true
            $day = try { ([datetime]$e.timestamp).ToString('yyyy-MM-dd') } catch { Get-Date -Format yyyy-MM-dd }
            $dir = Join-Path $OutRoot $day
            New-Item -ItemType Directory -Force -Path $dir | Out-Null
            $rec = @{ ts = $e.timestamp; session = $sessionId; prompt = $e.data.content; source = 'retro-transcript' } | ConvertTo-Json -Compress
            Add-Content -Path (Join-Path $dir "ideas.jsonl") -Value $rec -Encoding UTF8
            $recovered++
        }
    }
}
Write-Host "Recovered $recovered prompt(s); skipped $skipped duplicate(s). Output under: $OutRoot"
