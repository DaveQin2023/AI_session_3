# Project instructions

This repository is a UI prototyping workspace for a Business User (non-developer) in insurance/annuity marketing. Her design ideas must drive every code change.

## Where things live

- UI code: `src/ui/` — plain HTML/CSS prototypes.
- Business intake forms: `docs/business/<formId>.md` — the business context for every change.
- Current work brief: `docs/agent/active-brief.md` — the active form ID, her goal, and accepted decisions.

## Before making any UI change (reflect-then-edit)

1. Read `docs/agent/active-brief.md` and the intake form it references, because the "why" of every change lives there, not in the code.
2. Restate the user's idea in one or two plain, non-technical sentences and list the files you plan to touch. Wait for her confirmation before editing, because she is not a developer and this restatement is her only chance to catch a misunderstanding before code changes.
3. If her request conflicts with the active brief or intake form, say so and ask — do not silently pick one.

## After making a UI change — SHOW her, never just tell her

She verifies visually, not by reading code. The workspace uses the **Live Preview** extension (`ms-vscode.live-server`): once its preview tab is open, it auto-refreshes on every file save, so she sees each change instantly with zero clicks. Immediately after ANY edit to `src/ui/**`, in this order and without being asked:

1. **Make sure the page is visible beside the chat.** If the Live Preview tab is already open, saving your edit has already refreshed it — tell her to look at it. If it is not open, open it now: run the VS Code command `Live Preview: Show Preview (Internal Browser)` on the changed HTML file (tool permitting), or fall back to the Simple Browser tool (`openSimpleBrowser`) with `http://127.0.0.1:3000/src/ui/index.html` (Live Preview's server) or the page's `file:///` URL. As a last resort tell her: right-click `src/ui/index.html` → "Show Preview" — one click, permanent.
2. **Run the smoke test**: `powershell -NoProfile -ExecutionPolicy Bypass -File scripts/show-changes.ps1` — it verifies every local link/style/script reference in the changed HTML exists and also opens the page in her default browser as a fallback. If it prints `RESULT: FAIL`, fix the problem and repeat from step 1 before asking her to look.
3. Then tell her in plain language what changed and where on the page to look.

Never tell her to run `npm run dev` — this project has no build step (the UI convention forbids one). Never end your turn after a UI edit without the page being visible to her.

## Never

- Never run `git commit`, `git push`, `git merge`, or `git rebase` — this workspace hands changes off via patches, and the repository role does not permit pushing.
- Never invent business rationale. If the reason for a change is not in the brief, the form, or her words, ask her.
