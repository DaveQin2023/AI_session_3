@echo off
rem install.cmd - double-click installer for the Business-User Agent Kit.
rem Requires deploy.config.json (rename deploy.config.template.json and fill it in)
rem to sit next to this file.
setlocal
if not exist "%~dp0deploy.config.json" (
  echo ERROR: deploy.config.json not found next to install.cmd.
  echo Rename deploy.config.template.json to deploy.config.json and fill in your URLs first.
  pause
  exit /b 1
)
set /p TARGET="Folder to create for the business user (e.g. C:\work\my-product): "
if "%TARGET%"=="" (
  echo ERROR: no folder given.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-business-user.ps1" -ConfigPath "%~dp0deploy.config.json" -TargetDir "%TARGET%"
echo.
echo Setup exit code: %ERRORLEVEL%  (0 = success)
pause
