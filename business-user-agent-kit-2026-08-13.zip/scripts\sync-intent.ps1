# sync-intent.ps1 - commit + push her intent/design history to the dedicated INTENT repo
#
# DESIGN (Option A, decided 2026-08-10): docs/agent/ is its own nested git repository
# whose origin is the intent repo, where she has WRITE access. The PRODUCT repo
# (where she has READ) ignores docs/agent/ entirely. GitHub roles are per-repository
# (docs: "You can customize access to each repository in your organization by
# assigning granular roles"), so this does not touch the Layer 0 guardrail.
#
# CONFIDENTIALITY: session-diff.patch inside this repo contains product source code
# as diff text. The intent repo MUST have the same visibility/access controls as the
# product repo.
#
# Fail-soft: never blocks her session. Offline push failures leave local commits
# intact; the next sync pushes them.
param([string]$Message = "intent sync $(Get-Date -Format s)")
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$intentDir = "docs/agent"
try {
    if (-not (Test-Path "$intentDir/.git")) {
        Write-Warning "No intent repo at $intentDir (expected nested git repo). Run one-time setup first."
        exit 1
    }
    git -C $intentDir add -A
    $pending = git -C $intentDir status --porcelain
    if ($pending) {
        git -C $intentDir commit -m $Message | Out-Null
        Write-Host "Intent commit created: $Message"
    } else {
        Write-Host "No new intent changes to commit."
    }
    # Push whatever is unpushed (covers earlier offline failures too).
    # NOTE (proven in T7 first run): git push reports SUCCESS on stderr; under
    # ErrorActionPreference=Stop, '2>&1' converts that into a terminating error.
    # Relax the preference around the native call and trust $LASTEXITCODE only.
    $ErrorActionPreference = "Continue"
    git -C $intentDir push origin main 2>&1 | Out-Null
    $pushExit = $LASTEXITCODE
    $ErrorActionPreference = "Stop"
    if ($pushExit -ne 0) {
        Write-Warning "Intent push failed (offline? credentials?). Commits are safe locally; next sync will push."
        exit 1
    }
    Write-Host "Intent repo synced to origin/main."
    exit 0
} catch {
    Write-Warning "Intent sync failed non-fatally: $_"
    exit 1
}
