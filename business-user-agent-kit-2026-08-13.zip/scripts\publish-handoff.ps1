# publish-handoff.ps1 - push the session's changes as a branch to the FEATURE repo
# (a repo where the business user has Write) and optionally open a draft PR there.
#
# WHY THIS SHAPE: she has Read-only on the product repo (Layer 0), so a branch/PR
# on the product repo itself is impossible for her. The feature repo receives:
#   - <default-branch>  : mirror of product origin/<default> (so PR diffs are clean)
#   - handoff/<session> : her changes committed on top of product origin/<default>
# Developers review the draft PR there, then apply/cherry-pick into the product repo.
#
# HARD CONSTRAINT PRESERVED: the branch is built in a TEMP WORKTREE checked out from
# origin/<default> (which contains no agent kit) plus the handoff patch (which contains
# no kit files - proven in T9: kit paths are invisible to git via .git/info/exclude).
# Her working tree is never touched.
#
# Config: scripts/handoff.config.json
#   { "featureRepoUrl": "<url-or-path>", "createDraftPR": false, "prRepo": "owner/feature-repo",
#     "dailyPublish": false }
# No config file -> exits 0 silently (fail-soft, so handoff.ps1 can always call this).
#
# -Daily mode (called by capture-session.ps1 Stop hook when config dailyPublish=true):
#   patch  = today's Stop-hook capture (docs/agent/sessions/_capture/<date>/session-diff.patch)
#   branch = daily/<date>, FORCE-pushed so each session end of the same day replaces it
#   no PR  = the draft PR remains the manual sign-off artifact (handoff.ps1)
#
# PowerShell 5.1 rules honoured: no '>' redirects for git output, $LASTEXITCODE (not
# stderr) decides success, explicit UTF8 everywhere.
param(
    [Parameter(Mandatory = $true)][string]$SessionName,
    [switch]$Daily
)
$ErrorActionPreference = "Continue"   # native git writes progress to stderr; exit codes decide

function Invoke-Git {
    param([string[]]$GitArgs, [string]$What)
    & git @GitArgs 2>&1 | ForEach-Object { Write-Host "  git: $_" }
    if ($LASTEXITCODE -ne 0) { throw "git failed ($What): git $($GitArgs -join ' ')" }
}

# 0. Config (absent = feature-repo publishing not set up; that is allowed)
$configPath = Join-Path $PSScriptRoot "handoff.config.json"
if (-not (Test-Path $configPath)) {
    Write-Host "publish-handoff: no scripts/handoff.config.json - skipping feature-repo publish."
    exit 0
}
$config = Get-Content $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $config.featureRepoUrl) { Write-Warning "handoff.config.json has no featureRepoUrl"; exit 1 }
if ($Daily -and -not $config.dailyPublish) {
    Write-Host "publish-handoff: dailyPublish not enabled in handoff.config.json - skipping daily publish."
    exit 0
}

# 1. The patch is the single source of truth for the branch content.
#    Normal mode: the patch produced by handoff.ps1. Daily mode: today's Stop-hook capture.
if ($Daily) {
    $patch = Join-Path (Get-Location) "docs/agent/sessions/_capture/$(Get-Date -Format yyyy-MM-dd)/session-diff.patch"
    if (-not (Test-Path $patch) -or (Get-Item $patch).Length -eq 0) {
        Write-Host "publish-handoff: no changes captured today - nothing to daily-publish."
        exit 0
    }
} else {
    $patch = Join-Path (Get-Location) "handoff/$SessionName-changes.patch"
    if (-not (Test-Path $patch)) { Write-Warning "No patch at $patch - run handoff.ps1 first."; exit 1 }
}

# 2. Detect the product repo's default branch from the remote itself
#    (lesson from T9: never hardcode 'main'; plain 'git init' repos default to 'master')
$symref = git ls-remote --symref origin HEAD 2>$null | Select-String "^ref: refs/heads/(\S+)"
if (-not $symref) { Write-Warning "Cannot detect default branch of origin."; exit 1 }
$defaultBranch = $symref.Matches[0].Groups[1].Value
if ($Daily) { $branch = "daily/$SessionName" } else { $branch = "handoff/$SessionName" }
Write-Host "publish-handoff: default branch '$defaultBranch', feature branch '$branch'"

Invoke-Git @("fetch", "origin") "fetch product origin"

# 3. Build the branch in a temp worktree so her working tree is untouched
$wt = Join-Path $env:TEMP ("handoff-wt-" + [guid]::NewGuid().ToString("N").Substring(0, 8))
git worktree remove --force $wt 2>$null | Out-Null
git branch -D $branch 2>$null | Out-Null
try {
    Invoke-Git @("worktree", "add", "-b", $branch, $wt, "origin/$defaultBranch") "create worktree"
    Invoke-Git @("-C", $wt, "apply", "--index", $patch) "apply handoff patch"

    # Commit message: title + session skeleton (if capture produced one today)
    $msgFile = Join-Path $env:TEMP "handoff-msg-$SessionName.txt"
    $skeleton = Get-ChildItem "docs/agent/sessions/_capture" -Recurse -Filter "session-skeleton.md" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime | Select-Object -Last 1
    $body = "handoff: $SessionName`n`nBuilt by publish-handoff.ps1 from $patch"
    if ($Daily) { $body = "daily WIP: $SessionName`n`nAutomatic end-of-session snapshot (Stop hook). NOT a review request - see the draft PR from handoff.ps1 for sign-off.`n`nBuilt from $patch" }
    if ($skeleton) { $body += "`n`n" + (Get-Content $skeleton.FullName -Raw -Encoding UTF8) }
    [System.IO.File]::WriteAllText($msgFile, $body, (New-Object System.Text.UTF8Encoding($false)))
    Invoke-Git @("-C", $wt, "commit", "-F", $msgFile) "commit handoff branch"

    # 4. Push: keep feature repo's default branch mirrored, then push the branch.
    #    Daily mode force-pushes: the daily branch is a WIP snapshot that each
    #    session end of the same day REPLACES (it is never a review base).
    Invoke-Git @("push", $config.featureRepoUrl, "refs/remotes/origin/${defaultBranch}:refs/heads/$defaultBranch") "mirror default branch to feature repo"
    if ($Daily) {
        Invoke-Git @("-C", $wt, "push", "--force", $config.featureRepoUrl, "HEAD:refs/heads/$branch") "force-push daily WIP branch"
    } else {
        Invoke-Git @("-C", $wt, "push", $config.featureRepoUrl, "HEAD:refs/heads/$branch") "push handoff branch"
    }
    Write-Host "publish-handoff: pushed '$branch' to $($config.featureRepoUrl)"

    # 5. Draft PR on the feature repo (needs gh + real GitHub; skipped/printed otherwise).
    #    NEVER in daily mode: the PR is the final sign-off artifact, created only by
    #    the manual handoff.ps1 run (her approval gate).
    if ($Daily) {
        Write-Host "publish-handoff: daily mode - no PR (sign-off PR comes from handoff.ps1)."
    } elseif ($config.createDraftPR -and $config.prRepo) {
        $gh = Get-Command gh -ErrorAction SilentlyContinue
        if ($gh) {
            & gh pr create -R $config.prRepo --draft --base $defaultBranch --head $branch `
                --title "Draft: handoff $SessionName" --body-file $msgFile
            if ($LASTEXITCODE -ne 0) { Write-Warning "gh pr create failed (exit $LASTEXITCODE) - branch is pushed; open the PR manually." }
        } else {
            Write-Warning "gh CLI not found - branch is pushed. Manual PR command:"
            Write-Host "  gh pr create -R $($config.prRepo) --draft --base $defaultBranch --head $branch --title `"Draft: handoff $SessionName`""
        }
    } else {
        Write-Host "publish-handoff: createDraftPR disabled - branch pushed, no PR requested."
    }
}
finally {
    git worktree remove --force $wt 2>$null | Out-Null
    git branch -D $branch 2>$null | Out-Null
}
exit 0
