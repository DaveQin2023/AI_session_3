# scan-repos.ps1 - build docs/agent/repo-catalog.md: what each company repo IS FOR.
# The intent agent reads this catalog to match her idea to a repo.
#
# Two sources:
#   -RepoListFile <file>  lines of "name,url" (works headlessly; T8-tested)
#   -Org <name>           uses GitHub CLI: `gh repo list <org> --json name,description,url`
#                         (documented: cli.github.com/manual/gh_repo_list - "List
#                         repositories owned by a user or organization".
#                         REQUIRES gh installed + authenticated. NOT tested in pilot.)
#
# For each repo: shallow-clone to temp, take README excerpt + package.json
# name/description. Mechanical extraction only - no AI in this script.
param(
    [string]$RepoListFile = "",
    [string]$Org = "",
    [string]$OutFile = "docs/agent/repo-catalog.md"
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$repos = @()
if ($RepoListFile) {
    foreach ($line in Get-Content $RepoListFile -Encoding UTF8 | Where-Object { $_ -match ',' }) {
        $parts = $line.Split(',', 2)
        $repos += @{ name = $parts[0].Trim(); url = $parts[1].Trim() }
    }
} elseif ($Org) {
    # UNTESTED PATH (needs real gh auth): documented fields name/description/url
    $json = gh repo list $Org --limit 200 --json name,description,url | ConvertFrom-Json
    foreach ($r in $json) { $repos += @{ name = $r.name; url = $r.url; desc = $r.description } }
} else {
    Write-Error "Provide -RepoListFile or -Org."; exit 1
}

$lines = @("# Company repo catalog", "", "Generated $(Get-Date -Format s) by scan-repos.ps1. Mechanical excerpts only.", "")
foreach ($r in $repos) {
    $tmp = Join-Path $env:TEMP ("scan-" + $r.name)
    if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
    $ErrorActionPreference = "Continue"   # git writes progress to stderr (T7 lesson)
    git clone -q --depth 1 $r.url $tmp 2>&1 | Out-Null
    $cloneExit = $LASTEXITCODE
    $ErrorActionPreference = "Stop"
    $lines += "## $($r.name)"
    $lines += "- url: $($r.url)"
    if ($r.desc) { $lines += "- gh description: $($r.desc)" }
    if ($cloneExit -ne 0) {
        $lines += "- STATUS: clone failed - catalog entry incomplete"; $lines += ""
        continue
    }
    $pkg = Join-Path $tmp "package.json"
    if (Test-Path $pkg) {
        try { $p = Get-Content $pkg -Raw -Encoding UTF8 | ConvertFrom-Json
              $lines += "- package: $($p.name) - $($p.description)" } catch { }
    }
    $readme = Join-Path $tmp "README.md"
    if (Test-Path $readme) {
        $lines += "- README excerpt:"
        $lines += '  ```'
        Get-Content $readme -Encoding UTF8 -TotalCount 15 | ForEach-Object { $lines += "  $_" }
        $lines += '  ```'
    } else { $lines += "- (no README.md)" }
    $lines += ""
    Remove-Item $tmp -Recurse -Force
}
New-Item -ItemType Directory -Force -Path (Split-Path $OutFile) | Out-Null
Set-Content -Path $OutFile -Value $lines -Encoding UTF8
Write-Host "Catalog written: $OutFile ($($repos.Count) repos)"
