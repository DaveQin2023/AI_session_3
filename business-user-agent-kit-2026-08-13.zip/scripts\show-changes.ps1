# show-changes.ps1 — immediate visual display + smoke test after any code change.
# Called by the builder agent right after editing (and available to her as /show-changes).
# 1. Lists exactly what changed (git, product repo).
# 2. Smoke test: every local href/src reference in changed HTML files must exist on disk.
# 3. Opens the changed page(s) in her default browser for visual review.
# Exit 0 = all checks pass; exit 1 = a check failed (agent must report it, not hide it).

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot
Set-Location $repoRoot

$fail = $false

Write-Host "=== 1. What changed (uncommitted, product repo) ==="
$status = git status --porcelain -- ':!docs/agent' 2>$null
if (-not $status) { Write-Host "  (no uncommitted changes - nothing to show)"; exit 0 }
git diff --stat
git diff --stat --cached | Out-Null  # no-op; staged changes are unusual here but status below covers them

$changed = @($status | ForEach-Object { ($_ -replace '^..\s+','') -replace '"','' })
$changed | ForEach-Object { Write-Host "  changed: $_" }

Write-Host "=== 2. Smoke test: local references in changed HTML files ==="
$htmlChanged = @($changed | Where-Object { $_ -like '*.html' })
$refChecked = 0; $refMissing = 0
foreach ($h in $htmlChanged) {
    $full = Join-Path $repoRoot $h
    if (-not (Test-Path $full)) { Write-Host "  FAIL: deleted/missing file $h"; $fail = $true; continue }
    $dir = Split-Path -Parent $full
    $refs = Select-String -Path $full -Pattern '(?:href|src)="([^"]+)"' -AllMatches |
        ForEach-Object { $_.Matches } | ForEach-Object { $_.Groups[1].Value } |
        Where-Object { $_ -notmatch '^(https?:|#|mailto:|data:|//)' } | Sort-Object -Unique
    foreach ($r in $refs) {
        $refChecked++
        $target = Join-Path $dir ($r -split '[?#]')[0]
        if (Test-Path $target) { Write-Host "  PASS: $h -> $r" }
        else { Write-Host "  FAIL: $h -> $r (file not found)"; $refMissing++; $fail = $true }
    }
}
if ($refChecked -eq 0) { Write-Host "  (no changed HTML files with local references)" }
Write-Host "  references checked: $refChecked, missing: $refMissing"

Write-Host "=== 3. Open the page(s) for visual review ==="
$toOpen = @($htmlChanged)
if ($toOpen.Count -eq 0) {
    # Only css/js changed: open every HTML page that references a changed file.
    $nonHtml = @($changed | Where-Object { $_ -match '\.(css|js)$' })
    foreach ($n in $nonHtml) {
        $name = [regex]::Escape((Split-Path -Leaf $n))
        Get-ChildItem -Path (Join-Path $repoRoot 'src') -Filter *.html -Recurse -ErrorAction SilentlyContinue |
            Where-Object { Select-String -Path $_.FullName -Pattern $name -Quiet } |
            ForEach-Object { $toOpen += (Resolve-Path -Relative $_.FullName) }
    }
    $toOpen = @($toOpen | Sort-Object -Unique)
}
if ($toOpen.Count -eq 0) {
    Write-Host "  (no HTML page found to open - tell her which file to review manually)"
} else {
    foreach ($p in $toOpen) {
        $full = (Resolve-Path (Join-Path $repoRoot ($p -replace '^\.\\',''))).Path
        Write-Host "  opening in browser: $full"
        Start-Process $full
    }
    Write-Host "  (if the page was already open, press F5 / Ctrl+R in the browser to refresh)"
}

if ($fail) { Write-Host "RESULT: FAIL - fix the missing references before asking her to review"; exit 1 }
Write-Host "RESULT: PASS - ready for her visual review"
exit 0
