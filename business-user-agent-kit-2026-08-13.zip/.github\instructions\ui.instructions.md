---
name: 'UI conventions'
description: 'Conventions for the HTML/CSS UI prototypes'
applyTo: 'src/ui/**'
---

# UI prototype conventions

- Keep prototypes as plain HTML/CSS in `src/ui/` — no frameworks or build steps, because the Business User must be able to open files directly in a browser.
- One component idea per file (like `search-box.html`); page files may include them conceptually via comments.
- Use simple class names describing purpose (`.quick-search`, `.header`), not visual details, because visuals change during prototyping.
- Preserve her existing styling choices unless she asks to change them — the prototype records her design decisions.
