# capture-session.ps1 - Stop hook: snapshot the design-as-built at session end
# Writes session-diff.patch (git add -N first, so NEW files are included) and diff-stat.txt
# IMPORTANT: uses git's own --output option, NOT PowerShell '>' redirection.
# In Windows PowerShell 5.1, '>' writes UTF-16LE, which git apply cannot read.
# No AI involved. Exit 0 = success.
$ErrorActionPreference = "Stop"
try {
    $dir = "docs/agent/sessions/_capture/$(Get-Date -Format yyyy-MM-dd)"
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    git add -N . 2>$null
    git diff --output="$dir/session-diff.patch" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
    git diff --stat --output="$dir/diff-stat.txt" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
    # session-skeleton: mechanical file list + timestamp (no AI)
    $skeleton = @("# Session skeleton ($(Get-Date -Format s))", "", "## Changed files (vs origin/main)")
    $skeleton += (git diff --name-status origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff')
    Set-Content -Path "$dir/session-skeleton.md" -Value $skeleton -Encoding UTF8
    # Persist intent history to the dedicated intent repo (Option A). Fail-soft:
    # a sync failure must never block session end.
    try { & "$PSScriptRoot\sync-intent.ps1" -Message "session-end sync $(Get-Date -Format s)" | Out-Null } catch { Write-Warning "intent sync skipped: $_" }
    # Daily WIP publish to the feature repo (only if handoff.config.json sets
    # dailyPublish=true). Force-updates daily/<date> from today's capture patch;
    # never opens a PR - the sign-off PR stays behind the manual handoff.ps1 gate.
    try { & "$PSScriptRoot\publish-handoff.ps1" -SessionName (Get-Date -Format yyyy-MM-dd) -Daily | Out-Null } catch { Write-Warning "daily feature-repo publish skipped: $_" }
    exit 0
} catch {
    Write-Error $_
    exit 1
}
