# inject-context.ps1 - SessionStart hook: inject cross-session context into the new agent session
# Documented output: hookSpecificOutput.additionalContext ("Context added to the agent's conversation",
# SessionStart section of the hooks reference). Exit 0 = "Success: parse stdout as JSON".
# Injects: active brief + tail of recent captured ideas (verbatim) + diff-stat of work in progress.
# Caps (engineering judgment, tune in pilot): last 2 capture days, max 30 idea lines, stat only.
$ErrorActionPreference = "Stop"
try {
    # PS 5.1 writes stdout in the OEM codepage by default, which mangles non-ASCII
    # (em-dashes etc.) and can corrupt the JSON. Force UTF-8 output. (Empirical: T5 first run failed on this.)
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $null = [Console]::In.ReadToEnd()  # drain stdin; input fields not needed
    $parts = @()

    # 1. Active brief (current form ID, goal, accepted decisions)
    if (Test-Path "docs/agent/active-brief.md") {
        # -Encoding UTF8 required: PS 5.1 misreads BOM-less UTF-8 as ANSI (Empirical: T5 first run)
        $parts += "## Active work brief`n" + (Get-Content "docs/agent/active-brief.md" -Raw -Encoding UTF8)
    }

    # 2. Recent captured ideas, verbatim (last 2 capture days, max 30 lines)
    $captureRoot = "docs/agent/sessions/_capture"
    if (Test-Path $captureRoot) {
        $recentDays = Get-ChildItem $captureRoot -Directory | Sort-Object Name -Descending | Select-Object -First 2
        $ideaLines = @()
        foreach ($d in $recentDays) {
            $f = Join-Path $d.FullName "ideas.jsonl"
            if (Test-Path $f) { $ideaLines += Get-Content $f -Encoding UTF8 }
        }
        $ideaLines = $ideaLines | Select-Object -Last 30
        if ($ideaLines.Count -gt 0) {
            $parts += "## Recent design ideas from the user (verbatim, oldest first)`n" + ($ideaLines -join "`n")
        }
    }

    # 3. Work in progress: diff-stat vs origin/main (add -N so NEW files are visible)
    git add -N . 2>$null
    $stat = git diff --stat origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff' 2>$null
    if ($stat) {
        $parts += "## Uncommitted work in progress (git diff --stat vs origin/main)`n" + ($stat -join "`n")
    }

    if ($parts.Count -eq 0) {
        Write-Output "{}"   # always emit valid JSON; empty-stdout behavior is undocumented
        exit 0
    }

    $context = "Cross-session context for this Business User UI-prototyping workspace.`n`n" + ($parts -join "`n`n")
    @{
        hookSpecificOutput = @{
            hookEventName     = "SessionStart"
            additionalContext = $context
        }
    } | ConvertTo-Json -Depth 4 -Compress | Write-Output
    exit 0
} catch {
    # Logging/context failure must never break her session: non-2 exit = non-blocking warning
    Write-Error $_
    exit 1
}
