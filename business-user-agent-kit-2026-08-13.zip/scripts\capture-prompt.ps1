# capture-prompt.ps1 - UserPromptSubmit hook: log each user prompt verbatim to ideas.jsonl
# Input: JSON on stdin with documented fields: timestamp, session_id (optional), prompt
# Output: appends one JSON line to docs/agent/sessions/_capture/<date>/ideas.jsonl
# No AI involved. Exit 0 = success (documented exit-code semantics).
$ErrorActionPreference = "Stop"
try {
    $raw = [Console]::In.ReadToEnd()
    $in = $raw | ConvertFrom-Json
    $dir = "docs/agent/sessions/_capture/$(Get-Date -Format yyyy-MM-dd)"
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $line = @{
        ts      = $in.timestamp
        session = $in.session_id
        prompt  = $in.prompt
    } | ConvertTo-Json -Compress
    Add-Content -Path "$dir/ideas.jsonl" -Value $line -Encoding UTF8
    exit 0
} catch {
    # Never block the user's prompt on a logging failure: non-2 exit = non-blocking warning
    Write-Error $_
    exit 1
}
