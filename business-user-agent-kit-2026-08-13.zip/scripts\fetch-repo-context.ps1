# fetch-repo-context.ps1 - download an identified company repo and extract its
# documentation as context for design/build sessions.
#
# LAYER 0 PROOF this is permitted: GitHub role table (fetched 2026-08-10) -
# Read role = YES for "Pull from the person or team's assigned repositories".
# Cloning is a pull. Nothing here writes to any remote.
#
# What it does (mechanical, no AI):
#   1. git clone --depth 1 <url> external/<name>     (external/ is gitignored)
#   2. copy all *.md files -> docs/agent/context/<name>/  (keeps relative paths)
#   3. write _inventory.md: file tree + package.json fields + `function` names
#      found by regex in js files (regex is a heuristic, stated in the output)
# The INTENT AGENT then reads the extracted files and writes features.md (the
# AI summarization step lives in the agent, never in this script).
param(
    [Parameter(Mandatory=$true)][string]$Name,
    [Parameter(Mandatory=$true)][string]$Url
)
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$dest = "external/$Name"
$ctx  = "docs/agent/context/$Name"

if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
$ErrorActionPreference = "Continue"   # git progress goes to stderr (T7 lesson)
git clone -q --depth 1 $Url $dest 2>&1 | Out-Null
$cloneExit = $LASTEXITCODE
$ErrorActionPreference = "Stop"
if ($cloneExit -ne 0) { Write-Error "Clone failed for $Url (exit $cloneExit)"; exit 1 }

New-Item -ItemType Directory -Force -Path $ctx | Out-Null

# 2. extract markdown docs, preserving relative paths
$mdCount = 0
Get-ChildItem $dest -Recurse -Filter *.md | ForEach-Object {
    $rel = $_.FullName.Substring((Resolve-Path $dest).Path.Length + 1)
    $target = Join-Path $ctx $rel
    New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
    Copy-Item $_.FullName $target -Force
    $mdCount++
}

# 3. mechanical inventory
$inv = @("# $Name - mechanical inventory ($(Get-Date -Format s))", "",
         "Source: $Url (shallow clone in external/$Name)", "")
$pkg = Join-Path $dest "package.json"
if (Test-Path $pkg) {
    try { $p = Get-Content $pkg -Raw -Encoding UTF8 | ConvertFrom-Json
          $inv += "package.json: name=$($p.name) version=$($p.version) description=$($p.description)"; $inv += "" } catch { }
}
$inv += "## File tree"
Get-ChildItem $dest -Recurse -File | Where-Object { $_.FullName -notmatch '\\\.git\\' } |
    ForEach-Object { $inv += "- " + $_.FullName.Substring((Resolve-Path $dest).Path.Length + 1) }
$inv += ""
$inv += "## Function names in .js files (regex heuristic ``function\s+(\w+)`` - not a full parse)"
Get-ChildItem $dest -Recurse -Filter *.js | Where-Object { $_.FullName -notmatch '\\\.git\\' } | ForEach-Object {
    $rel = $_.FullName.Substring((Resolve-Path $dest).Path.Length + 1)
    Select-String -Path $_.FullName -Pattern 'function\s+(\w+)' -AllMatches | ForEach-Object {
        $_.Matches | ForEach-Object { $inv += "- $($_.Groups[1].Value)  ($rel)" }
    }
}
Set-Content -Path (Join-Path $ctx "_inventory.md") -Value $inv -Encoding UTF8
Write-Host "Context extracted: $ctx ($mdCount markdown file(s) + _inventory.md)"
Write-Host "Clone kept at: $dest (gitignored; delete when done)"
exit 0
