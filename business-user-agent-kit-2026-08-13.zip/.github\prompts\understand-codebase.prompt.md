---
name: understand-codebase
description: Read ALL locally available repos (UI working copy + reference clones under external/) and write a cross-repo understanding document. Read-only; never edits code.
argument-hint: Optional focus, e.g. "how do product rates get onto the page"
---

You are building a cross-repository understanding for a non-developer Business
User (insurance/annuity marketing). She works in ONE writable repo (this
folder, the UI) and has read-only reference clones of the other company repos.

## Non-negotiable working rules — apply to every step below

1. Criticize yourself: before presenting any information or design, re-check it for correctness and accuracy, and state anything you are unsure of.
2. You need proof for all the information you provide: every claim must cite the exact file and quote the line(s) that support it.
3. Go through the code thoroughly — read the actual files in this workspace; never answer from memory, prior sessions, or general knowledge of "typical" codebases.
4. Do not make up things. Be very serious and sincere about what you are doing: if something cannot be verified, say "I could not verify this" instead of guessing.

## The three local folders — go through ALL of them thoroughly

Read file by file, top to bottom. Do not skim, sample, or stop at the first
match — a claim about "how the code works" based on a partial read is treated
as made up.

1. **This working folder (the UI repo)** — the only place changes are ever made.
   Read `src/` fully.
2. **`external/<name>/` reference clones** — one per company repo listed in
   `scripts/repo-list.txt` (the configuration file naming every source repo and
   its URL). Read their source files fully. These clones are READ-ONLY
   references: never edit, never commit, never push in them.
3. **`docs/agent/context/<name>/`** — pre-extracted docs and `_inventory.md`
   per reference repo. Use them as an index, but verify claims against the real
   source in `external/` before repeating them.

If a repo named in `scripts/repo-list.txt` has no clone under `external/`, run:
`scripts/fetch-repo-context.ps1 -Name <name> -Url <url>` (url from the config
file only — never construct URLs yourself).

## What to produce

Write `docs/agent/context/overview.md` (overwrite if present) containing:

1. **Repo map** — one paragraph per repo, in her plain language: what it is
   for, with 2-3 quoted lines of real code/docs as evidence per claim.
2. **How they connect** — trace at least one real data path end to end (e.g.
   database column → rule function → UI element), quoting the exact file and
   line content at each hop. If a hop cannot be evidenced in the code, mark it
   `[UNVERIFIED]` — never invent a connection.
3. **Where her change would go** — for the focus `${input:focus:Optional — what is she trying to understand or change?}`
   (if given): which repo owns that behavior, and why the UI repo is or is not
   the right place for her change.
4. A `Generated:` timestamp line and the list of folders actually read.

## Rules

- READ-ONLY toward all code: the ONLY file you create or edit is
  `docs/agent/context/overview.md`.
- Never run git commands that mutate anything (`commit`, `push`, `merge`,
  `checkout`, `reset`) in ANY of the three folders.
- Every claim about the code must quote the file it came from. No quotes = say
  you could not verify it.
- `docs/agent/context/` is synced automatically to her intent repo at each
  turn end, so the overview becomes part of her permanent design history.
