# Pure OpenAI Agent - Updated for 3-column CSV and real document loading
# app.py
import pdb
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import json
import logging
import csv
from typing import List, Dict
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env file
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for React frontend

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize OpenAI client (v1.0+ syntax)
client = OpenAI(
    api_key=os.getenv('OPENAI_API_KEY')
)

def load_document_summaries(csv_file_path: str = "document_summary.csv") -> List[Dict]:
    """
    Load document summaries from CSV file.
    CSV format: doc_name,summary,file_name
    """
    documents = []
    
    try:
        # Check if file exists
        if not os.path.exists(csv_file_path):
            logger.warning(f"CSV file {csv_file_path} not found. Using default documents.")
            return get_default_documents()
        
        # Read CSV file
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            csv_reader = csv.DictReader(file)
            
            # Validate CSV headers
            required_columns = ['doc_name', 'summary', 'file_name']
            if not all(col in csv_reader.fieldnames for col in required_columns):
                logger.error(f"CSV file must have columns: {required_columns}")
                return get_default_documents()
            
            # Load documents from CSV
            for row in csv_reader:
                doc_name = row.get('doc_name', '').strip()
                summary = row.get('summary', '').strip()
                file_name = row.get('file_name', '').strip()
                
                if doc_name and summary and file_name:  # Skip empty rows
                    documents.append({
                        "doc_name": doc_name,
                        "summary": summary,
                        "file_name": file_name
                    })
                else:
                    logger.warning(f"Skipping invalid row: {row}")
        
        logger.info(f"Loaded {len(documents)} documents from {csv_file_path}")
        return documents
        
    except Exception as e:
        logger.error(f"Error loading CSV file {csv_file_path}: {str(e)}")
        return get_default_documents()

def get_default_documents() -> List[Dict]:
    """
    Fallback default documents if CSV loading fails.
    """
    logger.info("Using default document summaries")
    return [
        {
            "doc_name": "Loan_Application_Process",
            "summary": "Detailed process for applying for personal loans, mortgages, business loans, eligibility criteria, and required documentation.",
            "file_name": "Loan_Application_Process.pdf"
        },
        {
            "doc_name": "Product_Catalog_2024",
            "summary": "Comprehensive catalog of all banking products including savings accounts, credit cards, loans, and investment options with features and pricing.",
            "file_name": "Product_Catalog_2024.pdf"
        },
        {
            "doc_name": "Security_Guidelines", 
            "summary": "Complete security protocols for online banking, password requirements, two-factor authentication, and fraud prevention measures.",
            "file_name": "Security_Guidelines.pdf"
        },
        {
            "doc_name": "Account_Management_Guide",
            "summary": "Step-by-step instructions for managing accounts, transferring funds, setting up automatic payments, and mobile banking features.",
            "file_name": "Account_Management_Guide.pdf"
        },
        {
            "doc_name": "ATM_PIN_Management",
            "summary": "Instructions for changing ATM PIN, security measures, PIN recovery process, and troubleshooting ATM issues.",
            "file_name": "ATM_PIN_Management.pdf"
        }
    ]

# Load document summaries from CSV
DOCUMENT_SUMMARIES = load_document_summaries()

class KnowledgeBaseAgent:
    def __init__(self, documents_directory: str = "documents"):
        self.model = "gpt-3.5-turbo"
        self.max_tokens = 1000
        self.temperature = 0.7
        self.documents_directory = documents_directory
        
        # Create documents directory if it doesn't exist
        if not os.path.exists(self.documents_directory):
            os.makedirs(self.documents_directory)
            logger.info(f"Created documents directory: {self.documents_directory}")
    
    def truncate_content(self, content: str, max_tokens: int = 8000) -> str:
        """
        Truncate document content to fit within token limits.
        Rough estimation: 1 token ≈ 4 characters
        """
        max_chars = max_tokens * 4  # Conservative estimate
        
        if len(content) <= max_chars:
            return content
        
        # Try to truncate at paragraph or sentence boundaries
        truncated = content[:max_chars]
        
        # Find the last paragraph break
        last_paragraph = truncated.rfind('\n\n')
        if last_paragraph > max_chars * 0.7:  # At least 70% of content
            return truncated[:last_paragraph] + "\n\n[Content truncated for length...]"
        
        # Find the last sentence
        last_sentence = max(
            truncated.rfind('. '),
            truncated.rfind('! '),
            truncated.rfind('? ')
        )
        if last_sentence > max_chars * 0.7:
            return truncated[:last_sentence + 1] + " [Content truncated for length...]"
        
        # Hard truncate if no good break point found
        return truncated + " [Content truncated for length...]"
    
    def extract_relevant_sections(self, content: str, question: str, max_tokens: int = 6000) -> str:
        """
        Use OpenAI to extract only the most relevant sections from large documents.
        """
        try:
            # First, check if content is too large
            if len(content) < max_tokens * 4:  # If content is small enough, return as-is
                return content
            
            # Split content into chunks for analysis
            chunk_size = 3000 * 4  # ~3000 tokens per chunk
            chunks = [content[i:i+chunk_size] for i in range(0, len(content), chunk_size)]
            
            relevant_sections = []
            
            for i, chunk in enumerate(chunks[:5]):  # Limit to first 5 chunks to avoid too many API calls
                messages = [
                    {
                        "role": "system",
                        "content": "Extract only the sections from this document chunk that are relevant to answering the user's question. Return the relevant text sections, or 'NO_RELEVANT_CONTENT' if nothing is relevant."
                    },
                    {
                        "role": "user",
                        "content": f"""
Document Chunk {i+1}:
{chunk}

User Question: {question}

Extract and return only the relevant sections that help answer this question. If no relevant content, respond with 'NO_RELEVANT_CONTENT'.
"""
                    }
                ]
                
                try:
                    response = self.call_openai(messages, max_tokens=1000)
                    if response.strip() != "NO_RELEVANT_CONTENT":
                        relevant_sections.append(f"--- Relevant Section {i+1} ---\n{response}")
                except Exception as e:
                    logger.warning(f"Error processing chunk {i+1}: {str(e)}")
                    continue
            
            if relevant_sections:
                combined_content = "\n\n".join(relevant_sections)
                return self.truncate_content(combined_content, max_tokens)
            else:
                # If no relevant sections found, return truncated original
                return self.truncate_content(content, max_tokens)
                
        except Exception as e:
            logger.error(f"Error in extract_relevant_sections: {str(e)}")
            return self.truncate_content(content, max_tokens)

    def call_openai(self, messages: List[Dict], max_tokens: int = None) -> str:
        """
        Direct OpenAI API call using v1.0+ syntax with error handling
        """
        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=max_tokens or self.max_tokens,
                temperature=self.temperature
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            error_msg = str(e)
            if "context_length_exceeded" in error_msg:
                logger.error(f"Context length exceeded. Error: {error_msg}")
                raise Exception("Document content is too large. Please try with a more specific question.")
            else:
                logger.error(f"OpenAI API error: {error_msg}")
                raise e
    
    def load_document_content(self, file_name: str) -> str:
        """
        Load the full content of a document by file name.
        Supports PDF, TXT, DOCX, and other common formats.
        """
        file_path = os.path.join(self.documents_directory, file_name)
        
        # DEBUG: Log exactly what we're trying to open
        logger.info(f"=== FILE LOADING DEBUG ===")
        logger.info(f"Requested file_name: '{file_name}'")
        logger.info(f"Documents directory: '{self.documents_directory}'")
        logger.info(f"Full file path: '{file_path}'")
        logger.info(f"Current working directory: '{os.getcwd()}'")
        logger.info(f"Absolute file path: '{os.path.abspath(file_path)}'")
        logger.info(f"File exists: {os.path.exists(file_path)}")
        
        # List files in documents directory for debugging
        try:
            if os.path.exists(self.documents_directory):
                files_in_dir = os.listdir(self.documents_directory)
                logger.info(f"Files in documents directory: {files_in_dir}")
            else:
                logger.error(f"Documents directory does not exist: {self.documents_directory}")
        except Exception as e:
            logger.error(f"Error listing files in directory: {str(e)}")
        
        logger.info(f"=== END DEBUG ===")
        
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                logger.error(f"Document file not found: {file_path}")
                return f"Error: Document file '{file_name}' not found in {self.documents_directory} directory."
            
            # Handle different file types
            file_extension = file_name.lower().split('.')[-1]
            logger.info(f"File extension detected: '{file_extension}'")
            
            if file_extension == 'pdf':
                logger.info("Loading as PDF file...")
                return self._load_pdf(file_path)
            elif file_extension == 'txt':
                logger.info("Loading as text file...")
                return self._load_text_file(file_path)
            elif file_extension in ['docx', 'doc']:
                logger.info("Loading as DOCX file...")
                return self._load_docx(file_path)
            elif file_extension == 'md':
                logger.info("Loading as markdown file...")
                return self._load_text_file(file_path)
            else:
                # Try to read as plain text
                logger.warning(f"Unknown file type for {file_name}, attempting to read as text")
                return self._load_text_file(file_path)
                
        except Exception as e:
            logger.error(f"Error loading document {file_name}: {str(e)}")
            return f"Error loading document '{file_name}': {str(e)}"
    
    def _load_pdf(self, file_path: str) -> str:
        """Load content from PDF file."""
        try:
            import PyPDF2
            content = ""
            with open(file_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for page_num, page in enumerate(reader.pages):
                    try:
                        page_text = page.extract_text()
                        content += f"\n--- Page {page_num + 1} ---\n{page_text}\n"
                    except Exception as e:
                        logger.warning(f"Error reading page {page_num + 1}: {str(e)}")
                        continue
            return content.strip()
        except ImportError:
            return "Error: PyPDF2 library not installed. Please install it with: pip install PyPDF2"
        except Exception as e:
            return f"Error reading PDF: {str(e)}"
    
    def _load_text_file(self, file_path: str) -> str:
        """Load content from text file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                return file.read()
        except UnicodeDecodeError:
            # Try with different encoding
            try:
                with open(file_path, 'r', encoding='latin-1') as file:
                    return file.read()
            except Exception as e:
                return f"Error reading text file with multiple encodings: {str(e)}"
        except Exception as e:
            return f"Error reading text file: {str(e)}"
    
    def _load_docx(self, file_path: str) -> str:
        """Load content from DOCX file."""
        try:
            import docx
            doc = docx.Document(file_path)
            content = []
            for paragraph in doc.paragraphs:
                content.append(paragraph.text)
            return '\n'.join(content)
        except ImportError:
            return "Error: python-docx library not installed. Please install it with: pip install python-docx"
        except Exception as e:
            return f"Error reading DOCX: {str(e)}"
    
    def find_relevant_document(self, question: str) -> Dict:
        """
        Use OpenAI to find the single most relevant document for the question.
        NO HARDCODED DOCUMENT NAMES - relies purely on OpenAI's selection.
        """
        try:
            # Format document summaries with clear structure and numbering
            summaries_text = ""
            for i, doc in enumerate(DOCUMENT_SUMMARIES, 1):
                summaries_text += f"""
{i}. DOC_NAME: {doc['doc_name']}
   SUMMARY: {doc['summary']}
   FILE_NAME: {doc['file_name']}
"""

            # Create orchestrator prompt - Ask OpenAI to return file_name directly
            messages = [
                {
                    "role": "system",
                    "content": "You are a document selection expert. Analyze the user's question and select the SINGLE most relevant document based on semantic similarity between the question and document summaries. Focus on the main topic and intent of the user's question."
                },
                {
                    "role": "user",
                    "content": f"""
Available Documents:
{summaries_text}

User Question: "{question}"

Analyze the semantic meaning of the user's question and match it with the most relevant document summary. Consider the main topic, intent, and specific information needs.

Respond ONLY in this JSON format with EXACT values from the list above:
{{
    "selected_file_name": "EXACT_FILE_NAME_FROM_ABOVE",
    "selected_doc_name": "EXACT_DOC_NAME_FROM_ABOVE", 
    "reasoning": "Brief explanation of the semantic match",
    "confidence": "high/medium/low"
}}
"""
                }
            ]
            
            # Call OpenAI
            response = self.call_openai(messages, max_tokens=200)
            
            # DEBUG: Log OpenAI's exact response
            logger.info(f"=== DOCUMENT SELECTION DEBUG ===")
            logger.info(f"User question: '{question}'")
            logger.info(f"OpenAI raw response: '{response}'")
            logger.info(f"=== END SELECTION DEBUG ===")

            # Parse JSON response - THIS IS WHERE OPENAI RETURNS THE SELECTION
            try:
                parsed_response = json.loads(response)
                selected_file_name = parsed_response.get("selected_file_name", "").strip()
                selected_doc_name = parsed_response.get("selected_doc_name", "").strip()
                #pdb.set_trace()
                logger.info(f"OpenAI selected - File: '{selected_file_name}', Doc: '{selected_doc_name}'")
                
                # Find the matching document in our CSV data using OpenAI's selection
                selected_doc = None
                
                # Try exact matches first
                for doc in DOCUMENT_SUMMARIES:
                    if doc['file_name'] == selected_file_name and doc['doc_name'] == selected_doc_name:
                        selected_doc = doc
                        logger.info(f"Exact match found: {doc['doc_name']} -> {doc['file_name']}")
                        break
                
                # If no exact match, try file_name with and without extension
                if not selected_doc:
                    logger.warning(f"No exact match, trying file_name variations for: '{selected_file_name}'")
                    for doc in DOCUMENT_SUMMARIES:
                        # Try exact file_name match
                        if doc['file_name'] == selected_file_name:
                            selected_doc = doc
                            logger.info(f"File match found: {doc['doc_name']} -> {doc['file_name']}")
                            break
                        # Try adding .pdf extension
                        elif doc['file_name'] == f"{selected_file_name}.pdf":
                            selected_doc = doc
                            logger.info(f"File match with .pdf extension: {doc['doc_name']} -> {doc['file_name']}")
                            break
                        # Try removing extension from CSV file_name
                        elif doc['file_name'].replace('.pdf', '') == selected_file_name:
                            selected_doc = doc
                            logger.info(f"File match without extension: {doc['doc_name']} -> {doc['file_name']}")
                            break
                
                # If still no match, try doc_name matching
                if not selected_doc:
                    logger.warning(f"No file match, trying doc_name matching for: '{selected_doc_name}'")
                    for doc in DOCUMENT_SUMMARIES:
                        # Try exact doc_name match
                        if doc['doc_name'] == selected_doc_name:
                            selected_doc = doc
                            logger.info(f"Doc name match found: {doc['doc_name']} -> {doc['file_name']}")
                            break
                        # Try partial doc_name match
                        elif selected_doc_name.lower() in doc['doc_name'].lower() or doc['doc_name'].lower() in selected_doc_name.lower():
                            selected_doc = doc
                            logger.info(f"Partial doc name match: {doc['doc_name']} -> {doc['file_name']}")
                            break
                        # Check if selected_doc_name is actually the summary (OpenAI confusion)
                        elif selected_doc_name.lower() in doc['summary'].lower():
                            selected_doc = doc
                            logger.info(f"Summary match (OpenAI returned summary as doc_name): {doc['doc_name']} -> {doc['file_name']}")
                            break
                
                # Final fallback
                if not selected_doc:
                    selected_doc = DOCUMENT_SUMMARIES[0]
                    logger.error(f"No matches found for OpenAI selection, using fallback: {selected_doc['doc_name']} -> {selected_doc['file_name']}")
                
                return {
                    "doc_name": selected_doc["doc_name"],
                    "file_name": selected_doc["file_name"],
                    "reasoning": parsed_response.get("reasoning", "Document selected by AI"),
                    "confidence": parsed_response.get("confidence", "medium")
                }
            except json.JSONDecodeError:
                logger.warning(f"Failed to parse OpenAI response: {response}")
                fallback_doc = DOCUMENT_SUMMARIES[0]
                return {
                    "doc_name": fallback_doc["doc_name"],
                    "file_name": fallback_doc["file_name"],
                    "reasoning": "Default fallback due to parsing error",
                    "confidence": "low"
                }
                
        except Exception as e:
            logger.error(f"Error in document selection: {str(e)}")
            fallback_doc = DOCUMENT_SUMMARIES[0]
            return {
                "doc_name": fallback_doc["doc_name"],
                "file_name": fallback_doc["file_name"],
                "reasoning": "Error in document selection",
                "confidence": "low"
            }
    
    def generate_answer(self, question: str, document_content: str, doc_name: str) -> str:
        """
        Generate an answer based on the loaded document content using OpenAI.
        Handles large documents by extracting relevant sections or truncating content.
        """
        try:
            # Check if document content is valid
            if not document_content or document_content.startswith("Error"):
                logger.warning(f"Invalid document content for {doc_name}: {document_content[:100]}...")
                return f"I apologize, but I couldn't load the content from '{doc_name}'. The document may be missing or corrupted. Please check that the file exists in the documents directory."
            
            # Handle large documents
            processed_content = document_content
            content_processing_note = ""
            
            # Estimate token count (rough: 1 token ≈ 4 characters)
            estimated_tokens = len(document_content) / 4
            
            if estimated_tokens > 8000:  # If document is large
                logger.info(f"Large document detected ({estimated_tokens:.0f} estimated tokens). Processing content...")
                
                # Try to extract relevant sections first
                try:
                    processed_content = self.extract_relevant_sections(document_content, question, max_tokens=6000)
                    content_processing_note = "\n\nNote: This answer is based on relevant sections extracted from a large document."
                except Exception as e:
                    logger.warning(f"Failed to extract relevant sections: {str(e)}. Using truncation instead.")
                    processed_content = self.truncate_content(document_content, max_tokens=6000)
                    content_processing_note = "\n\nNote: This answer is based on a portion of the full document due to length constraints."
            
            messages = [
                {
                    "role": "system",
                    "content": "You are a knowledgeable banking assistant. Provide comprehensive answers based on the provided document content. Be specific and cite relevant sections when appropriate. If the document doesn't contain relevant information for the question, clearly state this and explain what information is available instead."
                },
                {
                    "role": "user",
                    "content": f"""
Document: {doc_name}
Content:
{processed_content}

User Question: {question}

Provide a helpful answer based on the document content. If the document doesn't contain enough information to fully answer the question, say so and provide what information is available. Be specific and reference relevant sections from the document.
"""
                }
            ]
            
            response = self.call_openai(messages, max_tokens=800)
            logger.info(f"Generated answer for question: '{question}' using document: '{doc_name}'")
            
            return response + content_processing_note
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"Error generating answer: {error_msg}")
            
            if "too large" in error_msg.lower() or "context" in error_msg.lower():
                return f"I apologize, but the document '{doc_name}' is too large to process in full. Please try asking a more specific question about a particular aspect (e.g., 'What are the requirements for personal loans?' instead of 'tell me about loan application')."
            else:
                return f"I apologize, but I encountered an error while generating your answer. Error details: {error_msg}. Please try again."
    
    def process_query(self, question: str) -> Dict:
        """
        Main method to process a user query through the agent framework.
        """
        logger.info(f"Processing query: {question}")
        
        # Step 1: Find the most relevant document
        logger.info("Step 1: Finding relevant document...")
        doc_result = self.find_relevant_document(question)
        selected_doc_name = doc_result["doc_name"]
        selected_file_name = doc_result["file_name"]
        
        logger.info(f"Selected document: {selected_doc_name} (file: {selected_file_name})")
        logger.info(f"Selection reasoning: {doc_result['reasoning']}")
        logger.info(f"Selection confidence: {doc_result['confidence']}")
        
        # Step 2: Load the actual document content
        logger.info(f"Step 2: Loading document content from: {selected_file_name}")
        document_content = self.load_document_content(selected_file_name)
        
        # Log content preview for debugging
        content_preview = document_content[:200] + "..." if len(document_content) > 200 else document_content
        logger.info(f"Document content loaded. Length: {len(document_content)} characters")
        logger.info(f"Content preview: {content_preview}")
        
        # Check if content loading failed
        if document_content.startswith("Error"):
            logger.error(f"Document loading failed: {document_content}")
        
        # Step 3: Generate answer
        logger.info("Step 3: Generating answer using OpenAI...")
        answer = self.generate_answer(question, document_content, selected_doc_name)
        
        logger.info(f"Answer generated successfully. Length: {len(answer)} characters")
        
        return {
            "answer": answer,
            "source": selected_doc_name,
            "file_name": selected_file_name,
            "reasoning": doc_result["reasoning"],
            "confidence": doc_result["confidence"],
            "content_preview": content_preview,
            "debug_info": {
                "document_content_length": len(document_content),
                "content_starts_with_error": document_content.startswith("Error"),
                "documents_available": len(DOCUMENT_SUMMARIES)
            }
        }

# Initialize the agent
agent = KnowledgeBaseAgent()

@app.route('/')
def home():
    """Root endpoint for testing."""
    return jsonify({
        'message': 'Knowledge Base Agent API is running!',
        'backend': 'Pure OpenAI API with Real Document Loading',
        'endpoints': {
            'health': '/api/health',
            'chat': '/api/chat (POST)',
            'documents': '/api/documents'
        },
        'documents_directory': agent.documents_directory,
        'status': 'active'
    })

@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Main chat endpoint that processes user messages through the agent framework.
    """
    try:
        data = request.get_json()
        
        if not data or 'message' not in data:
            return jsonify({
                'success': False,
                'error': 'No message provided'
            }), 400
        
        user_message = data['message'].strip()
        
        if not user_message:
            return jsonify({
                'success': False,
                'error': 'Empty message'
            }), 400
        
        # Process the query through the agent
        result = agent.process_query(user_message)
        
        return jsonify({
            'success': True,
            'answer': result['answer'],
            'source': result['source'],
            'file_name': result['file_name'],
            'reasoning': result['reasoning'],
            'confidence': result['confidence'],
            'content_preview': result.get('content_preview', ''),
            'document_url': f"/api/documents/{result['file_name']}",  # URL to view document
            'download_url': f"/api/documents/{result['file_name']}/download"  # URL to download document
        })
        
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'message': str(e)
        }), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'OK',
        'message': 'Knowledge Base Agent is running',
        'backend': 'Pure OpenAI API with Real Document Loading',
        'documents_loaded': len(DOCUMENT_SUMMARIES),
        'documents_directory': agent.documents_directory
    })

@app.route('/api/documents/<filename>', methods=['GET'])
def serve_document(filename):
    """Serve document files for viewing in browser."""
    try:
        # Security: Only allow files that exist in our document summaries
        allowed_files = [doc['file_name'] for doc in DOCUMENT_SUMMARIES]
        if filename not in allowed_files:
            return jsonify({
                'error': 'Document not found or not allowed'
            }), 404
        
        file_path = os.path.join(agent.documents_directory, filename)
        
        if not os.path.exists(file_path):
            return jsonify({
                'error': f'Document file {filename} not found'
            }), 404
        
        # Determine content type based on file extension
        file_extension = filename.lower().split('.')[-1]
        content_types = {
            'pdf': 'application/pdf',
            'txt': 'text/plain',
            'md': 'text/markdown',
            'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'doc': 'application/msword'
        }
        
        content_type = content_types.get(file_extension, 'application/octet-stream')
        
        from flask import send_file
        return send_file(
            file_path,
            mimetype=content_type,
            as_attachment=False,  # Display in browser if possible
            download_name=filename
        )
        
    except Exception as e:
        logger.error(f"Error serving document {filename}: {str(e)}")
        return jsonify({
            'error': f'Error serving document: {str(e)}'
        }), 500

@app.route('/api/documents/<filename>/download', methods=['GET'])
def download_document(filename):
    """Force download of document files."""
    try:
        # Security: Only allow files that exist in our document summaries
        allowed_files = [doc['file_name'] for doc in DOCUMENT_SUMMARIES]
        if filename not in allowed_files:
            return jsonify({
                'error': 'Document not found or not allowed'
            }), 404
        
        file_path = os.path.join(agent.documents_directory, filename)
        
        if not os.path.exists(file_path):
            return jsonify({
                'error': f'Document file {filename} not found'
            }), 404
        
        from flask import send_file
        return send_file(
            file_path,
            as_attachment=True,  # Force download
            download_name=filename
        )
        
    except Exception as e:
        logger.error(f"Error downloading document {filename}: {str(e)}")
        return jsonify({
            'error': f'Error downloading document: {str(e)}'
        }), 500

@app.route('/api/debug/files', methods=['GET'])
def debug_files():
    """Debug endpoint to check file locations and CSV contents."""
    debug_info = {
        'working_directory': os.getcwd(),
        'documents_directory': agent.documents_directory,
        'documents_directory_exists': os.path.exists(agent.documents_directory),
        'csv_file_exists': os.path.exists('document_summary.csv'),
        'loaded_documents': [],
        'actual_files_in_directory': [],
        'missing_files': []
    }
    
    # Show what's loaded from CSV
    for doc in DOCUMENT_SUMMARIES:
        debug_info['loaded_documents'].append({
            'doc_name': doc['doc_name'],
            'file_name': doc['file_name'],
            'expected_path': os.path.join(agent.documents_directory, doc['file_name']),
            'file_exists': os.path.exists(os.path.join(agent.documents_directory, doc['file_name']))
        })
    
    # Show actual files in documents directory
    if os.path.exists(agent.documents_directory):
        try:
            actual_files = os.listdir(agent.documents_directory)
            debug_info['actual_files_in_directory'] = actual_files
        except Exception as e:
            debug_info['actual_files_in_directory'] = f"Error reading directory: {str(e)}"
    
    # Find missing files
    expected_files = [doc['file_name'] for doc in DOCUMENT_SUMMARIES]
    if os.path.exists(agent.documents_directory):
        actual_files = os.listdir(agent.documents_directory)
        debug_info['missing_files'] = [f for f in expected_files if f not in actual_files]
        debug_info['unexpected_files'] = [f for f in actual_files if f not in expected_files]
    
    return jsonify(debug_info)

@app.route('/api/documents', methods=['GET'])
def list_documents():
    """List all available documents with their file names."""
    return jsonify({
        'documents': [
            {
                'doc_name': doc['doc_name'],
                'file_name': doc['file_name'],
                'summary': doc['summary'],
                'view_url': f"/api/documents/{doc['file_name']}",
                'download_url': f"/api/documents/{doc['file_name']}/download"
            }
            for doc in DOCUMENT_SUMMARIES
        ],
        'total_count': len(DOCUMENT_SUMMARIES)
    })

if __name__ == '__main__':
    # Check for required environment variables
    if not os.getenv('OPENAI_API_KEY'):
        logger.error("OPENAI_API_KEY environment variable is required")
        exit(1)
    
    # Run the Flask app
    app.run(
        host='0.0.0.0',
        port=int(os.getenv('PORT', 5000)),
        debug=os.getenv('FLASK_ENV') == 'development'
    )