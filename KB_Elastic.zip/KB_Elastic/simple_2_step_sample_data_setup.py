"""
Sample Data Setup for KB System
Creates indices and populates with test data
"""

from elasticsearch import Elasticsearch
from sentence_transformers import SentenceTransformer
import json

# Initialize
es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
model = SentenceTransformer('all-MiniLM-L6-v2')

def setup_indices():
    """Create all necessary indices with proper mappings"""
    
    # 1. KB Summaries Index
    kb_summary_mapping = {
        "mappings": {
            "properties": {
                "kb_id": {"type": "keyword"},
                "sub_kb_id": {"type": "keyword"},
                "kb_type": {"type": "keyword"},
                "level": {"type": "keyword"},
                "parent_kb_id": {"type": "keyword"},
                "name": {"type": "text"},
                "description": {"type": "text"},
                "summary": {"type": "text"},
                "summary_embedding": {
                    "type": "dense_vector",
                    "dims": 384,
                    "similarity": "cosine"
                },
                "keywords": {"type": "keyword"},
                "entitlements": {
                    "properties": {
                        "required_roles": {"type": "keyword"},
                        "departments": {"type": "keyword"},
                        "access_level": {"type": "keyword"}
                    }
                },
                "stats": {
                    "properties": {
                        "document_count": {"type": "integer"},
                        "last_updated": {"type": "date"}
                    }
                },
                "created_at": {"type": "date"},
                "updated_at": {"type": "date"}
            }
        }
    }
    
    # Create kb_summaries index
    if es.indices.exists(index="kb_summaries"):
        es.indices.delete(index="kb_summaries")
    es.indices.create(index="kb_summaries", body=kb_summary_mapping)
    
    # 2. Document Index Mapping (used for all KB indices)
    document_mapping = {
        "mappings": {
            "properties": {
                "document_id": {"type": "keyword"},
                "title": {
                    "type": "text",
                    "analyzer": "standard",
                    "fields": {"keyword": {"type": "keyword"}}
                },
                "content": {"type": "text"},
                "content_embedding": {
                    "type": "dense_vector",
                    "dims": 384,
                    "similarity": "cosine"
                },
                "title_embedding": {
                    "type": "dense_vector",
                    "dims": 384,
                    "similarity": "cosine"
                },
                "metadata": {
                    "properties": {
                        "file_type": {"type": "keyword"},
                        "s3_url": {"type": "keyword"},
                        "author": {"type": "keyword"},
                        "tags": {"type": "keyword"},
                        "classification": {"type": "keyword"}
                    }
                },
                "entitlements": {
                    "properties": {
                        "required_roles": {"type": "keyword"},
                        "departments": {"type": "keyword"},
                        "document_sensitivity": {"type": "keyword"}
                    }
                },
                "created_at": {"type": "date"},
                "updated_at": {"type": "date"}
            }
        }
    }
    
    # Create document indices
    doc_indices = [
        "kb_tech-kb",
        "kb_business-kb_gtm-kb", 
        "kb_business-kb_roi-kb",
        "kb_business-kb_sales-kb"
    ]
    
    for index_name in doc_indices:
        if es.indices.exists(index=index_name):
            es.indices.delete(index=index_name)
        es.indices.create(index=index_name, body=document_mapping)
    
    print("✅ All indices created successfully")

def populate_kb_summaries():
    """Populate KB summaries with sample data"""
    
    summaries = [
        # Main KBs
        {
            "kb_id": "tech-kb",
            "sub_kb_id": None,
            "kb_type": "technical",
            "level": "main",
            "parent_kb_id": None,
            "name": "Technical Documentation",
            "description": "Software architecture, APIs, deployment guides, and technical specifications",
            "summary": "Comprehensive technical documentation covering software architecture patterns, API specifications, deployment procedures, infrastructure setup, code standards, and development best practices. Includes microservices design, database schemas, CI/CD pipelines, monitoring, and troubleshooting guides.",
            "keywords": ["architecture", "api", "deployment", "infrastructure", "code", "development"],
            "entitlements": {
                "required_roles": ["engineer", "architect", "devops"],
                "departments": ["engineering", "platform"],
                "access_level": "technical"
            },
            "stats": {
                "document_count": 25,
                "last_updated": "2024-08-12T00:00:00Z"
            },
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-08-12T00:00:00Z"
        },
        {
            "kb_id": "business-kb",
            "sub_kb_id": None,
            "kb_type": "business",
            "level": "main",
            "parent_kb_id": None,
            "name": "Business Strategy & Operations",
            "description": "Business strategy, planning, market analysis, and operations",
            "summary": "Strategic business documentation including quarterly planning, market analysis, competitive intelligence, business operations, financial planning, and organizational strategy. Contains go-to-market strategies, ROI analysis, sales operations, and business development materials.",
            "keywords": ["strategy", "planning", "market", "business", "operations", "financial"],
            "entitlements": {
                "required_roles": ["manager", "director", "vp", "executive"],
                "departments": ["business", "strategy", "sales", "marketing"],
                "access_level": "business"
            },
            "stats": {
                "document_count": 45,
                "last_updated": "2024-08-10T00:00:00Z"
            },
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-08-12T00:00:00Z"
        },
        
        # Sub-KBs
        {
            "kb_id": "business-kb",
            "sub_kb_id": "gtm-kb",
            "kb_type": "business",
            "level": "sub",
            "parent_kb_id": "business-kb",
            "name": "Go-to-Market Strategy",
            "description": "Product launches, market positioning, and GTM execution",
            "summary": "Go-to-market strategies and execution plans including product launch frameworks, market positioning documents, competitive analysis, customer segmentation, pricing strategies, channel partner programs, and marketing campaign planning. Contains templates, case studies, and best practices for bringing products to market.",
            "keywords": ["gtm", "launch", "positioning", "marketing", "channels", "pricing", "product"],
            "entitlements": {
                "required_roles": ["manager", "director", "marketing"],
                "departments": ["marketing", "product", "business"],
                "access_level": "business"
            },
            "stats": {
                "document_count": 15,
                "last_updated": "2024-08-08T00:00:00Z"
            },
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-08-12T00:00:00Z"
        },
        {
            "kb_id": "business-kb",
            "sub_kb_id": "roi-kb",
            "kb_type": "business",
            "level": "sub",
            "parent_kb_id": "business-kb",
            "name": "ROI & Financial Analysis",
            "description": "ROI calculations, financial projections, and investment analysis",
            "summary": "Financial analysis and ROI calculation frameworks including investment analysis templates, financial modeling spreadsheets, cost-benefit analysis guides, budget planning documents, and performance metrics. Contains methodologies for evaluating project returns, capital allocation decisions, and financial forecasting.",
            "keywords": ["roi", "financial", "analysis", "investment", "budget", "metrics", "cost"],
            "entitlements": {
                "required_roles": ["manager", "director", "finance"],
                "departments": ["finance", "business", "strategy"],
                "access_level": "business"
            },
            "stats": {
                "document_count": 12,
                "last_updated": "2024-08-05T00:00:00Z"
            },
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-08-12T00:00:00Z"
        },
        {
            "kb_id": "business-kb",
            "sub_kb_id": "sales-kb",
            "kb_type": "business",
            "level": "sub",
            "parent_kb_id": "business-kb",
            "name": "Sales Operations",
            "description": "Sales processes, CRM, and pipeline management",
            "summary": "Sales operations documentation including CRM processes, pipeline management, sales methodologies, territory planning, compensation plans, sales enablement materials, and performance tracking. Contains playbooks, scripts, objection handling guides, and sales training materials.",
            "keywords": ["sales", "crm", "pipeline", "territory", "enablement", "process", "quota"],
            "entitlements": {
                "required_roles": ["sales", "manager", "director"],
                "departments": ["sales", "business"],
                "access_level": "business"
            },
            "stats": {
                "document_count": 18,
                "last_updated": "2024-08-09T00:00:00Z"
            },
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": "2024-08-12T00:00:00Z"
        }
    ]
    
    # Generate embeddings and index
    for i, summary in enumerate(summaries):
        # Generate embedding for summary text
        summary_text = f"{summary['name']} {summary['description']} {summary['summary']}"
        embedding = model.encode(summary_text).tolist()
        summary["summary_embedding"] = embedding
        
        # Index the document
        doc_id = f"{summary['kb_id']}-{summary['sub_kb_id'] or 'main'}"
        es.index(index="kb_summaries", id=doc_id, body=summary)
    
    print("✅ KB summaries populated")

def populate_tech_kb():
    """Populate technical KB with sample documents"""
    
    tech_docs = [
        {
            "document_id": "tech-001",
            "title": "Microservices Architecture Guide",
            "content": "This comprehensive guide covers microservices architecture patterns, service decomposition strategies, inter-service communication, data management patterns, and deployment considerations. Includes best practices for API design, service discovery, load balancing, and fault tolerance. Covers containerization with Docker, orchestration with Kubernetes, and monitoring strategies for distributed systems.",
            "metadata": {
                "file_type": "pdf",
                "s3_url": "s3://kb-docs/tech/microservices-guide.pdf",
                "author": "engineering-team",
                "tags": ["architecture", "microservices", "distributed-systems"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["engineer", "architect"],
                "departments": ["engineering"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-07-15T10:30:00Z",
            "updated_at": "2024-08-01T14:20:00Z"
        },
        {
            "document_id": "tech-002",
            "title": "REST API Design Standards",
            "content": "API design standards and best practices for building RESTful services. Covers HTTP methods, status codes, resource naming conventions, versioning strategies, authentication patterns, rate limiting, and documentation requirements. Includes examples of well-designed endpoints, error handling patterns, and API testing strategies.",
            "metadata": {
                "file_type": "docx",
                "s3_url": "s3://kb-docs/tech/api-standards.docx",
                "author": "platform-team",
                "tags": ["api", "rest", "standards", "design"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["engineer", "architect"],
                "departments": ["engineering"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-06-20T09:15:00Z",
            "updated_at": "2024-07-30T11:45:00Z"
        },
        {
            "document_id": "tech-003",
            "title": "CI/CD Pipeline Setup Guide",
            "content": "Complete guide for setting up continuous integration and deployment pipelines. Covers Git workflows, automated testing strategies, build processes, deployment automation, environment management, and monitoring. Includes configurations for GitHub Actions, Jenkins, and deployment to AWS ECS and Kubernetes clusters.",
            "metadata": {
                "file_type": "pdf",
                "s3_url": "s3://kb-docs/tech/cicd-setup.pdf",
                "author": "devops-team",
                "tags": ["cicd", "deployment", "automation", "devops"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["engineer", "devops"],
                "departments": ["engineering"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-05-10T14:00:00Z",
            "updated_at": "2024-08-05T16:30:00Z"
        }
    ]
    
    # Generate embeddings and index
    for doc in tech_docs:
        # Generate embeddings
        title_embedding = model.encode(doc["title"]).tolist()
        content_embedding = model.encode(doc["content"]).tolist()
        
        doc["title_embedding"] = title_embedding
        doc["content_embedding"] = content_embedding
        
        # Index the document
        es.index(index="kb_tech-kb", id=doc["document_id"], body=doc)
    
    print("✅ Tech KB populated")

def populate_gtm_kb():
    """Populate GTM sub-KB with sample documents"""
    
    gtm_docs = [
        {
            "document_id": "gtm-001",
            "title": "Q4 2024 Product Launch Strategy",
            "content": "Comprehensive go-to-market strategy for our new AI-powered analytics platform. Includes target market analysis, competitive positioning, pricing strategy, channel partnerships, marketing campaigns, and success metrics. Covers enterprise and mid-market segments with focus on data-driven organizations in financial services and healthcare.",
            "metadata": {
                "file_type": "pptx",
                "s3_url": "s3://kb-docs/business/gtm/q4-launch-strategy.pptx",
                "author": "product-marketing",
                "tags": ["launch", "strategy", "ai", "analytics", "q4"],
                "classification": "confidential"
            },
            "entitlements": {
                "required_roles": ["manager", "director", "marketing"],
                "departments": ["marketing", "product"],
                "document_sensitivity": "confidential"
            },
            "created_at": "2024-08-01T16:45:00Z",
            "updated_at": "2024-08-10T11:30:00Z"
        },
        {
            "document_id": "gtm-002",
            "title": "Competitive Analysis Framework",
            "content": "Framework for conducting competitive analysis including competitor identification, feature comparison matrices, pricing analysis, market positioning maps, and SWOT analysis. Includes templates for battlecards, competitive response strategies, and win/loss analysis. Covers direct competitors, indirect competitors, and emerging threats.",
            "metadata": {
                "file_type": "docx",
                "s3_url": "s3://kb-docs/business/gtm/competitive-analysis.docx",
                "author": "strategy-team",
                "tags": ["competitive", "analysis", "framework", "positioning"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["manager", "marketing", "sales"],
                "departments": ["marketing", "sales", "strategy"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-07-20T13:20:00Z",
            "updated_at": "2024-08-08T09:15:00Z"
        },
        {
            "document_id": "gtm-003",
            "title": "Channel Partner Program Guide",
            "content": "Comprehensive guide for channel partner programs including partner onboarding, training programs, certification requirements, co-marketing opportunities, and incentive structures. Covers partner tiers, deal registration processes, and support resources. Includes templates for partner agreements and marketing materials.",
            "metadata": {
                "file_type": "pdf",
                "s3_url": "s3://kb-docs/business/gtm/partner-program.pdf",
                "author": "channels-team",
                "tags": ["partners", "channels", "program", "onboarding"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["manager", "sales", "partners"],
                "departments": ["sales", "marketing"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-06-15T10:00:00Z",
            "updated_at": "2024-07-25T14:45:00Z"
        }
    ]
    
    # Generate embeddings and index
    for doc in gtm_docs:
        title_embedding = model.encode(doc["title"]).tolist()
        content_embedding = model.encode(doc["content"]).tolist()
        
        doc["title_embedding"] = title_embedding
        doc["content_embedding"] = content_embedding
        
        es.index(index="kb_business-kb_gtm-kb", id=doc["document_id"], body=doc)
    
    print("✅ GTM KB populated")

def populate_roi_kb():
    """Populate ROI sub-KB with sample documents"""
    
    roi_docs = [
        {
            "document_id": "roi-001",
            "title": "Marketing Campaign ROI Analysis Template",
            "content": "Excel template for calculating return on investment for marketing campaigns. Includes formulas for customer acquisition cost (CAC), lifetime value (LTV), conversion rates, and attribution modeling. Covers multi-touch attribution, incrementality testing, and budget allocation optimization. Includes example calculations for digital marketing, events, and content marketing.",
            "metadata": {
                "file_type": "xlsx",
                "s3_url": "s3://kb-docs/business/roi/marketing-roi-template.xlsx",
                "author": "finance-team",
                "tags": ["roi", "marketing", "template", "cac", "ltv"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["manager", "finance", "marketing"],
                "departments": ["finance", "marketing"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-07-10T11:30:00Z",
            "updated_at": "2024-08-03T15:20:00Z"
        },
        {
            "document_id": "roi-002",
            "title": "Product Investment Business Case",
            "content": "Business case framework for product investments including market sizing, revenue projections, development costs, operational expenses, and sensitivity analysis. Covers NPV calculations, payback period analysis, and risk assessment. Includes templates for presenting investment proposals to executive team and board of directors.",
            "metadata": {
                "file_type": "docx",
                "s3_url": "s3://kb-docs/business/roi/investment-business-case.docx",
                "author": "product-team",
                "tags": ["investment", "business-case", "npv", "projections"],
                "classification": "confidential"
            },
            "entitlements": {
                "required_roles": ["director", "vp", "finance"],
                "departments": ["finance", "product", "strategy"],
                "document_sensitivity": "confidential"
            },
            "created_at": "2024-06-05T14:15:00Z",
            "updated_at": "2024-07-18T10:45:00Z"
        }
    ]
    
    # Generate embeddings and index
    for doc in roi_docs:
        title_embedding = model.encode(doc["title"]).tolist()
        content_embedding = model.encode(doc["content"]).tolist()
        
        doc["title_embedding"] = title_embedding
        doc["content_embedding"] = content_embedding
        
        es.index(index="kb_business-kb_roi-kb", id=doc["document_id"], body=doc)
    
    print("✅ ROI KB populated")

def populate_sales_kb():
    """Populate Sales sub-KB with sample documents"""
    
    sales_docs = [
        {
            "document_id": "sales-001",
            "title": "Sales Process Playbook",
            "content": "Comprehensive sales process covering lead qualification, discovery methodology, proposal development, objection handling, and closing techniques. Includes MEDDIC qualification framework, value-based selling approaches, and CRM workflow guidelines. Covers sales stages, exit criteria, and required documentation for each phase.",
            "metadata": {
                "file_type": "pdf",
                "s3_url": "s3://kb-docs/business/sales/sales-playbook.pdf",
                "author": "sales-ops",
                "tags": ["sales", "process", "playbook", "meddic", "qualification"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["sales", "manager"],
                "departments": ["sales"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-05-20T09:00:00Z",
            "updated_at": "2024-07-22T16:30:00Z"
        },
        {
            "document_id": "sales-002", 
            "title": "Territory Planning Guide",
            "content": "Guide for sales territory planning including account segmentation, territory mapping, quota setting, and resource allocation. Covers account prioritization frameworks, competitive landscape analysis, and growth opportunity identification. Includes templates for territory plans and account strategies.",
            "metadata": {
                "file_type": "docx",
                "s3_url": "s3://kb-docs/business/sales/territory-planning.docx",
                "author": "sales-management",
                "tags": ["territory", "planning", "accounts", "quota", "segmentation"],
                "classification": "internal"
            },
            "entitlements": {
                "required_roles": ["sales", "manager", "director"],
                "departments": ["sales"],
                "document_sensitivity": "internal"
            },
            "created_at": "2024-04-15T13:45:00Z",
            "updated_at": "2024-06-28T11:20:00Z"
        }
    ]
    
    # Generate embeddings and index
    for doc in sales_docs:
        title_embedding = model.encode(doc["title"]).tolist()
        content_embedding = model.encode(doc["content"]).tolist()
        
        doc["title_embedding"] = title_embedding
        doc["content_embedding"] = content_embedding
        
        es.index(index="kb_business-kb_sales-kb", id=doc["document_id"], body=doc)
    
    print("✅ Sales KB populated")

def main():
    """Main setup function"""
    print("🚀 Setting up KB system with sample data...")
    
    try:
        setup_indices()
        populate_kb_summaries()
        populate_tech_kb()
        populate_gtm_kb() 
        populate_roi_kb()
        populate_sales_kb()
        
        print("\n✅ Setup complete! Sample data loaded:")
        print("   📊 KB Summaries: 5 documents")
        print("   🔧 Tech KB: 3 documents")
        print("   🚀 GTM KB: 3 documents") 
        print("   💰 ROI KB: 2 documents")
        print("   💼 Sales KB: 2 documents")
        print("   📈 Total: 15 documents across 4 indices")
        
        # Refresh indices to make data searchable
        es.indices.refresh(index="_all")
        print("\n🔄 Indices refreshed - ready for search!")
        
    except Exception as e:
        print(f"❌ Setup failed: {e}")
        raise

if __name__ == "__main__":
    main()