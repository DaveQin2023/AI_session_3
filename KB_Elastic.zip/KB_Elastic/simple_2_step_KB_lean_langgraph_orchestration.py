"""
Lean LangGraph KB Orchestration System
Simplified version focusing on core two-step search functionality
"""

from typing import TypedDict, List, Dict, Any, Optional
from langgraph.graph import StateGraph, START, END
from langchain_core.messages import HumanMessage, AIMessage
from langchain_openai import ChatOpenAI
from sentence_transformers import SentenceTransformer
from elasticsearch import Elasticsearch
import json

# =============================================================================
# SIMPLIFIED STATE
# =============================================================================

class SimpleState(TypedDict):
    """Simplified state for the workflow"""
    # Input
    query: str
    user_roles: List[str]
    user_department: str
    
    # Step 1: Summary Search Results
    query_embedding: List[float]
    top_targets: List[Dict[str, Any]]
    selected_target: Optional[Dict[str, Any]]
    
    # Step 2: Document Search Results
    documents: List[Dict[str, Any]]
    
    # Output
    response: str
    sources: List[str]

# =============================================================================
# LEAN NODES
# =============================================================================

class EmbeddingNode:
    """Generate query embedding"""
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        self.model = SentenceTransformer(model_name)
    
    def __call__(self, state: SimpleState) -> SimpleState:
        embedding = self.model.encode(state["query"]).tolist()
        return {**state, "query_embedding": embedding}

class SummarySearchNode:
    """Search KB summaries to find best target"""
    def __init__(self, es_client: Elasticsearch):
        self.es = es_client
    
    def __call__(self, state: SimpleState) -> SimpleState:
        # Hybrid search on summaries
        search_query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "bool": {
                                "should": [
                                    # Text search
                                    {
                                        "multi_match": {
                                            "query": state["query"],
                                            "fields": ["name^3", "description^2", "summary^2", "keywords^1.5"],
                                            "type": "best_fields"
                                        }
                                    },
                                    # Vector search  
                                    {
                                        "script_score": {
                                            "query": {"match_all": {}},
                                            "script": {
                                                "source": "cosineSimilarity(params.query_vector, 'summary_embedding') + 1.0",
                                                "params": {"query_vector": state["query_embedding"]}
                                            },
                                            "boost": 2.0
                                        }
                                    }
                                ]
                            }
                        }
                    ],
                    "filter": [
                        {"terms": {"entitlements.required_roles": state["user_roles"]}},
                        {"terms": {"entitlements.departments": [state["user_department"]]}}
                    ]
                }
            },
            "_source": ["kb_id", "sub_kb_id", "name", "description", "level"],
            "size": 3
        }
        
        try:
            response = self.es.search(index="kb_summaries", body=search_query)
            targets = []
            
            for hit in response['hits']['hits']:
                source = hit['_source']
                # Generate index name
                if source.get('sub_kb_id'):
                    index_name = f"kb_{source['kb_id']}_{source['sub_kb_id']}"
                else:
                    index_name = f"kb_{source['kb_id']}"
                
                targets.append({
                    "kb_id": source['kb_id'],
                    "sub_kb_id": source.get('sub_kb_id'),
                    "name": source['name'],
                    "description": source['description'],
                    "score": hit['_score'],
                    "index_name": index_name
                })
            
            # Select best target (highest score)
            selected = targets[0] if targets else None
            
            return {
                **state, 
                "top_targets": targets,
                "selected_target": selected
            }
            
        except Exception as e:
            print(f"Summary search error: {e}")
            return {**state, "top_targets": [], "selected_target": None}

class DocumentSearchNode:
    """Search documents in selected KB"""
    def __init__(self, es_client: Elasticsearch):
        self.es = es_client
    
    def __call__(self, state: SimpleState) -> SimpleState:
        if not state["selected_target"]:
            return {**state, "documents": []}
        
        target = state["selected_target"]
        
        # Hybrid search in target index
        search_query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "bool": {
                                "should": [
                                    # Text search
                                    {
                                        "multi_match": {
                                            "query": state["query"],
                                            "fields": ["title^3", "content^1", "metadata.tags^2"],
                                            "type": "best_fields"
                                        }
                                    },
                                    # Vector search on content
                                    {
                                        "script_score": {
                                            "query": {"match_all": {}},
                                            "script": {
                                                "source": "cosineSimilarity(params.query_vector, 'content_embedding')",
                                                "params": {"query_vector": state["query_embedding"]}
                                            },
                                            "boost": 1.5
                                        }
                                    },
                                    # Vector search on title
                                    {
                                        "script_score": {
                                            "query": {"match_all": {}},
                                            "script": {
                                                "source": "cosineSimilarity(params.query_vector, 'title_embedding')",
                                                "params": {"query_vector": state["query_embedding"]}
                                            },
                                            "boost": 1.2
                                        }
                                    }
                                ]
                            }
                        }
                    ],
                    "filter": [
                        {"terms": {"entitlements.required_roles": state["user_roles"]}}
                    ]
                }
            },
            "highlight": {
                "fields": {
                    "content": {"fragment_size": 150, "number_of_fragments": 2}
                }
            },
            "_source": ["title", "content", "metadata.s3_url", "metadata.tags"],
            "size": 5
        }
        
        try:
            response = self.es.search(index=target["index_name"], body=search_query)
            documents = []
            
            for hit in response['hits']['hits']:
                source = hit['_source']
                highlight = hit.get('highlight', {})
                
                # Get content snippet
                if 'content' in highlight:
                    snippet = ' ... '.join(highlight['content'])
                else:
                    snippet = source.get('content', '')[:300] + '...'
                
                documents.append({
                    "title": source['title'],
                    "snippet": snippet,
                    "s3_url": source['metadata']['s3_url'],
                    "score": hit['_score'],
                    "tags": source['metadata'].get('tags', [])
                })
            
            return {**state, "documents": documents}
            
        except Exception as e:
            print(f"Document search error: {e}")
            return {**state, "documents": []}

class ResponseNode:
    """Generate final response using LLM"""
    def __init__(self, llm):
        self.llm = llm
    
    def __call__(self, state: SimpleState) -> SimpleState:
        if not state["documents"]:
            return {
                **state,
                "response": "No relevant documents found. Please try rephrasing your query or check your access permissions.",
                "sources": []
            }
        
        # Prepare context for LLM
        docs_context = []
        sources = []
        
        for i, doc in enumerate(state["documents"][:3]):  # Top 3 docs
            docs_context.append(f"""
Document {i+1}: {doc['title']}
Content: {doc['snippet']}
Tags: {', '.join(doc['tags'])}
""")
            sources.append(doc['s3_url'])
        
        # Simple prompt for response generation
        prompt = f"""
Answer this question based on the provided documents:

Question: {state['query']}

Relevant Documents:
{''.join(docs_context)}

Instructions:
1. Provide a direct, helpful answer
2. Reference specific documents when possible
3. If information is incomplete, say so
4. Keep response clear and concise

Answer:"""
        
        try:
            response = self.llm.invoke([HumanMessage(content=prompt)])
            return {
                **state,
                "response": response.content,
                "sources": sources
            }
        except Exception as e:
            return {
                **state,
                "response": f"Error generating response: {e}",
                "sources": sources
            }

# =============================================================================
# GRAPH CREATION
# =============================================================================

def create_lean_kb_graph(es_client: Elasticsearch, llm_model: str = "gpt-3.5-turbo"):
    """Create the simplified KB search graph"""
    
    # Initialize components
    llm = ChatOpenAI(model=llm_model, temperature=0)
    
    # Create nodes
    embedding_node = EmbeddingNode()
    summary_search_node = SummarySearchNode(es_client)
    document_search_node = DocumentSearchNode(es_client)
    response_node = ResponseNode(llm)
    
    # Build the graph
    workflow = StateGraph(SimpleState)
    
    # Add nodes
    workflow.add_node("embedding", embedding_node)
    workflow.add_node("summary_search", summary_search_node)
    workflow.add_node("document_search", document_search_node)
    workflow.add_node("response", response_node)
    
    # Define flow
    workflow.add_edge(START, "embedding")
    workflow.add_edge("embedding", "summary_search")
    workflow.add_edge("summary_search", "document_search")
    workflow.add_edge("document_search", "response")
    workflow.add_edge("response", END)
    
    return workflow.compile()

# =============================================================================
# USAGE FUNCTIONS
# =============================================================================

def search_kb(
    query: str,
    user_roles: List[str], 
    user_department: str,
    es_client: Elasticsearch
) -> Dict[str, Any]:
    """Simple function to search KB system"""
    
    # Create and run the graph
    app = create_lean_kb_graph(es_client)
    
    initial_state = {
        "query": query,
        "user_roles": user_roles,
        "user_department": user_department,
        "query_embedding": [],
        "top_targets": [],
        "selected_target": None,
        "documents": [],
        "response": "",
        "sources": []
    }
    
    # Execute the workflow
    result = app.invoke(initial_state)
    
    return {
        "query": result["query"],
        "response": result["response"],
        "sources": result["sources"],
        "kb_used": result["selected_target"]["name"] if result["selected_target"] else None,
        "target_info": result["selected_target"],
        "num_documents": len(result["documents"]),
        "all_targets": result["top_targets"]
    }

# =============================================================================
# TEST RUNNER
# =============================================================================

def test_kb_system():
    """Test the KB system with sample queries"""
    
    # Initialize Elasticsearch
    es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
    
    # Test queries with different user contexts
    test_cases = [
        {
            "query": "How do I set up a CI/CD pipeline?",
            "user_roles": ["engineer"],
            "user_department": "engineering",
            "expected_kb": "Technical Documentation"
        },
        {
            "query": "What's our go-to-market strategy for new products?",
            "user_roles": ["manager", "marketing"],
            "user_department": "marketing", 
            "expected_kb": "Go-to-Market Strategy"
        },
        {
            "query": "How do I calculate ROI for marketing campaigns?",
            "user_roles": ["manager", "finance"],
            "user_department": "marketing",
            "expected_kb": "ROI & Financial Analysis"
        },
        {
            "query": "What's the sales qualification process?",
            "user_roles": ["sales"],
            "user_department": "sales",
            "expected_kb": "Sales Operations"
        }
    ]
    
    print("🧪 Testing KB Orchestration System\n")
    
    for i, test in enumerate(test_cases, 1):
        print(f"{'='*60}")
        print(f"Test {i}: {test['query']}")
        print(f"User: {test['user_department']} department, roles: {test['user_roles']}")
        print(f"Expected KB: {test['expected_kb']}")
        print('='*60)
        
        try:
            result = search_kb(
                query=test["query"],
                user_roles=test["user_roles"], 
                user_department=test["user_department"],
                es_client=es
            )
            
            print(f"✅ Selected KB: {result['kb_used']}")
            print(f"📄 Documents found: {result['num_documents']}")
            print(f"🎯 Target info: {result['target_info']['kb_id'] if result['target_info'] else 'None'}:{result['target_info']['sub_kb_id'] if result['target_info'] and result['target_info']['sub_kb_id'] else 'main'}")
            print(f"\n💬 Response:\n{result['response'][:300]}...")
            print(f"\n📚 Sources: {len(result['sources'])} documents")
            
            if result['all_targets']:
                print(f"\n🔍 All targets considered:")
                for target in result['all_targets']:
                    print(f"   - {target['name']} (score: {target['score']:.2f})")
            
        except Exception as e:
            print(f"❌ Test failed: {e}")
        
        print(f"\n")

# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    import os
    
    # Set OpenAI API key if not already set
    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  Please set OPENAI_API_KEY environment variable")
        print("   export OPENAI_API_KEY='your-api-key'")
        exit(1)
    
    print("🚀 Starting KB System Test...")
    print("📋 Make sure you've run the sample data setup first!")
    print()
    
    test_kb_system()