import os
from dotenv import load_dotenv
from langchain_openai import OpenAI

load_dotenv()

api_key = os.getenv('OPENAI_API_KEY')
print(f"API Key: {api_key[:10]}..." if api_key else "No API key found")

try:
    llm = OpenAI(api_key=api_key)
    print("✅ OpenAI LLM initialized successfully!")
except Exception as e:
    print(f"❌ Error: {e}")