import React, { useState, useEffect, useRef } from 'react';

const ChatGPTStyleBankingChatbot = () => {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  // Backend URL - CHANGE THIS TO MATCH YOUR FLASK SERVER
  const BACKEND_URL = 'http://localhost:5000';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (inputMessage.trim()) {
      const newMessage = {
        id: messages.length + 1,
        type: 'user',
        text: inputMessage
      };
      setMessages([...messages, newMessage]);
      const currentInput = inputMessage;
      setInputMessage('');
      setIsTyping(true);
      
      // Auto-resize textarea
      if (textareaRef.current) {
        textareaRef.current.style.height = '24px';
      }
      
      try {
        console.log('Sending message to:', `${BACKEND_URL}/api/chat`);
        
        // Call the Flask agent API
        const response = await fetch(`${BACKEND_URL}/api/chat`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: currentInput
          }),
        });
        
        console.log('Response status:', response.status);
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('Response data:', data);
        
        setIsTyping(false);
        
        if (data.success) {
          const botResponse = {
            id: messages.length + 2,
            type: 'assistant',
            text: data.answer,
            source: data.source || null,
            file_name: data.file_name || null,
            document_url: data.document_url || null,
            download_url: data.download_url || null,
            confidence: data.confidence || 'medium',
            reasoning: data.reasoning || '',
            content_preview: data.content_preview || ''
          };
          setMessages(prev => [...prev, botResponse]);
        } else {
          // Fallback response if API fails
          const errorResponse = {
            id: messages.length + 2,
            type: 'assistant',
            text: data.error || "I apologize, but I'm having trouble accessing the knowledge base right now. Please try again later."
          };
          setMessages(prev => [...prev, errorResponse]);
        }
      } catch (error) {
        console.error('Error calling agent API:', error);
        setIsTyping(false);
        
        // Fallback response for network errors
        const fallbackResponse = {
          id: messages.length + 2,
          type: 'assistant',
          text: `I'm currently unable to connect to the knowledge base at ${BACKEND_URL}. Please check if the Flask backend is running and try again.`
        };
        setMessages(prev => [...prev, fallbackResponse]);
      }
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e) => {
    setInputMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = '24px';
    textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const sidebarItems = [
    { icon: '💬', text: 'New chat', isNew: true },
    { icon: '🔍', text: 'Search chats' },
    { icon: '💡', text: 'IQ Help Center' },
    { icon: '📖', text: 'Product Reference' },
    { icon: '📋', text: 'Account Summary' },
    { icon: '📊', text: 'Transaction History' }
  ];

  const recentChats = [];

  const styles = {
    container: {
      display: 'flex',
      height: '100vh',
      width: '100vw',
      backgroundColor: '#212121',
      color: '#e4e4e7',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      overflow: 'hidden'
    },
    sidebar: {
      width: '260px',
      backgroundColor: '#171717',
      borderRight: '1px solid #3f3f46',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0
    },
    sidebarHeader: {
      padding: '12px 16px',
      borderBottom: '1px solid #3f3f46',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    },
    logo: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: '18px',
      fontWeight: '600'
    },
    modelSelector: {
      backgroundColor: '#2d2d30',
      border: '1px solid #3f3f46',
      borderRadius: '6px',
      padding: '6px 12px',
      color: '#e4e4e7',
      fontSize: '14px',
      cursor: 'pointer'
    },
    sidebarContent: {
      flex: 1,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column'
    },
    sidebarSection: {
      padding: '16px'
    },
    sidebarItem: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      padding: '8px 12px',
      borderRadius: '8px',
      cursor: 'pointer',
      fontSize: '14px',
      marginBottom: '4px',
      transition: 'background-color 0.2s',
      color: '#a1a1aa'
    },
    sidebarItemHover: {
      backgroundColor: '#2d2d30'
    },
    newChatItem: {
      backgroundColor: '#2d2d30',
      color: '#e4e4e7',
      fontWeight: '500'
    },
    recentChatsSection: {
      flex: 1,
      overflow: 'auto',
      padding: '0 16px'
    },
    recentChatsTitle: {
      fontSize: '12px',
      fontWeight: '600',
      color: '#71717a',
      marginBottom: '8px',
      textTransform: 'uppercase',
      letterSpacing: '0.5px'
    },
    recentChatItem: {
      padding: '8px 12px',
      borderRadius: '8px',
      cursor: 'pointer',
      fontSize: '14px',
      marginBottom: '2px',
      color: '#a1a1aa',
      transition: 'background-color 0.2s',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    },
    sidebarFooter: {
      padding: '16px',
      borderTop: '1px solid #3f3f46'
    },
    upgradeButton: {
      width: '100%',
      padding: '8px 16px',
      backgroundColor: 'transparent',
      border: '1px solid #3f3f46',
      borderRadius: '8px',
      color: '#a1a1aa',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s'
    },
    mainContent: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#212121'
    },
    header: {
      padding: '12px 24px',
      borderBottom: '1px solid #3f3f46',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#212121'
    },
    headerTitle: {
      fontSize: '24px',
      fontWeight: '600',
      color: '#e4e4e7'
    },
    messagesContainer: {
      flex: 1,
      overflow: 'auto',
      padding: '0',
      position: 'relative'
    },
    emptyState: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      textAlign: 'center',
      padding: '0 24px'
    },
    emptyStateTitle: {
      fontSize: '28px',
      fontWeight: '400',
      color: '#e4e4e7',
      marginBottom: '16px'
    },
    emptyStateSubtitle: {
      fontSize: '16px',
      color: '#a1a1aa',
      marginBottom: '32px'
    },
    emptyStateExamples: {
      textAlign: 'left',
      color: '#71717a'
    },
    messageGroup: {
      borderBottom: '1px solid #3f3f46'
    },
    messageContainer: {
      maxWidth: '768px',
      margin: '0 auto',
      padding: '24px'
    },
    messageHeader: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '16px',
      marginBottom: '16px'
    },
    avatar: {
      width: '32px',
      height: '32px',
      borderRadius: '4px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '16px',
      flexShrink: 0,
      marginTop: '4px'
    },
    userAvatar: {
      backgroundColor: '#10a37f',
      color: 'white'
    },
    assistantAvatar: {
      backgroundColor: '#6366f1',
      color: 'white'
    },
    messageContent: {
      flex: 1,
      fontSize: '16px',
      lineHeight: '1.6',
      color: '#e4e4e7'
    },
    messageLabel: {
      fontSize: '14px',
      fontWeight: '600',
      color: '#e4e4e7',
      marginBottom: '8px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    },
    copyButton: {
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      border: '1px solid rgba(255, 255, 255, 0.2)',
      borderRadius: '6px',
      padding: '4px 8px',
      fontSize: '12px',
      color: '#e4e4e7',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      marginLeft: '8px'
    },
    assistantMessageBox: {
      backgroundColor: 'rgba(55, 65, 81, 0.6)',
      border: '1px solid rgba(75, 85, 99, 0.4)',
      borderRadius: '8px',
      padding: '16px',
      marginTop: '4px',
      lineHeight: '1.6'
    },
    sourceContainer: {
      marginTop: '12px',
      padding: '12px 16px',
      backgroundColor: 'rgba(255, 255, 255, 0.05)',
      borderRadius: '8px',
      border: '1px solid #3f3f46',
      fontSize: '14px'
    },
    sourceTitle: {
      fontWeight: '600',
      marginBottom: '12px',
      color: '#a1a1aa',
      display: 'flex',
      alignItems: 'center',
      gap: '6px'
    },
    documentActions: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '8px',
      marginBottom: '12px'
    },
    actionButton: {
      backgroundColor: 'rgba(59, 130, 246, 0.1)',
      border: '1px solid rgba(59, 130, 246, 0.3)',
      borderRadius: '6px',
      padding: '6px 12px',
      fontSize: '12px',
      color: '#60a5fa',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '4px'
    },
    downloadButton: {
      backgroundColor: 'rgba(34, 197, 94, 0.1)',
      border: '1px solid rgba(34, 197, 94, 0.3)',
      color: '#22c55e'
    },
    sourceDocument: {
      color: '#e4e4e7',
      fontSize: '13px',
      fontFamily: 'monospace',
      backgroundColor: 'rgba(255, 255, 255, 0.1)',
      padding: '8px 12px',
      borderRadius: '6px',
      display: 'block',
      marginBottom: '8px',
      border: '1px solid rgba(255, 255, 255, 0.1)'
    },
    confidenceBadge: {
      display: 'inline-block',
      padding: '2px 8px',
      borderRadius: '12px',
      fontSize: '11px',
      fontWeight: '500',
      marginLeft: '8px'
    },
    confidenceHigh: {
      backgroundColor: 'rgba(34, 197, 94, 0.2)',
      color: '#22c55e',
      border: '1px solid rgba(34, 197, 94, 0.3)'
    },
    confidenceMedium: {
      backgroundColor: 'rgba(251, 191, 36, 0.2)',
      color: '#fbbf24',
      border: '1px solid rgba(251, 191, 36, 0.3)'
    },
    confidenceLow: {
      backgroundColor: 'rgba(239, 68, 68, 0.2)',
      color: '#ef4444',
      border: '1px solid rgba(239, 68, 68, 0.3)'
    },
    typingIndicator: {
      borderBottom: '1px solid #3f3f46'
    },
    typingContainer: {
      maxWidth: '768px',
      margin: '0 auto',
      padding: '24px'
    },
    typingContent: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '16px'
    },
    typingText: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: '16px',
      color: '#71717a',
      marginTop: '4px'
    },
    inputContainer: {
      padding: '24px',
      backgroundColor: '#212121'
    },
    inputWrapper: {
      maxWidth: '768px',
      margin: '0 auto',
      position: 'relative',
      backgroundColor: '#2d2d30',
      borderRadius: '12px',
      border: '1px solid #3f3f46',
      paddingRight: '52px'
    },
    textarea: {
      width: '100%',
      minHeight: '24px',
      maxHeight: '200px',
      padding: '12px 16px',
      backgroundColor: 'transparent',
      border: 'none',
      outline: 'none',
      color: '#e4e4e7',
      fontSize: '16px',
      fontFamily: 'inherit',
      resize: 'none',
      lineHeight: '1.5'
    },
    sendButton: {
      position: 'absolute',
      right: '8px',
      bottom: '8px',
      width: '36px',
      height: '36px',
      backgroundColor: '#e4e4e7',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '16px',
      color: '#212121',
      transition: 'all 0.2s'
    },
    sendButtonDisabled: {
      backgroundColor: '#3f3f46',
      color: '#71717a',
      cursor: 'not-allowed'
    }
  };

  const handleCopyMessage = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      // You could add a toast notification here
      console.log('Message copied to clipboard');
      // Optional: Show a temporary "Copied!" message
    }).catch(err => {
      console.error('Failed to copy text: ', err);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    });
  };

  // OPTION 2 IMPLEMENTATION: Use URLs from API response
  const handleViewDocument = (message) => {
    if (message.document_url) {
      const fullUrl = `${BACKEND_URL}${message.document_url}`;
      console.log('Opening document URL:', fullUrl);
      
      // Try to open the document
      const newWindow = window.open(fullUrl, '_blank');
      
      // Check if popup was blocked
      if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
        alert(`Popup blocked! Please allow popups or manually visit: ${fullUrl}`);
      }
    } else {
      alert('Document viewing is not available - no document URL provided by the backend');
    }
  };

  const handleDownloadDocument = (message) => {
    if (message.download_url) {
      const fullUrl = `${BACKEND_URL}${message.download_url}`;
      console.log('Opening download URL:', fullUrl);
      
      // Create temporary link for download
      const link = document.createElement('a');
      link.href = fullUrl;
      link.download = message.file_name || 'document';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } else {
      alert('Document download is not available - no download URL provided by the backend');
    }
  };

  const handleCopyDocumentUrl = (message) => {
    if (message.document_url) {
      const fullUrl = `${BACKEND_URL}${message.document_url}`;
      navigator.clipboard.writeText(fullUrl).then(() => {
        alert('Document URL copied to clipboard!');
      }).catch(() => {
        alert(`Copy this URL manually: ${fullUrl}`);
      });
    } else {
      alert('No document URL available to copy');
    }
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        <div style={styles.sidebarHeader}>
          {/* Header section removed */}
        </div>
        
        <div style={styles.sidebarContent}>
          <div style={styles.sidebarSection}>
            {sidebarItems.slice(0, 2).map((item, index) => (
              <div
                key={index}
                style={{
                  ...styles.sidebarItem,
                  ...(item.isNew ? styles.newChatItem : {})
                }}
                onMouseEnter={(e) => !item.isNew && (e.target.style.backgroundColor = '#2d2d30')}
                onMouseLeave={(e) => !item.isNew && (e.target.style.backgroundColor = 'transparent')}
              >
                <span>{item.icon}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>

          <div style={styles.sidebarSection}>
            {sidebarItems.slice(2).map((item, index) => (
              <div
                key={index + 2}
                style={styles.sidebarItem}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#2d2d30'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                <span>{item.icon}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>

          <div style={styles.recentChatsSection}>
            {/* Recent chats section removed */}
          </div>
        </div>

        <div style={styles.sidebarFooter}>
          <button 
            style={styles.upgradeButton}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#2d2d30';
              e.target.style.borderColor = '#52525b';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = 'transparent';
              e.target.style.borderColor = '#3f3f46';
            }}
          >
            🔧 Knowledge Tools
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        <div style={styles.header}>
          <div style={styles.headerTitle}>Knowledge Base Assistant</div>
        </div>

        <div style={styles.messagesContainer}>
          {messages.length === 0 ? (
            <div style={styles.emptyState}>
              <div style={styles.emptyStateTitle}>What can I help you with today?</div>
              <div style={styles.emptyStateSubtitle}>Ask me about our banking documents and policies</div>
              <div style={styles.emptyStateExamples}>
                <p><strong>Try asking:</strong></p>
                <ul>
                  <li>"How do I apply for a loan?"</li>
                  <li>"How do I change my ATM PIN?"</li>
                  <li>"What are your security guidelines?"</li>
                  <li>"Tell me about your savings accounts"</li>
                </ul>
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div key={message.id} style={styles.messageGroup}>
                  <div style={styles.messageContainer}>
                    <div style={styles.messageHeader}>
                      <div style={{
                        ...styles.avatar,
                        ...(message.type === 'user' ? styles.userAvatar : styles.assistantAvatar)
                      }}>
                        {message.type === 'user' ? '👤' : '🏦'}
                      </div>
                      <div style={styles.messageContent}>
                        <div style={styles.messageLabel}>
                          {message.type === 'user' ? 'You' : 'Knowledge Base Assistant'}
                          {message.type === 'assistant' && (
                            <div style={{ display: 'flex', alignItems: 'center' }}>
                              {message.confidence && (
                                <span style={{
                                  ...styles.confidenceBadge,
                                  ...(message.confidence === 'high' ? styles.confidenceHigh :
                                      message.confidence === 'medium' ? styles.confidenceMedium :
                                      styles.confidenceLow)
                                }}>
                                  {message.confidence === 'high' ? '✓' : 
                                   message.confidence === 'medium' ? '⚠' : '!'}
                                  {message.confidence}
                                </span>
                              )}
                              <button
                                style={styles.copyButton}
                                onClick={() => handleCopyMessage(message.text)}
                                onMouseEnter={(e) => {
                                  e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
                                }}
                                onMouseLeave={(e) => {
                                  e.target.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                                }}
                                title="Copy message"
                              >
                                📋
                              </button>
                            </div>
                          )}
                        </div>
                        <div style={message.type === 'assistant' ? styles.assistantMessageBox : {}}>
                          {message.text}
                        </div>
                        
                        {/* Source Information with Document Actions */}
                        {message.source && (
                          <div style={styles.sourceContainer}>
                            <div style={styles.sourceTitle}>
                              📄 Source Document
                            </div>
                            
                            <div style={styles.sourceDocument}>
                              <strong>Document:</strong> {message.source}
                              {message.file_name && (
                                <div><strong>File:</strong> {message.file_name}</div>
                              )}
                            </div>

                            {/* Document Action Buttons */}
                            <div style={styles.documentActions}>
                              <button
                                style={styles.actionButton}
                                onClick={() => handleViewDocument(message)}
                                onMouseEnter={(e) => {
                                  e.target.style.backgroundColor = 'rgba(59, 130, 246, 0.2)';
                                }}
                                onMouseLeave={(e) => {
                                  e.target.style.backgroundColor = 'rgba(59, 130, 246, 0.1)';
                                }}
                                title="View document in browser"
                              >
                                👁 View Document
                              </button>

                              <button
                                style={{...styles.actionButton, ...styles.downloadButton}}
                                onClick={() => handleDownloadDocument(message)}
                                onMouseEnter={(e) => {
                                  e.target.style.backgroundColor = 'rgba(34, 197, 94, 0.2)';
                                }}
                                onMouseLeave={(e) => {
                                  e.target.style.backgroundColor = 'rgba(34, 197, 94, 0.1)';
                                }}
                                title="Download document"
                              >
                                ⬇ Download
                              </button>

                              <button
                                style={styles.actionButton}
                                onClick={() => handleCopyDocumentUrl(message)}
                                onMouseEnter={(e) => {
                                  e.target.style.backgroundColor = 'rgba(59, 130, 246, 0.2)';
                                }}
                                onMouseLeave={(e) => {
                                  e.target.style.backgroundColor = 'rgba(59, 130, 246, 0.1)';
                                }}
                                title="Copy document URL"
                              >
                                📋 Copy URL
                              </button>
                            </div>

                            {message.reasoning && (
                              <div style={{
                                marginTop: '8px',
                                fontSize: '12px',
                                color: '#71717a',
                                fontStyle: 'italic'
                              }}>
                                <strong>Why this document:</strong> {message.reasoning}
                              </div>
                            )}

                            {message.content_preview && (
                              <div style={{
                                marginTop: '8px',
                                fontSize: '12px',
                                color: '#71717a',
                                backgroundColor: 'rgba(255, 255, 255, 0.05)',
                                padding: '8px',
                                borderRadius: '4px',
                                borderLeft: '3px solid #3f3f46'
                              }}>
                                <strong>Content preview:</strong> {message.content_preview}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div style={styles.typingIndicator}>
                  <div style={styles.typingContainer}>
                    <div style={styles.typingContent}>
                      <div style={{...styles.avatar, ...styles.assistantAvatar}}>
                        🏦
                      </div>
                      <div style={styles.typingText}>
                        <span>Knowledge Base Assistant is analyzing documents...</span>
                        <div style={{display: 'flex', gap: '4px'}}>
                          <div style={{
                            width: '4px',
                            height: '4px',
                            backgroundColor: '#71717a',
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite'
                          }}></div>
                          <div style={{
                            width: '4px',
                            height: '4px',
                            backgroundColor: '#71717a',
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite 0.5s'
                          }}></div>
                          <div style={{
                            width: '4px',
                            height: '4px',
                            backgroundColor: '#71717a',
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite 1s'
                          }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div style={styles.inputContainer}>
          <div style={styles.inputWrapper}>
            <textarea
              ref={textareaRef}
              value={inputMessage}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="Ask about loans, security, account management, ATM services..."
              style={styles.textarea}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim()}
              style={{
                ...styles.sendButton,
                ...(inputMessage.trim() ? {} : styles.sendButtonDisabled)
              }}
            >
              ↑
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatGPTStyleBankingChatbot;