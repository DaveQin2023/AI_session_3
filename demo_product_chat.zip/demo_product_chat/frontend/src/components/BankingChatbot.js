
import React, { useState, useEffect, useRef } from 'react';

const ChatGPTStyleBankingChatbot = () => {
  const [messages, setMessages] = useState([]);

  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      const newMessage = {
        id: messages.length + 1,
        type: 'user',
        text: inputMessage
      };
      setMessages([...messages, newMessage]);
      setInputMessage('');
      setIsTyping(true);
      
      // Auto-resize textarea
      if (textareaRef.current) {
        textareaRef.current.style.height = '24px';
      }
      
      // Simulate assistant response
      setTimeout(() => {
        setIsTyping(false);
        const responses = [
          "Thank you for providing that information. Let me verify your details in our system.",
          "Great! I can see your account. Now I'll guide you through the PIN change process step by step.",
          "For security, you'll receive an OTP on your registered mobile number. Please check your phone.",
          "Perfect! Your request has been processed. Is there anything else I can help you with today?"
        ];
        
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        const botResponse = {
          id: messages.length + 2,
          type: 'assistant',
          text: randomResponse
        };
        setMessages(prev => [...prev, botResponse]);
      }, 1500);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleInputChange = (e) => {
    setInputMessage(e.target.value);
    
    // Auto-resize textarea
    const textarea = e.target;
    textarea.style.height = '24px';
    textarea.style.height = Math.min(textarea.scrollHeight, 200) + 'px';
  };

  const sidebarItems = [
    { icon: '💬', text: 'New chat', isNew: true },
    { icon: '🔍', text: 'Search chats' },
    { icon: '💡', text: 'IQ Help Center' },
    { icon: '📖', text: 'Product Reference' },
    { icon: '📋', text: 'Account Summary' },
    { icon: '📊', text: 'Transaction History' }
  ];

  const recentChats = [];

  const styles = {
    container: {
      display: 'flex',
      height: '100vh',
      width: '100vw',
      backgroundColor: '#212121',
      color: '#e4e4e7',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      overflow: 'hidden'
    },
    sidebar: {
      width: '260px',
      backgroundColor: '#171717',
      borderRight: '1px solid #3f3f46',
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0
    },
    sidebarHeader: {
      padding: '12px 16px',
      borderBottom: '1px solid #3f3f46',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    },
    logo: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: '18px',
      fontWeight: '600'
    },
    modelSelector: {
      backgroundColor: '#2d2d30',
      border: '1px solid #3f3f46',
      borderRadius: '6px',
      padding: '6px 12px',
      color: '#e4e4e7',
      fontSize: '14px',
      cursor: 'pointer'
    },
    sidebarContent: {
      flex: 1,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column'
    },
    sidebarSection: {
      padding: '16px'
    },
    sidebarItem: {
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      padding: '8px 12px',
      borderRadius: '8px',
      cursor: 'pointer',
      fontSize: '14px',
      marginBottom: '4px',
      transition: 'background-color 0.2s',
      color: '#a1a1aa'
    },
    sidebarItemHover: {
      backgroundColor: '#2d2d30'
    },
    newChatItem: {
      backgroundColor: '#2d2d30',
      color: '#e4e4e7',
      fontWeight: '500'
    },
    recentChatsSection: {
      flex: 1,
      overflow: 'auto',
      padding: '0 16px'
    },
    recentChatsTitle: {
      fontSize: '12px',
      fontWeight: '600',
      color: '#71717a',
      marginBottom: '8px',
      textTransform: 'uppercase',
      letterSpacing: '0.5px'
    },
    recentChatItem: {
      padding: '8px 12px',
      borderRadius: '8px',
      cursor: 'pointer',
      fontSize: '14px',
      marginBottom: '2px',
      color: '#a1a1aa',
      transition: 'background-color 0.2s',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    },
    sidebarFooter: {
      padding: '16px',
      borderTop: '1px solid #3f3f46'
    },
    upgradeButton: {
      width: '100%',
      padding: '8px 16px',
      backgroundColor: 'transparent',
      border: '1px solid #3f3f46',
      borderRadius: '8px',
      color: '#a1a1aa',
      fontSize: '14px',
      cursor: 'pointer',
      transition: 'all 0.2s'
    },
    mainContent: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      backgroundColor: '#212121'
    },
    header: {
      padding: '12px 24px',
      borderBottom: '1px solid #3f3f46',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#212121'
    },
    headerTitle: {
      fontSize: '24px',
      fontWeight: '600',
      color: '#e4e4e7'
    },
    messagesContainer: {
      flex: 1,
      overflow: 'auto',
      padding: '0',
      position: 'relative'
    },
    emptyState: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100%',
      textAlign: 'center',
      padding: '0 24px'
    },
    emptyStateTitle: {
      fontSize: '28px',
      fontWeight: '400',
      color: '#e4e4e7',
      marginBottom: '32px'
    },
    messageGroup: {
      borderBottom: '1px solid #3f3f46'
    },
    messageContainer: {
      maxWidth: '768px',
      margin: '0 auto',
      padding: '24px'
    },
    messageHeader: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '16px',
      marginBottom: '16px'
    },
    avatar: {
      width: '32px',
      height: '32px',
      borderRadius: '4px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '16px',
      flexShrink: 0,
      marginTop: '4px'
    },
    userAvatar: {
      backgroundColor: '#10a37f',
      color: 'white'
    },
    assistantAvatar: {
      backgroundColor: '#6366f1',
      color: 'white'
    },
    messageContent: {
      flex: 1,
      fontSize: '16px',
      lineHeight: '1.6',
      color: '#e4e4e7'
    },
    messageLabel: {
      fontSize: '14px',
      fontWeight: '600',
      color: '#e4e4e7',
      marginBottom: '8px'
    },
    typingIndicator: {
      borderBottom: '1px solid #3f3f46'
    },
    typingContainer: {
      maxWidth: '768px',
      margin: '0 auto',
      padding: '24px'
    },
    typingContent: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '16px'
    },
    typingText: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: '16px',
      color: '#71717a',
      marginTop: '4px'
    },
    inputContainer: {
      padding: '24px',
      backgroundColor: '#212121'
    },
    inputWrapper: {
      maxWidth: '768px',
      margin: '0 auto',
      position: 'relative',
      backgroundColor: '#2d2d30',
      borderRadius: '12px',
      border: '1px solid #3f3f46',
      paddingRight: '52px'
    },
    textarea: {
      width: '100%',
      minHeight: '24px',
      maxHeight: '200px',
      padding: '12px 16px',
      backgroundColor: 'transparent',
      border: 'none',
      outline: 'none',
      color: '#e4e4e7',
      fontSize: '16px',
      fontFamily: 'inherit',
      resize: 'none',
      lineHeight: '1.5'
    },
    sendButton: {
      position: 'absolute',
      right: '8px',
      bottom: '8px',
      width: '36px',
      height: '36px',
      backgroundColor: '#e4e4e7',
      border: 'none',
      borderRadius: '8px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '16px',
      color: '#212121',
      transition: 'all 0.2s'
    },
    sendButtonDisabled: {
      backgroundColor: '#3f3f46',
      color: '#71717a',
      cursor: 'not-allowed'
    }
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        <div style={styles.sidebarHeader}>
          {/* Header section removed */}
        </div>
        
        <div style={styles.sidebarContent}>
          <div style={styles.sidebarSection}>
            {sidebarItems.slice(0, 2).map((item, index) => (
              <div
                key={index}
                style={{
                  ...styles.sidebarItem,
                  ...(item.isNew ? styles.newChatItem : {})
                }}
                onMouseEnter={(e) => !item.isNew && (e.target.style.backgroundColor = '#2d2d30')}
                onMouseLeave={(e) => !item.isNew && (e.target.style.backgroundColor = 'transparent')}
              >
                <span>{item.icon}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>

          <div style={styles.sidebarSection}>
            {sidebarItems.slice(2).map((item, index) => (
              <div
                key={index + 2}
                style={styles.sidebarItem}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#2d2d30'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                <span>{item.icon}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>

          <div style={styles.recentChatsSection}>
            {/* Recent chats section removed */}
          </div>
        </div>

        <div style={styles.sidebarFooter}>
          <button 
            style={styles.upgradeButton}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#2d2d30';
              e.target.style.borderColor = '#52525b';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = 'transparent';
              e.target.style.borderColor = '#3f3f46';
            }}
          >
            🔧 Banking Tools
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        <div style={styles.header}>
          <div style={styles.headerTitle}>Knowledge Base Assistant</div>
        </div>

        <div style={styles.messagesContainer}>
          {messages.length === 0 ? (
            <div style={styles.emptyState}>
              <div style={styles.emptyStateTitle}>What can I help you?</div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div key={message.id} style={styles.messageGroup}>
                  <div style={styles.messageContainer}>
                    <div style={styles.messageHeader}>
                      <div style={{
                        ...styles.avatar,
                        ...(message.type === 'user' ? styles.userAvatar : styles.assistantAvatar)
                      }}>
                        {message.type === 'user' ? '👤' : '🏦'}
                      </div>
                      <div style={styles.messageContent}>
                        <div style={styles.messageLabel}>
                          {message.type === 'user' ? 'You' : 'Knowledge Base Assistant'}
                        </div>
                        <div>{message.text}</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div style={styles.typingIndicator}>
                  <div style={styles.typingContainer}>
                    <div style={styles.typingContent}>
                      <div style={{...styles.avatar, ...styles.assistantAvatar}}>
                        🏦
                      </div>
                      <div style={styles.typingText}>
                        <span>Knowledge Base Assistant is typing</span>
                        <div style={{display: 'flex', gap: '4px'}}>
                          <div style={{
                            width: '4px',
                            height: '4px',
                            backgroundColor: '#71717a',
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite'
                          }}></div>
                          <div style={{
                            width: '4px',
                            height: '4px',
                            backgroundColor: '#71717a',
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite 0.5s'
                          }}></div>
                          <div style={{
                            width: '4px',
                            height: '4px',
                            backgroundColor: '#71717a',
                            borderRadius: '50%',
                            animation: 'pulse 1.5s infinite 1s'
                          }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div style={styles.inputContainer}>
          <div style={styles.inputWrapper}>
            <textarea
              ref={textareaRef}
              value={inputMessage}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="Ask anything"
              style={styles.textarea}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputMessage.trim()}
              style={{
                ...styles.sendButton,
                ...(inputMessage.trim() ? {} : styles.sendButtonDisabled)
              }}
            >
              ↑
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatGPTStyleBankingChatbot;