import ChatGPTStyleBankingChatbot from './components/ChatGPTStyleBankingChatbot';

function App() {
  return (
    <div className="App">
      <ChatGPTStyleBankingChatbot />
    </div>
  );
}

export default App;