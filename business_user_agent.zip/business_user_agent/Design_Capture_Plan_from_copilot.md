# Design Capture Plan: Automatic Capture of the Business User's Design from Code Diff + Prompts

> Companion to [Guarded_Business-User_Agent_Workflow_from_copilot.md](Guarded_Business-User_Agent_Workflow_from_copilot.md) (v2.5) — this file specifies the **capture subsystem** in implementable detail.
> Target environment: **VS Code with GitHub Copilot**, Windows (PowerShell scripts; per-OS overrides available if that changes).
> All documentation claims verified against primary sources on **2026-08-09**: [VS Code agent hooks (Preview)](https://code.visualstudio.com/docs/agent-customization/hooks), [VS Code prompt files](https://code.visualstudio.com/docs/copilot/customization/prompt-files), [git-add](https://git-scm.com/docs/git-add), [gitglossary pathspec](https://git-scm.com/docs/gitglossary#Documentation/gitglossary.txt-aiddefpathspecapathspec).

## 0. Objective and the key insight

Capture the Business User's design **automatically and in full detail** from two sources:

1. **The code diff** — the design *as built* (JSX/HTML/CSS literally is the layout, colors, structure).
2. **Her chat prompts to Copilot** — her design ideas **verbatim, in her own words** ("make the header blue, move the search box up…").

**Why both sources are required — provably, not stylistically:**

- The diff shows only the **final state**. If she tried a red header, hated it, and settled on blue, the diff says "blue" — the exploration is invisible.
- The prompt stream shows the **iteration path** — the design reasoning as it happened.

Detailed understanding = both sources, chronologically aligned. Capture is deterministic (no AI); narration/correlation is LLM-drafted and human-reviewed. That boundary is kept visible everywhere in this plan.

## 1. Component 1 — Prompt capture (automatic, fires on every prompt she types)

### File: `.github/hooks/capture.json`

```json
{
  "hooks": {
    "UserPromptSubmit": [
      {
        "type": "command",
        "command": "./scripts/capture-prompt.sh",
        "windows": "powershell -NoProfile -File scripts\\capture-prompt.ps1"
      }
    ],
    "Stop": [
      {
        "type": "command",
        "command": "./scripts/capture-session.sh",
        "windows": "powershell -NoProfile -File scripts\\capture-session.ps1"
      }
    ]
  }
}
```

### File: `scripts/capture-prompt.ps1`

```powershell
$in  = [Console]::In.ReadToEnd() | ConvertFrom-Json
$dir = "docs/agent/sessions/_capture/$(Get-Date -Format yyyy-MM-dd)"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
@{ ts = $in.timestamp; session = $in.session_id; prompt = $in.prompt } |
  ConvertTo-Json -Compress | Add-Content "$dir/ideas.jsonl"
exit 0
```

### Proof, field by field (all from the [hooks page](https://code.visualstudio.com/docs/agent-customization/hooks), fetched 2026-08-09)

| Claim | Source statement |
|---|---|
| `UserPromptSubmit` is a real event | Event table: "UserPromptSubmit — User submits a prompt — Audit user requests, inject system context" |
| Hooks receive JSON on stdin | "VS Code runs your command and passes information about the event as a JSON object on standard input (stdin)" |
| `timestamp`, `session_id` are input fields | "Common input fields" table (`session_id` marked optional) |
| `prompt` is an input field | Named verbatim in the docs: "Prefer the documented hook input fields (`tool_name`, `tool_input`, `prompt`, and so on)" |
| `windows` per-OS command override | "OS-specific commands" section with `windows`/`linux`/`osx` properties |
| Exit 0 = success | Exit-code table: "0 — Success: parse stdout as JSON" |
| Execution is guaranteed, not advisory | "hooks execute your code at specific lifecycle points with guaranteed outcomes" |
| Hook file location | "Workspace: `.github/hooks/*.json`" |

**Result:** every idea she types is on disk, timestamped, in her own words — zero clicks, zero AI.

**Why not the full transcript:** the docs also offer `transcript_path` (whole conversation), but warn verbatim: "The transcript file format is not a stable hook API and may change in future VS Code releases." This plan uses the stable `prompt` field only.

## 2. Component 2 — Diff capture (automatic, fires when the session ends)

### File: `scripts/capture-session.ps1` (wired to the `Stop` hook above — event table: "Stop — Agent session ends — Generate reports, cleanup resources")

```powershell
$dir = "docs/agent/sessions/_capture/$(Get-Date -Format yyyy-MM-dd)"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
git add -N .
git diff --output="$dir/session-diff.patch" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
git diff --stat --output="$dir/diff-stat.txt" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
exit 0
```

> **Fixed after empirical testing (v1.1, 2026-08-10):** the first version of this script used PowerShell `>` redirection. On Windows PowerShell 5.1, `>` writes **UTF-16LE**, and `git apply` rejects such patches — proven in the pilot: the redirect-produced file began with bytes `255,254` (UTF-16LE BOM) and `git apply` failed with "No valid patches in input" (exit 128). Git's own `--output=<file>` option lets git write the file itself, producing a valid ASCII patch (first bytes `100,105,102,102` = `diff`). See §8.

### Proof

| Claim | Source |
|---|---|
| Bare `git diff` **omits untracked (new) files** — her new components would silently vanish | Documented git behavior; the fix below is git's own documented remedy |
| `git add -N` (`--intent-to-add`) makes new files visible to diff | [git-add docs](https://git-scm.com/docs/git-add): "Record only the fact that the path will be added later … useful for, among other things, showing the unstaged content of such files with `git diff`" |
| `add -N` is safe under her Read role | It touches only the local index — no commit, no push; nothing can reach the shared repo (Read role is server-side enforcement) |
| `:(exclude)` pathspec keeps generated docs/patches out of the code diff | [gitglossary pathspec magic](https://git-scm.com/docs/gitglossary#Documentation/gitglossary.txt-aiddefpathspecapathspec) |
| Diff base `origin/main` is correct even with stray local commits | She never commits (Read role decided); working tree vs. remote tracking branch *is* the change record |

**Result:** the complete design-as-built snapshot exists on disk at every session end. **Both raw sources are captured with zero clicks.**

### Why capture writes to `_capture/<date>/`, not the session folder

Hooks fire from her **first prompt**, before any feature/session name exists — a shell script cannot write into a folder named after a feature nobody has named yet (the chicken-and-egg bug found in the v2.2 audit). Date-based staging is deterministic; `/document-changes` later moves the capture into the named session folder.

Staging folder contents:

```
docs/agent/sessions/_capture/2026-08-09/
  ideas.jsonl          # UserPromptSubmit hook — her prompts verbatim (no AI)
  session-diff.patch   # Stop hook — design-as-built snapshot (no AI)
  diff-stat.txt        # Stop hook — summary stats (no AI)
  audit.jsonl          # optional PostToolUse hook — one line per agent tool call (no AI)
```

## 3. Component 3 — From raw capture to detailed design understanding (one click)

`/document-changes formId=<OPC-form-ID>` plus a one-sentence session goal. The prompt file (documented feature: [prompt files](https://code.visualstudio.com/docs/copilot/customization/prompt-files), invoked as `/` commands with `${input:variableName}` arguments) hands the LLM **both captured files** and instructs it to **correlate, not recall**:

**Which LLM, how often, what gets sent:** the model is whatever is selected in her VS Code Copilot model picker, unless pinned via the prompt file's documented `model` frontmatter field ("The language model used when running the prompt. If not specified, the currently selected model in model picker is used") — pin it for consistent output. The diff + `ideas.jsonl` + her typed goal are sent to the Copilot service **once per session, only at this step** — capture itself (Components 1–2) is shell-script-to-disk, no LLM. Her prompts already reach the Copilot service during normal editing (that is how Copilot works); this pipeline adds no new data exposure, only a local disk copy. Data handling is governed by the organization's Copilot policies (organizational fact, not verifiable from the docs).

1. Order `ideas.jsonl` chronologically — the design narrative in her words.
2. For each design element in the diff (component, style block, layout change), quote the prompt(s) that drove it **verbatim**, matched by content and timestamp order.
3. Anything the LLM concludes beyond a quote or a hunk must be marked `[inferred — verify]`.
4. Output per element: **what** (hunk) + **her words** (quote) + **why** (her typed goal + form ID).
5. Write `plan.md`, `changelog.md`, `requirements.md`, `test-log.md` into the dated session folder; move the `_capture/` files alongside them.

**Required inputs — why they are mandatory and cannot be automated away:** a diff is content, not motive. Intent is **not in the diff** and only fragmentarily in the prompts; her typed one-sentence goal + form ID make her the author of the "why" instead of the LLM inventing it. If either input is missing, the prompt instructs the agent to **ask, not proceed** (backstop, because the docs hedge: "*Most* language models understand this syntax").

**Honesty about the seams:** quotes and hunks are **ground truth**; the prompt↔hunk *pairing* is LLM judgment — usually obvious ("make the header blue" ↔ the header CSS hunk) but draft quality, reviewed like all narrative. The raw files travel in the handoff zip, so a developer can always re-derive the pairing from scratch.

**Honesty about "automatically":** capture (Components 1–2) is zero-click. Narration (Component 3) is one click per session, because the prompt files docs state verbatim: "Unlike custom instructions that are applied automatically, you invoke prompt files manually in chat." There is no documented zero-click LLM-generation path in VS Code chat — a `Stop` hook runs shell scripts, not LLM calls. Accurate label: **autonomous capture, one-click narration.** Fallback if hooks are unavailable: running `/document-changes` in the *same chat session* as the work gives the model her prior prompts in context (prompt files run in the current session) — weaker, lost on new sessions or context compaction.

## 4. Protection of the capture subsystem itself

The hooks page's own **Safety** section: "If the agent has access to edit scripts run by hooks, then it has the ability to modify those scripts during its own run … We recommend using `chat.tools.edits.autoApprove` to disallow the agent from editing hook scripts without manual approval."

```jsonc
// .vscode/settings.json (workspace)
"chat.tools.edits.autoApprove": {
  "**/.github/hooks/**": false,
  "**/.github/prompts/**": false,
  "**/scripts/**": false
}
```

Caveat kept honest: `false` = **ask for confirmation**, not block — she can still click Approve. The server-side Read role remains the only true enforcement (per the main document, Layer 0).

## 5. Validation tests (subset of the main document's 13-test matrix)

| # | Test | Expected |
|---|---|---|
| A (=#12) | Work a session, end it **without** running `/document-changes` | `_capture/<date>/` contains `ideas.jsonl` (one line per prompt typed), `session-diff.patch`, `diff-stat.txt` — session documented even without narration |
| B (=#13) | Make an edit via **inline chat (Ctrl+I)** | Determine empirically whether `UserPromptSubmit` fires — **undocumented**; record result, train accordingly |
| C (=#6) | Sample edit incl. a **newly created file** + `/document-changes` | Agent asks for missing `formId`/goal; docs quote her prompts verbatim; every claim maps to a diff hunk; new file present in the diff |
| D (=#8) | Hung hook (script sleeps past 30 s default timeout) | Determine empirically whether VS Code fails open or closed — **undocumented for VS Code**; record result |
| E (=#9) | Ask the agent to edit `scripts/capture-prompt.ps1` | Manual-approval prompt appears (autoApprove glob) |

## 6. Self-criticism — the serious list, stated before anyone finds it

1. **"Capture" is guaranteed; "understand in very detail" is not.** Components 1–2 are deterministic shell scripts and I stand behind them fully. Component 3 is LLM synthesis — the detail is preserved **losslessly**, but the *understanding* is a draft a human must check. Anyone who promises guaranteed machine understanding of design intent is lying.
2. **Undocumented edge, not papered over:** whether `UserPromptSubmit` fires for **inline chat** (Ctrl+I) is not stated on the hooks page. If she works via inline chat, prompt capture may miss those prompts — pilot test B exists precisely for this.
3. **Preview feature:** agent hooks are titled "(Preview)"; the format and behavior may change. Pin the VS Code version for the pilot. Hook timeout fail-open/fail-closed is undocumented for VS Code (Copilot CLI docs say fail-open — do not assume VS Code matches; test D).
4. **Manual edits without chat produce no prompts** — for those changes `ideas.jsonl` is legitimately empty and the diff + her typed goal carry the load. Not a bug; stated.
5. **Hook script *bodies* are now executed and pass (see §8) — hook *firing* is not.** The scripts were run against simulated documented stdin JSON and a real git repo, and the original version contained a real bug (the `>` encoding defect above), proving this caution was warranted. What remains untested is whether VS Code actually invokes them at the documented moments — tests A, B, D require a live agent session and are still pending.
6. **Organizational facts assumed, not invented:** OPC Y intake forms have stable referencable IDs; the OPS repos exist with her on a Read role. If either assumption is wrong, that is a prerequisite to raise.

## 7. What this plan does NOT do (scope honesty)

- It does not block anything — commit/push prevention is the main document's Layer 0 (Read role, server-side) and optional Layers 1–2.
- It does not deliver code to developers — that is the handoff script (`handoff.ps1`, main document Layer 3).
- It does not guarantee narrative accuracy — developer review against the raw captured files is mandatory (main document, test #6 and PR checklist).

## 8. Empirical test results (2026-08-10, pilot repo)

Environment: Windows PowerShell 5.1, real git repo `pilot/` with bare origin `pilot-origin.git` and a pushed `origin/main` baseline. Simulated session: header color edit in `src/ui/index.html` + **newly created** `src/ui/search-box.html`.

| Test | Evidence (actual terminal output) | Verdict |
|---|---|---|
| T1a — negative control: bare `git diff --name-status origin/main` | Output: `M src/ui/index.html` only; `git status --porcelain` showed `?? src/ui/search-box.html` — the new file is invisible to diff | ✅ The untracked-file gap is real, not theoretical |
| T1b — `capture-prompt.ps1` fed two stdin JSON payloads with documented fields | `ideas.jsonl` contains both prompts verbatim with `ts` and `session` | ✅ Pass |
| T2 — `capture-session.ps1` | Patch contains `diff --git` headers for **both** `index.html` and the new `search-box.html`; `ideas.jsonl` is **not** in the patch (`:(exclude)docs/agent` honored); exit 0 | ✅ Pass |
| T2b — encoding: `>` vs `--output` | Redirect file first bytes: `255,254,100,0` (UTF-16LE BOM); `--output` file: `100,105,102,102` (`diff`) | ✅ Defect proven, scripts fixed |
| T3 — `handoff.ps1` | `policy-search-refresh-changes.patch` (2 files) + `policy-search-refresh-handoff.zip` produced, exit 0 | ✅ Pass |
| T4a — `git apply` the UTF-16 patch on a fresh clone | `error: No valid patches in input`, exit 128 | ✅ Failure mode proven |
| T4b — `git apply` the clean patch on a fresh clone of origin | Exit 0; `Test-Path src\ui\search-box.html` → `True`; header hunk (`1a4d8f`) present | ✅ End-to-end pass |
| A, B, D — hook firing / inline-chat / timeout | — | ⚠️ **Not executed**: hooks only load when `pilot/` is the workspace root of a live VS Code agent session |
| C — `/document-changes` narration quality | — | ⚠️ **Not executed**: requires live agent session |

Two additional findings from a T4 first-run failure (both fixed, both honest lessons):

1. **Bare-repo HEAD**: `git init --bare` leaves HEAD at `master`; after pushing `main`, clones warn "remote HEAD refers to nonexistent ref" and check out nothing. Test-harness fix: `git symbolic-ref HEAD refs/heads/main` in the bare repo. (Not applicable to real GitHub, which sets the default branch.)
2. **Patch contamination**: a stray untracked temp file in the repo root was swept into the handoff patch by `git add -N .`. Real workflow lesson: `git add -N .` intends *everything* untracked — the script prints the patch, and the developer review must check its file list. Keep the working tree clean or extend the exclude pathspecs.
