# Business-Engineer Agentic Coding Workflow

**One sentence:** a non-developer Business User turns her design ideas into working UI code with VS Code + GitHub Copilot, through a guarded, orchestrated agent pipeline that captures her ideas, engineers the correct context, designs, critiques, implements, verifies, documents — and hands off to developers, who alone commit to GitHub.

- Date: 2026-08-10. Companion documents: [Guarded_Business-User_Agent_Workflow_from_copilot.md](Guarded_Business-User_Agent_Workflow_from_copilot.md) (guardrails, v2.6), [Design_Capture_Plan_from_copilot.md](Design_Capture_Plan_from_copilot.md) (capture subsystem), [Design_Context_Plan_from_copilot.md](Design_Context_Plan_from_copilot.md) (context subsystem).
- Everything here is either (a) quoted from official documentation fetched 2026-08-09/10, (b) empirically tested in the `pilot/` repo with terminal evidence, or (c) explicitly marked as untested or unknown. Sources:
  - [Chat overview](https://code.visualstudio.com/docs/chat/chat-overview) · [Custom instructions](https://code.visualstudio.com/docs/copilot/customization/custom-instructions) · [Prompt files](https://code.visualstudio.com/docs/copilot/customization/prompt-files) · [Custom agents](https://code.visualstudio.com/docs/agent-customization/custom-agents) · [Agent hooks](https://code.visualstudio.com/docs/agent-customization/hooks) · [Hooks reference](https://code.visualstudio.com/docs/agents/reference/hooks-reference) · [git-add](https://git-scm.com/docs/git-add) · [gitglossary pathspec](https://git-scm.com/docs/gitglossary)

---

## 0. The core fact everything builds on

The idea-to-code conversion is the **built-in VS Code agent**. Quoted from the chat docs: *"Type your message in the chat input box and press Enter… **The agent analyzes your code, makes the changes, and responds with a summary.**"* And: *"Chat in Visual Studio Code lets you use natural language for interacting with AI agents… generate new features, fix bugs, and more."*

Everything in this workflow is engineering **around** that engine, with one goal: make the generated code match **her** idea, and catch it when it doesn't. In the user's own accurate words: this is **prompt engineering, automated** — deterministic scripts and configuration assemble the correct context, then the agent updates the code.

Her ideas can enter as plain English **or as images** — documented Vision capability: *"attach images, such as screenshots or UI mockups, as context for your prompt."*

## 1. The complete workflow diagram

Every box below corresponds to a file that exists in `pilot/` and was **re-read on 2026-08-10** before drawing this diagram; nothing is drawn from memory. Legend: ✅ = pilot-tested (evidence in §4) · ⚠ = built but untested / live-pending (§6) · `[path]` = the file implementing the box.

```text
════════════════ ONE-TIME / PERIODIC SETUP ═══════════════════════════════════
 SETUP-1  docs/agent/ initialized as a NESTED git repo, origin = INTENT repo
          (she has Write there; the PRODUCT repo ignores docs/agent/ entirely
          via .gitignore: handoff/ docs/agent/ external/)              (✅ T7)
 SETUP-2  Retro-backfill of her PRE-HOOK prompt history (run once):
          [scripts/capture-history.ps1] mines %APPDATA%\Code\User\
          workspaceStorage\<hash>\GitHub.copilot-chat\transcripts\*.jsonl
          (matched to this workspace via workspace.json; internal,
          UNDOCUMENTED format ⚠) → dedupe-appends {ts,session,prompt,
          source:"retro-transcript"} into ideas.jsonl                  (✅ T6)
 SETUP-3  Company repo catalog (developer runs, periodic):
          [scripts/scan-repos.ps1] -RepoListFile "name,url" (✅ T8a)
          or -Org via `gh repo list --json name,description,url` (⚠ test N)
          → shallow-clones each repo, extracts README excerpt +
          package.json name/description (mechanical, no AI)
          → docs/agent/repo-catalog.md

════════════════ EVERY SESSION — HER LAPTOP (GitHub Read role) ═══════════════

 SESSION OPENS
   SessionStart hook [.github/hooks/context.json]
     → [scripts/inject-context.ps1] emits hookSpecificOutput
       .additionalContext = active-brief.md + ideas.jsonl tail
       (last 2 capture days, max 30 lines) + git diff --stat vs
       origin/main (git add -N first, so new files show)          (✅ T5)
   Always-on context, no hook needed:
     [.github/copilot-instructions.md]  (workspace-wide rules:
       reflect-then-edit, plain-language reporting, never git
       commit/push/merge/rebase)
     [.github/instructions/ui.instructions.md]  (applyTo: src/ui/**)

 HER IDEA — plain English or pasted mockup image (documented Vision input)
   │  EVERY prompt she submits, in any agent:
   │  UserPromptSubmit hook [.github/hooks/capture.json]
   │    → [scripts/capture-prompt.ps1] appends {ts, session, prompt}
   │      → docs/agent/sessions/_capture/<date>/ideas.jsonl        (✅ T1b)
   │
   ├──▶ OPTIONAL STAGE 0 — INTENT agent [.github/agents/intent.agent.md]
   │      (scripts ✅ T8; agent behavioral compliance ⚠ test O)
   │      1 reads docs/agent/repo-catalog.md — REFUSES if missing or
   │        older than 30 days ("ask a developer to run scan-repos.ps1")
   │      2 matches her idea → candidate repo(s), quoting the exact
   │        catalog lines as evidence; no match → says so, never forces
   │      3 asks her confirmation before any download
   │      4 [scripts/fetch-repo-context.ps1 -Name -Url]  (✅ T8b/c)
   │          git clone --depth 1 → external/<name>  (gitignored,
   │            disposable; clone failure → hard exit 1)
   │          all *.md (relative paths kept) → docs/agent/context/<name>/
   │          + _inventory.md: file tree, package.json fields, js
   │            function names via regex (stated heuristic)
   │      5 writes docs/agent/context/<name>/features.md — the ONLY
   │        file this agent may edit; every claim quotes an extracted
   │        line; unprovable claims marked UNVERIFIED
   │      6 handoff button "Design with this context" ─▶ designer
   ▼
╔══════════════════════════════════════════════════════════════════════╗
║ ORCHESTRATOR [.github/agents/orchestrator.agent.md]                   ║
║ agents: ['designer','critic'] — never edits files, never runs git     ║
║                                                                       ║
║  1 DESIGNER subagent [.github/agents/designer.agent.md]               ║
║     grounding order (verbatim from the agent file): her idea in this  ║
║     conversation → docs/agent/active-brief.md → intake form in        ║
║     docs/business/ → ideas.jsonl (recent dates) → current src/ui/     ║
║     (when Stage 0 ran, docs/agent/context/<repo>/ arrives via the     ║
║      intent agent's handoff PROMPT — it is not in the agent file)     ║
║     writes ONLY docs/agent/designs/<yyyy-mm-dd>-<feature>.md:         ║
║       her idea verbatim + plain restatement + per-file proposed       ║
║       change + what will NOT change + open questions + how she        ║
║       will verify; inferences marked [inferred — verify]              ║
║  2 CRITIC subagent [.github/agents/critic.agent.md]                   ║
║     tools: ['search','web'] — read-only by design, reports only       ║
║     6 evidence-based checks: fidelity / completeness / ambiguity /    ║
║     feasibility-in-this-repo / scope honesty / verifiability          ║
║     → exactly one recommendation: REVISE or APPROVE                   ║
║  3 REVISE ─▶ designer again with critique attached (max 2 loops,      ║
║     then the open disagreement goes to HER — she decides)             ║
║    APPROVE ─▶ orchestrator summarizes (quotes her idea verbatim,      ║
║     lists [inferred — verify] items) and STOPS — never builds         ║
╚═════════════╪═════════════════════════════════════════════════════════╝
              │        Manual fallback (same files, human click each step):
              │        designer → "Send design to critique" → critic →
              │        "Revise design" | "Approve and implement";
              │        builder → "Design the next idea" → designer
              ▼
 [SHE CLICKS "Approve and implement"]  ◄── handoff button (send: false —
              │                            she sees the prompt before it runs)
              ▼
 BUILDER agent [.github/agents/builder.agent.md]
   edits src/ui/ per the approved design ONLY; other files require
   asking first; design-vs-reality conflict → STOP and report (that is
   a design defect, not a license to improvise); ui.instructions.md
   conventions auto-apply to src/ui/**
              ▼
 SHE VERIFIES visually (npm run dev / open the file) — compares against
   the design's "How she will verify" section; "not what I meant" loops
   in plain English until she confirms
              ▼
 /document-changes prompt [.github/prompts/document-changes.prompt.md]
   requires formId + sessionGoal (STOPS and asks if missing)
   ground truth ONLY: diff vs origin/main (git add -N first, excludes
   docs/agent + handoff) + ideas.jsonl verbatim + docs/business/
   <formId>.md + sessionGoal — CORRELATE, never invent; every claim =
   a diff hunk or a verbatim quote, else [inferred — verify]
   → moves _capture/<date>/ files into docs/agent/sessions/<date>-
     <feature>/ and writes changelog.md, requirements.md, plan.md,
     test-log.md ("No tests were run this session." if none)
   → refreshes docs/agent/active-brief.md  ──feeds──▶ next SessionStart
              ▼
 [scripts/handoff.ps1]  (✅ T3/T4b)
   git add -N → git diff --output=handoff/<session>-changes.patch
     origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
     (git's own --output, never PS '>' — UTF-16 gotcha, §5 #1)
   empty patch → warn + exit 1 (nothing to hand off)
   zip = patch + docs/agent/sessions/** + docs/agent/designs/**
              ▼
 SESSION ENDS (every session, handoff or not)
   Stop hook [.github/hooks/capture.json]
     → [scripts/capture-session.ps1]  (✅ T2)
       git add -N → session-diff.patch + diff-stat.txt +
       session-skeleton.md (mechanical name-status list, no AI)
   BOTH capture-session.ps1 AND handoff.ps1 then call, fail-soft
   (try/catch Write-Warning — a sync failure never blocks her):
     → [scripts/sync-intent.ps1]  (✅ T7)
       requires docs/agent/.git → add -A → commit iff changes →
       push origin main, trusting $LASTEXITCODE only (push reports
       success on stderr — §5 #6); offline → commits stay local,
       next sync pushes the backlog
              │
══════════════╪═══ GITHUB (server-side, per-repository roles) ════════════════
              ▼
 INTENT repo — she has WRITE: her ideas, designs, session patches, and
   repo context become her own timestamped commits, surviving her laptop
   (⚠ prerequisite: same confidentiality as the product repo — the
   session patches contain product source as diff text)
 PRODUCT repo — she has READ (Layer 0, §2): pull/clone ✓, push ✗ —
   server-enforced; no local mistake, agent, or prompt injection can
   bypass it. Optional Layer-2 hardening (PreToolUse git-deny hook,
   edit auto-approve exclusions, terminal allow-list) listed in §2.

════════════════ DEVELOPER MACHINE (Write role) ══════════════════════════════
 reviews the handoff zip → git apply <patch> → runs tests / code review
 → commits and pushes the PRODUCT repo. Only developer commits ever
 reach the product repo. Periodically re-runs scan-repos.ps1 (SETUP-3).
              │
              ▼
 NEXT SESSION: SessionStart re-injects refreshed brief + her verbatim
 ideas + work-in-progress diff-stat — the loop closes            (✅ T5)
```

## 2. Layer 0 — the guardrail everything sits on (unchanged, decided)

Her GitHub account has the **Read role** on the OPS repos (decided 2026-08-09). Read = clone/pull/open issues; **no push, ever** — server-side enforcement that no local configuration, agent, prompt injection, or mistake can bypass. Consequences:

- Neither she nor any agent on her machine can commit to GitHub. **Step 6 of any pipeline must end in a handoff, not a commit.** The developer commits after review. (Scale-up path if needed later: handoff attached to an issue → GitHub Action → draft PR — still developer-approved.)
- Local `git add -N`, `git diff` are safe: they touch only the local index/tree.
- Defense-in-depth (optional, Layer 2 of the main document): PreToolUse hook denying `git (commit|push|merge|rebase)`; `chat.tools.edits.autoApprove: false` (= ask) on `.github/hooks/**`, `.github/agents/**`, `.github/prompts/**`, `.vscode/**`, `scripts/**` — the hooks docs' own Safety recommendation; terminal allow-list for `npm run dev`, `npm test`, read-only git.

## 3. The pipeline stages — mechanism, proof, status

### Stage 0 — Locate the feature's home repo (optional; added 2026-08-10, §4.3)

Before designing, the `intent` agent answers "which company repo already has / should host this?": it reads `docs/agent/repo-catalog.md` (built by `scan-repos.ps1`), matches her idea to candidate repos **with quoted catalog evidence**, and — only after her confirmation — runs `fetch-repo-context.ps1` to shallow-clone the repo and extract its markdown docs + a mechanical inventory into `docs/agent/context/<repo>/`, which the designer then uses. Layer 0 safe: cloning is a pull, and Read = ✓ "Pull" in the role table. Scripts tested (T8 ✅); agent behavior + real `gh` org scan pending live tests N/O. Full detail: §4.3.

### Stage 1 — Capture her idea (automatic, zero-click, no AI)

| Piece | Mechanism | Proof | Status |
|---|---|---|---|
| Her prompts, verbatim | `UserPromptSubmit` hook → `scripts/capture-prompt.ps1` → `docs/agent/sessions/_capture/<date>/ideas.jsonl` | Hook event documented ("User submits a prompt — Audit user requests"), `prompt` input field documented | Script **tested (T1b ✅)**; live firing pending (test A) |
| The design as built | `Stop` hook → `capture-session.ps1` → `session-diff.patch` (with `git add -N` so **new files** are included) | git-add docs: intent-to-add is "useful for … showing the unstaged content of such files with git diff" | **Tested (T2 ✅)**; negative control T1a proved bare `git diff` really omits new files |
| Mockup images | Documented Vision input | Chat docs quote above | Documented, not yet live-tested |
| **Her PAST prompts (before hooks were installed)** | `scripts/capture-history.ps1` mines VS Code's on-disk chat transcripts (`%APPDATA%\Code\User\workspaceStorage\<hash>\GitHub.copilot-chat\transcripts\*.jsonl`, matched to the workspace via `workspace.json`) and backfills `ideas.jsonl` with `source:"retro-transcript"`, deduped against hook-captured lines | **Empirical, not documented**: format reverse-engineered from disk — entries are `{type, data, id, timestamp, parentId}`; user prompts are `type="user.message"` with `data.content`. Verified by extracting this project's own real prompts | **Tested (T6 ✅)**. ⚠ Internal/undocumented format — may break on VS Code updates; script skips unparseable lines rather than failing |

### Stage 2 — Prompt engineering: the correct context, assembled automatically

The prompt the model receives = four layers, each with a documented delivery mechanism:

| Layer | File | Documented mechanism |
|---|---|---|
| Cross-session memory: active brief + her verbatim ideas tail (cap: 2 days / 30 lines) + `git diff --stat` of work in progress | `scripts/inject-context.ps1` via `.github/hooks/context.json` | `SessionStart` output `hookSpecificOutput.additionalContext` — "Context added to the agent's conversation" |
| Standing rules incl. **reflect-then-edit** (restate her idea in plain language and confirm before editing) | `.github/copilot-instructions.md` | "automatically detects … and applies the instructions in this file to all chat requests" |
| UI conventions, loaded only when touching UI files | `.github/instructions/ui.instructions.md` | `applyTo: 'src/ui/**'` — "Glob pattern that defines which files the instructions apply to automatically" |
| Her new idea | typed prompt / pasted image | built-in |

**Status: injection script tested (T5 ✅)** — actual output verified to contain the brief (OPC-1234), her verbatim ideas, and the diff-stat, as valid JSON. **Verified negative:** `UserPromptSubmit` "uses the common output format only" — there is **no documented per-prompt injection**; only SessionStart/SubagentStart/PreToolUse/PostToolUse have `additionalContext`. This design injects at session start and does not pretend otherwise (mid-session, her prompts are already in the conversation).

### Stage 3 — Design + critique (orchestrated, autonomous between gates)

- **Orchestrator** (`orchestrator.agent.md`): documented `agents` frontmatter field — "A list of agent names that are available as subagents in this agent" — lets it invoke `designer` and `critic` itself: design → critique → revise (max 2 loops, cost control) → summary → **stops** for her approval.
- **Designer** (`designer.agent.md`): writes the design document — her idea verbatim, plain-language restatement, proposed change per file, explicit non-goals, open questions (never silently resolved), and "how she will verify". Hard path boundary: writes only in `docs/agent/designs/`.
- **Critic** (`critic.agent.md`, read-only tools): 6-point evidence-based checklist — **fidelity** (every change traces to her words/brief/form), **completeness** (quotes any ignored part of her idea), **ambiguity**, **feasibility** (referenced files exist), **scope honesty**, **verifiability**. Ends with exactly REVISE or APPROVE; she makes the final call.
- **Handoffs between agents are documented**: "Handoffs enable you to create guided sequential workflows … give developers control for reviewing and approving each step." The docs' own examples are this pipeline: "Planning → Implementation", "Implementation → Review".

**Status: files built and pushed (commits `8943971`, `acf41ba`); not yet executed live** — agent behavior is guidance-level and needs the live pilot.

### Stage 4 — Implement (one human gate before code changes)

**Builder** (`builder.agent.md`) implements the approved design **only**: touches only files the design names; stops and reports if the design conflicts with code reality (that is a design defect, not an improvisation license). The edit capability itself is the documented built-in ("The agent analyzes your code, makes the changes").

### Stage 5 — Test and feedback loop (honest version)

- Her prototypes are plain HTML/CSS: **there is no automated test suite to run** — pretending otherwise would be fabrication. "Test" = she opens the page (allow-listed `npm run dev`) and compares against the design's "how she will verify" section.
- The loop: "not what I meant" in plain English → builder fixes → repeat until she confirms. Documented revision support: "Request revisions: send a follow-up prompt"; checkpoints can restore any earlier state.
- Where real tests exist (`npm test` in the OPS repos), the builder runs them and `/document-changes` records the output in `test-log.md`; if none ran, it writes exactly "No tests were run this session."
- Two intent-checkpoints she can judge without reading code: the restatement *before* editing, her eyes on the page *after*.

### Stage 6 — Document and hand off (developer commits, not her)

- `/document-changes formId=… sessionGoal=…` (prompt file, one click): correlates diff hunks with her verbatim prompts — quotes and hunks are ground truth, everything else marked `[inferred — verify]`; writes changelog/requirements/plan/test-log; refreshes `docs/agent/active-brief.md` (which feeds the next session's injection).
- `scripts/handoff.ps1`: `git add -N .` → patch vs `origin/main` (excludes `docs/agent`, `handoff` via documented `:(exclude)` pathspec) → zip with session docs + designs + raw capture. **Tested end-to-end (T3, T4b ✅): a fresh clone + `git apply` reproduced her work, including the newly created file.**
- The developer reviews the patch's file list (important: `add -N .` sweeps in *any* untracked file — proven in testing) and commits. **Her machine never does.**

## 4. Empirical evidence — what was actually executed

All in `pilot/` (real git repo + bare `pilot-origin.git` origin + `dev-clone/`), Windows PowerShell 5.1. Full transcripts in the companion docs.

| Test | Proved | Verdict |
|---|---|---|
| T1a (negative control) | Bare `git diff` omits the newly created file — the untracked-file fix addresses a real bug | ✅ |
| T1b | Prompt capture writes her prompts verbatim to `ideas.jsonl` | ✅ |
| T2 | Session patch includes the new file, excludes `docs/agent` | ✅ |
| T2b | PS 5.1 `>` redirect = UTF-16LE (bytes `255,254`); `git diff --output=` = valid ASCII patch | ✅ bug proven+fixed |
| T3 | Handoff produces patch + zip | ✅ |
| T4a | `git apply` rejects the UTF-16 patch (exit 128) | ✅ failure mode proven |
| T4b | Fresh clone + apply patch → new file exists, edit present, exit 0 — **end-to-end** | ✅ |
| T5 | SessionStart injection emits valid JSON with brief + verbatim ideas + diff-stat | ✅ (after bug fix, see §5) |
| T6 | Retro-capture: mined this workspace's real transcripts → recovered **24/24** `user.message` prompts verbatim into day-bucketed `ideas.jsonl`; second run deduped all 24; UTF-8 round-trip verified | ✅ |
| T7 | Dedicated intent repo: nested repo sync, idempotency, product-repo isolation, developer clone, offline fail-soft + backlog push, handoff regression (§4.2) | ✅ (2 bugs found+fixed, see §5 #6–#7) |
| T8 | Intent-agent pipeline: catalog built from 2-repo fixture org; fetch extracted 2 md files + mechanical inventory (incl. `initSearchBox` found by regex); negative control (nonexistent repo → exit 1); context synced to intent repo | ✅ (1 bug found+fixed, see §5 #8) |

### 4.1 Enhancement (2026-08-10): retro-capture of past Copilot history (T6)

**Question:** can we go through the workspace history to capture what she has already done in Copilot — *before* the capture hooks were installed?

**Answer: yes — built, tested, and committed (`6d0497d`), with every claim proven on this machine's actual disk.**

**What was proven (executed, not asserted):**

1. **VS Code persists Copilot chat per-workspace** at `%APPDATA%\Code\User\workspaceStorage\<hash>\` — listed the real folder for this workspace: `GitHub.copilot-chat\transcripts\*.jsonl` (824,262 bytes), plus `chatSessions\` and `chatEditingSessions\` (the latter two exist but are deliberately not mined — see limits below).
2. **Her prompts are recoverable verbatim.** Parsed the real transcript: 549 entries; exactly **24 `user.message`** entries, each with `data.content` + ISO timestamp. Six of this project's own past prompts were printed back as evidence.
3. **The right workspace is findable programmatically:** `workspace.json` inside each hash folder maps the folder to its workspace URI (verified: `file:///c%3A/Users/qinxi/business_user_agent`).

**What was built:** `scripts/capture-history.ps1` — retro-mines the transcripts and backfills `ideas.jsonl` in the *same schema the hook writes* (`ts`, `session`, `prompt`), tagged `source:"retro-transcript"`, deduplicated on `ts|prompt` against hook-captured and previously recovered lines.

**T6 results (real transcripts of this workspace, output to a temp folder):**

- Run 1: **recovered 24/24 prompts**, day-bucketed (15 on 2026-08-09, 9 on 2026-08-10) — matching the independently counted 24 `user.message` entries exactly.
- Run 2: **0 recovered, 24 skipped** — dedupe proven.
- Spot-check: the last recovered record was the user's then-current message, JSON-valid, UTF-8 intact end-to-end.

**Honest limits (stated in the script header too):**

1. **Internal, undocumented format.** No documentation describes these transcript files; the schema (`type: "user.message"`, `data.content`) was reverse-engineered from disk — the first schema guess (`role` field) was **wrong** and errored before inspection revealed the real one. Any VS Code / Copilot update may change or remove the format, so the script fails soft (skips unparseable lines). The `UserPromptSubmit` hook remains the *supported* capture mechanism; retro-capture is best-effort forensics for the pre-hook gap only.
2. **Local machine, current profile only.** Cleared chats, other machines, other VS Code profiles (Insiders, portable) are not recoverable, and her retention settings are unverified.
3. **Prompts only, by design.** Transcripts also contain assistant output and tool results; extracting them would bloat handoff packages with noise. Scope can be widened if session narratives are ever wanted.
4. **Tested on n=1** workspace and one VS Code version — proven *here, today*, not universally.

### 4.2 Enhancement (2026-08-10, decided): dedicated intent repo — "Option A" (T7)

**Decision:** her intent/design history gets its own git repository ("intent repo") where she has **Write**, while she stays **Read** on the product repo.

**Why it was needed (proven by `git ls-files` before the change):** her intent lived almost entirely as *local-only* files — `ideas.jsonl`, `session-diff.patch`, designs, and handoff zips existed only on her disk; the sole committed artifact (`active-brief.md`) was committed by the *developer* role, not her. Her laptop was a single point of failure for the entire intent history.

**Options considered (each with its proof):**

| Option | Verdict | Proof / reason |
|---|---|---|
| **A. Dedicated intent repo** | **Chosen** | Roles are per-repository (quote below); smallest change to what's built; headlessly testable (T7) |
| B. Feature branch in the product repo | **Rejected — impossible** | Role table: Read = ✗ for "Push to (write)" — Read cannot push to *any* branch; doing this needs Write + branch protection, i.e. a Layer 0 revision |
| C. Her fork of the product repo | Viable alternative, deferred | Role table: Read = ✓ "Fork" and ✓ "Send pull requests from forks"; but private-repo forking can be disabled by org policy — unverified for this org |
| D. Status quo (local + handoff zip) | Rejected | Laptop = single point of failure (proven above) |

**Why A doesn't break Layer 0 (proof):** GitHub docs — *"You can customize access to **each repository** in your organization by assigning granular roles."* Roles are per-repository; Read on the product repo and Write on the intent repo are independent grants.

**Design (built in pilot, commits `7d411c3` + `e977314`):**

- `docs/agent/` becomes a **nested git repo** whose origin is the intent repo (pilot: bare `intent-origin.git`); commits are authored as *Business User*.
- The product repo **ignores** `docs/agent/` (`.gitignore`) and tracks nothing under it (verified with `git ls-files docs/agent` → empty).
- `scripts/sync-intent.ps1` (add → commit-if-changed → push, fail-soft) is called from **session end** (`capture-session.ps1`) and **handoff** (`handoff.ps1`), so intent history persists off-laptop automatically.

**T7 results (all executed):**

| Sub-test | Result |
|---|---|
| T7a: new idea → sync commits + pushes to intent origin | ✅ (after bug fix, see §5 #6) |
| T7b: re-run with no changes → "No new intent changes", exit 0 | ✅ idempotent |
| T7c: product repo isolation — `check-ignore` matches, `ls-files docs/agent` empty | ✅ (after fix, see §5 #7) |
| T7d: developer `git clone` of intent origin contains full commit history + verbatim ideas | ✅ |
| T7e (negative): unreachable origin → warning, exit 1, **commit survives locally** | ✅ fail-soft |
| T7f: next sync pushes the offline backlog | ✅ |
| T7g (regression): full handoff run — patch contains exactly her 2 UI files, intent synced | ✅ |

**Honest limits:** (1) pilot origin is a local bare repo — **no credentials were exercised**; real GitHub pushes need her git credentials configured once (Git Credential Manager), untested here (**live test M, §6**). (2) `session-diff.patch` in the intent repo contains product source as diff text — the intent repo **must** have the same confidentiality controls as the product repo. (3) Sync-at-session-end depends on the Stop hook firing — still pending live test A.

### 4.3 Enhancement (2026-08-10): INTENT agent — match her idea to a company repo, download it, extract context (T8)

**Requirement (hers, restated):** an agent that (a) identifies which company GitHub repo is needed for her idea, (b) scans the company GitHub to know what each repo is for, (c) downloads the identified repo locally, (d) extracts md/features from it as context, (e) uses that context in the coding session.

**Layer 0 proof this is permitted:** all of it is *read-only toward remotes*. GitHub role table (fetched this session): Read = ✓ *"Pull from the person or team's assigned repositories"* — cloning is a pull. Nothing in this feature pushes anywhere.

**Components (division of labor: scripts are mechanical, AI judgment lives only in the agent):**

| Piece | Requirement step | Mechanism | Proof / status |
|---|---|---|---|
| `scripts/scan-repos.ps1` | (b) scan the company GitHub | Builds `docs/agent/repo-catalog.md`: per repo, README excerpt (first 15 lines) + `package.json` name/description. Two modes: `-RepoListFile` (name,url lines — **T8-tested**) and `-Org` via `gh repo list <org> --json name,description,url` | gh command documented: CLI manual — *"List repositories owned by a user or organization"*, `--json` fields include `name`, `description`, `url`. **Org mode UNTESTED** (needs real gh auth) → live test N |
| `.github/agents/intent.agent.md` | (a) identify the repo | Reads the catalog, quotes her idea verbatim, lists candidates **with quoted catalog evidence**, refuses to force a match, asks confirmation before any fetch; only file it may write is `features.md` | Agent behavior is guidance-level (like all agents) → live test O |
| `scripts/fetch-repo-context.ps1` | (c)+(d) download + extract | `git clone --depth 1` → `external/<name>/` (gitignored); copies all `*.md` (relative paths preserved) → `docs/agent/context/<name>/`; writes `_inventory.md`: file tree + package fields + js function names (regex heuristic, labeled as such in the output) | **T8-tested** |
| Agent step 5 → `features.md` | (d) "features" summary | The AI reads extracted docs + inventory and writes a plain-language features summary, every claim tied to a quoted extracted line, unverifiable items marked UNVERIFIED | Guidance-level → live test O |
| `docs/agent/context/` placement | (e) use as context when coding | Lives in the workspace (agents read it; designer handoff prompt points at it) **and** inside the nested intent repo, so `sync-intent.ps1` persists it (proven: T8e commit `75d3467`) | ✅ T8e |

**T8 results (fixture org = 2 local bare repos, `company-widgets` + `annuity-calc`, with realistic README/docs/package.json/js):**

| Sub-test | Result |
|---|---|
| T8a: catalog built — both repos with correct excerpts + package description | ✅ (after parse-bug fix, §5 #8) |
| T8b: fetch `company-widgets` → 2 md files extracted + `_inventory.md` with file tree and `initSearchBox` found by regex | ✅ |
| T8c (negative): nonexistent repo → "Clone failed (exit 128)", script exit 1 | ✅ |
| T8d: her uncommitted UI work untouched; new dirs properly ignored/committed | ✅ |
| T8e: catalog + context sync to intent repo (`75d3467`, authored *Business User*) | ✅ |

**Honest limits:** (1) the `gh`-based org scan is **documented but never executed here** — no real GitHub org exists in the pilot (test N). (2) The function-name extraction is a stated regex heuristic, not a parser — it found `initSearchBox` in the fixture but will miss arrow functions, classes, and exports. (3) Whether the intent agent actually obeys "quote evidence / confirm before fetch / write only features.md" is guidance-level until test O. (4) Repos she cannot Read cannot be scanned or fetched — the catalog can only ever cover repos her role reaches. (5) Fetched repo docs may be large; `docs/agent/context/` grows the intent repo — pruning is left to her/developer judgment for now.

## 5. Defects found by execution and self-review (the honesty log)

These were **my own errors**, caught by testing or re-reading — recorded because "documented ≠ executed" is this project's governing principle:

1. **UTF-16LE patch corruption** — the documented scripts used PowerShell `>` redirection; PS 5.1 writes UTF-16LE and `git apply` rejects it ("No valid patches in input", exit 128, proven). Fix: `git diff --output=<file>`.
2. **ANSI/OEM context corruption** — `Get-Content` without `-Encoding UTF8` misread the brief; OEM stdout mangled an em-dash into a JSON-breaking byte (T5 first run failed at char 249, proven). Fix: explicit UTF-8 at every byte boundary. **Rule: on PS 5.1, every redirect, file read, and stdout must state its encoding.**
3. **Designer self-contradiction** — shipped with read-only tools *and* an instruction to write the design document; it could never have produced its artifact. Fix: tools unrestricted + strict path boundary.
4. **Overstated platform limit** — I claimed "no autonomous orchestrator exists"; the documented `agents` subagent field disproves that. Fix: `orchestrator.agent.md` runs design→critique autonomously.
5. **Patch contamination** — `git add -N .` swept a stray temp file into the handoff patch (proven in T4's first run). Mitigation: script prints the patch file list; developer review checks it.
6. **git-push stderr trap** (T7 first run) — `git push` reports *success* on stderr; under `$ErrorActionPreference = "Stop"`, `2>&1` converted the success message (`To ..\intent-origin.git`) into a terminating error, so a working push was reported as failed. Fourth proven PS 5.1 gotcha. Fix: relax the preference around the native call and trust `$LASTEXITCODE` only.
7. **gitignore ≠ untrack** — my `git reset -q` before the selective commit silently undid the earlier `git rm --cached` of `active-brief.md`, and `.gitignore` does not affect already-tracked files — the product repo still tracked it. Caught by post-commit verification (`git ls-files docs/agent`), fixed in `e977314`. Lesson: verify the *repository state*, not the command you think you ran.
8. **Backtick-in-double-quotes parse error** (T8 first run) — I put a markdown code fence (three backticks) inside a double-quoted PowerShell string; backtick is PS's escape character, so the script would not even parse. Fifth proven PS 5.1 gotcha. Fix: single-quoted strings for literal backticks.
9. Earlier design-phase catches (v2.1–v2.2 of the main doc): untracked-file gap, hook chicken-and-egg (date-based `_capture/` staging), inference-based form linkage replaced by required typed inputs.

## 6. Honest unknowns and the live-pilot test checklist

None of the following is testable headlessly; all require opening `pilot/` as the workspace root in a live VS Code agent session. Until they run, the corresponding claims are *documented*, not *verified*:

| # | Live test | Unknown it resolves |
|---|---|---|
| A | Work a session, end without `/document-changes` | Do the capture hooks actually fire? |
| B | Edit via inline chat (Ctrl+I) | Does `UserPromptSubmit` fire for inline chat? (undocumented) |
| C | `/document-changes` on a real session | Narration quality; agent asks for missing formId/goal |
| D | Hook script that sleeps past 30 s | Does VS Code fail open or closed on hook timeout? (undocumented) |
| E | Ask the agent to edit a hook script | Does the autoApprove "ask" gate appear? |
| F | New session, ask "what am I working on?" | Does SessionStart injection reach the model? Does the em-dash survive VS Code's stdout decoding? (undocumented) |
| G | Edit a UI file, check the response's References section | Are both instructions files applied? (docs name this exact verification method) |
| H | Give a vague idea | Does the model actually follow reflect-then-edit? (guidance-level — measure the rate) |
| I | >30 captured ideas | Does the injection cap hold? |
| J | Pick `orchestrator`, give one idea | Do subagent invocation, the revise loop (≤2), and the approval stop work as instructed? |
| K | After critique, click "Approve and implement" | Do handoff buttons render and carry the prompt? |
| L | Does `critic`'s `['search', 'web']` tool set include file reading? | Tool-set contents are not enumerated on the docs page — check the Diagnostics view |
| M | Point `docs/agent`'s origin at the real GitHub intent repo; run `sync-intent.ps1` | Does the push work with real authentication? The pilot origin is a **local bare repo — credentials were never exercised** (needs one-time Git Credential Manager setup) |
| N | `scan-repos.ps1 -Org <company org>` with GitHub CLI installed + authenticated | The `gh repo list` path is **documented but untested** (T8 used the file-list mode against local fixture repos) |
| O | Pick `intent`, give a real idea | Does the agent quote catalog evidence, ask before fetching, and confine writes to `features.md`? (guidance-level, like tests H/J) |

Also unverified organizational facts (prerequisites, not designable-around): OPC Y intake forms have stable referencable IDs; the OPS repos' GitHub plan tier; her Read role actually provisioned; **the intent repo actually created with her as Write and with the same confidentiality controls as the product repo** (its `session-diff.patch` files contain product source as diff text); whether org policy permits private-repo forking (only relevant if Option C is ever revisited).

## 7. Self-criticism — the standing list

1. **Guidance vs. enforcement.** Instructions and agent bodies are prompt text; models can ignore them (the docs ship a whole "Why is my instructions file not being applied?" FAQ). Only two things here are deterministic: the shell scripts (tested) and the server-side Read role. Every agent behavior claim carries test H/J/K uncertainty until the live pilot.
2. **Context raises probability, not certainty.** The chain ends with her eyes on the page because that is the only correctness check requiring zero trust in the model.
3. **Critique is only as good as the critic model.** The 6-point checklist forces evidence per point, but a weak model can pass bad designs. The developer review (stage 6) remains the real quality gate for production.
4. **Preview features.** Hooks and agent-scoped features are marked Preview; formats may change. Pin the VS Code version for the pilot.
5. **Cost.** The orchestrator's autonomous revise loop consumes model requests; capped at 2 loops deliberately.
6. **Compaction loss.** Long sessions may compact away early prompts; `PreCompact` cannot re-inject (documented: common output only). Capture persists everything to disk; the *next* session re-injects. Mid-session after compaction is an accepted gap.
7. **One instruction was refused, openly**: "commit the code to github" from her machine — it contradicts the decided Read-role guardrail. Changing that requires explicitly revoking the guardrail decision, not a silent redesign.

## 8. File inventory (all in `pilot/`, committed on `origin/main`)

```text
.github/
  copilot-instructions.md        standing rules + reflect-then-edit
  instructions/ui.instructions.md UI conventions (applyTo src/ui/**)
  hooks/capture.json             UserPromptSubmit + Stop → capture scripts
  hooks/context.json             SessionStart → inject-context.ps1
  agents/orchestrator.agent.md   manages designer+critic via subagents
  agents/designer.agent.md       idea → design doc (docs/agent/designs/ only)
  agents/critic.agent.md         6-point evidence-based critique (read-only)
  agents/builder.agent.md        implements approved design only
  agents/intent.agent.md         idea → company repo match → fetch context (§4.3)
  prompts/document-changes.prompt.md  correlate-not-recall session docs + brief refresh
.vscode/settings.json            autoApprove ask-gates on guardrail files
scripts/
  capture-prompt.ps1             her prompts → ideas.jsonl        (T1b ✅)
  capture-history.ps1            retro-mine past chat transcripts (T6 ✅)
  capture-session.ps1            session-end diff snapshot        (T2 ✅)
  sync-intent.ps1                intent repo commit+push          (T7 ✅)
  scan-repos.ps1                 org repo catalog builder         (T8 ✅ file mode; gh mode untested)
  fetch-repo-context.ps1         clone + extract md/inventory     (T8 ✅)
  inject-context.ps1             SessionStart context injection   (T5 ✅)
  handoff.ps1                    patch + zip for developers       (T3/T4b ✅)
docs/
  business/OPC-1234.md           sample intake form reference
  agent/                         NESTED INTENT REPO (§4.2) — her Write, product repo ignores it
  agent/active-brief.md          current form ID / goal / decisions
  agent/designs/                 design documents (in handoff zip)
  agent/sessions/                generated docs + _capture staging
src/ui/                          her HTML/CSS prototypes
```

Commit history (bare origin `pilot-origin.git`): `37b72af` baseline → `48dbe6a` context infra → `8943971` agent chain → `acf41ba` orchestrator + designer fix → `6d0497d` retro-capture script (T6) → `7d411c3` intent-repo infra (T7) → `e977314` untrack active-brief fix → `584ea9b` intent agent + repo scan/fetch (T8). Intent repo (bare origin `intent-origin.git`): baseline + T7 sync commits + `75d3467` repo catalog & context, authored by *Business User*.
