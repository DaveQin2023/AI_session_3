# Context Plan: From Captured Ideas to Correct Code Changes

Purpose: the capture subsystem (see `Design_Capture_Plan_from_copilot.md`) preserves the Business User's design ideas. This plan is the **forward direction**: how those ideas become **correct context** for the agent, so it designs and edits **based on her ideas** instead of guessing. Companion to `Guarded_Business-User_Agent_Workflow_from_copilot.md` (guardrails) — this document adds no new permissions and changes no enforcement.

All quotes below were fetched 2026-08-10 from:
- [Custom instructions docs](https://code.visualstudio.com/docs/copilot/customization/custom-instructions)
- [Agent hooks docs](https://code.visualstudio.com/docs/agent-customization/hooks)
- [Hooks reference](https://code.visualstudio.com/docs/agents/reference/hooks-reference)

## 0. The problem, stated precisely

LLM context is **per-session**. Within one chat session her prompts are already in the conversation — no mechanism needed. The gaps are:

| Gap | When it hurts | Covered by |
|---|---|---|
| **Session boundary** | She opens a new chat tomorrow; the agent knows nothing about yesterday's ideas or half-finished work | Component 3 (SessionStart injection) |
| **Missing standing knowledge** | Any session: agent doesn't know where UI code lives, project conventions, or that it must consult the intake form | Components 1–2 (instructions files) |
| **Missing current intent** | Agent doesn't know *which* feature/form she is working on right now | Component 4 (active brief) |
| **Context compaction** | Long session: early prompts get compacted away | **Not fully coverable** — see §3.2 |
| **Wrong result despite right context** | Always possible | Component 5 (verification loop) — context ≠ correctness |

## 1. The correctness chain

```
her idea (prompt / intake form / prior sessions)
  → CONTEXT (this plan): standing rules + active brief + session-start injection
    → agent restates the idea in plain language BEFORE editing (reflect-then-edit rule)
      → agent edits
        → VERIFICATION: she views the running page and confirms it matches her idea
          → CAPTURE (existing plan): ideas.jsonl + session-diff.patch
            → next session's context (loop closes)
```

Correctness is produced by the **whole chain**, not by context alone. Anyone claiming context injection *guarantees* correct code changes is lying — see §3.1.

## 2. Components (each with its verified mechanism)

### Component 1 — Standing project knowledge: `.github/copilot-instructions.md`

**Documented mechanism:** "VS Code automatically detects a `.github/copilot-instructions.md` Markdown file in the root of your workspace and applies the instructions in this file to all chat requests within this workspace." Zero-click, always-on.

Contents (see the scaffolded file in `pilot/`):
- Where the UI code lives and what technology it is.
- The **reflect-then-edit rule**: before editing, restate her idea in plain language, list the files to be touched, and ask her to confirm — so misunderstandings are caught *before* code changes, in language she can judge.
- Read `docs/agent/active-brief.md` and the linked intake form before UI changes. The docs support this pattern: "To reference specific context in your instructions, such as files or URLs, you can use Markdown links" (setting: `chat.includeReferencedInstructions`).
- Never commit/push (defense-in-depth restatement; real enforcement stays the Read role).

Writing style follows the docs' own tips: "Keep your instructions short and self-contained", "Include the reasoning behind rules".

### Component 2 — UI-specific conventions: `.github/instructions/ui.instructions.md`

**Documented mechanism:** `.instructions.md` frontmatter `applyTo` — "Glob pattern that defines which files the instructions apply to automatically, relative to the workspace root." With `applyTo: 'src/ui/**'` the conventions load exactly when the agent works on UI files, keeping Component 1 short.

### Component 3 — Cross-session memory: `SessionStart` hook → context injection

**This is the piece that makes captured ideas flow back in.** Two documented facts make it real:

1. Event: `SessionStart` — "User submits the first prompt of a new session — Initialize resources…". The hooks page lists "Inject context" as a primary hook use case.
2. Output: the SessionStart reference documents `hookSpecificOutput.additionalContext` — "Context added to the agent's conversation".

`scripts/inject-context.ps1` (wired in `.github/hooks/context.json`) emits JSON on stdout containing:
- `docs/agent/active-brief.md` (current form ID, goal, accepted decisions),
- the tail of recent `ideas.jsonl` (her ideas **verbatim**, capped — see §3.4),
- `git diff --stat origin/main` after `git add -N .` (what is in progress, including new files — the same untracked-file fix proven in the capture plan's tests).

Result: a brand-new session starts already knowing *what she said, what she's building, and what's half-done* — zero clicks.

**Verified negative — why not per-prompt injection:** the reference states "The `UserPromptSubmit` hook uses the common output format only" — it has **no** `additionalContext` field. There is no documented way to inject context on every prompt. Only `SessionStart`, `SubagentStart`, `PreToolUse`, and `PostToolUse` document `additionalContext`. This design uses session-start injection and does not pretend otherwise. (Mid-session this is fine: her prompts are already in the conversation.)

### Component 4 — Current intent: `docs/agent/active-brief.md`

A small, human-readable file: active form ID, her one-sentence goal, and decisions accepted so far. It is the *only* moving part the injection reads for intent.

Freshness loop: `/document-changes` (existing prompt file) now has a final step that updates the brief from the session it just documented, so the next session's injection reflects the latest state. She can also edit it by hand — it is plain language.

### Component 5 — Verification: correctness is observed, not assumed

The change is "correct" only when she sees her idea on screen. The workflow's allow-listed `npm run dev` (main document, Layer 2) exists for exactly this. The reflect-then-edit rule (Component 1) catches misunderstanding *before* the edit; her visual check catches it *after*. Both checkpoints are in language/imagery she can judge — no code reading required.

## 3. Self-criticism — stated before anyone finds it

1. **Instructions are guidance, not enforcement.** They are prompt text; models can ignore them. The docs implicitly admit this — they ship a whole FAQ section "Why is my instructions file not being applied?" and a diagnostics view. That is why the reflect-then-edit rule is a *ritual she can notice missing*, and why verification (Component 5) exists. Deterministic enforcement remains the Read role + PreToolUse guard, unchanged.
2. **Compaction loss is not fully solvable.** `PreCompact` fires "Before conversation context is compacted" but "uses the common output format only" — it can *export* state, not re-inject it. Partial mitigation only: capture already persists every prompt to `ideas.jsonl`, and the *next* SessionStart re-injects the tail. Mid-session after compaction, there is no documented re-injection path. Honest limit.
3. **Empty-stdout behavior is undocumented.** Exit code 0 means "Success: parse stdout as JSON"; the docs do not say what happens on empty stdout. The script therefore always emits valid JSON (`{}` when there is nothing to inject).
4. **Context budget.** Dumping every `ideas.jsonl` line ever would bloat/dilute the context. The script caps injection (last 2 capture days, max 30 idea lines, diff **stat** only — never the full diff). The cap values are engineering judgment, not doctrine — tune in the pilot.
5. **`SessionStart` semantics are thin.** Input `source` is "Currently always `new`" — behavior on window reload or resumed sessions is undocumented. Test F exists for this.
6. **Stale brief risk.** If `/document-changes` isn't run and she doesn't edit the brief, injection carries yesterday's intent. Mitigated (not eliminated) by injecting the ideas tail and diff-stat alongside — three sources rarely go stale together.
7. **Hook firing remains untestable headlessly.** The script *body* is tested (see §5); whether VS Code invokes it at session start requires the live pilot — same honest boundary as the capture plan.

## 4. Validation tests (extends the pilot matrix)

| # | Test | Expected |
|---|---|---|
| F | Fresh chat session, first prompt: "What form ID am I working on and what did I ask for last time?" | Agent answers from injected context (OPC-1234 + recent ideas) without reading files. Also test after window reload (§3.5) |
| G | Ask the agent to edit `src/ui/index.html`; check the response's **References** section | Both `copilot-instructions.md` and `ui.instructions.md` listed (docs: "Verify the References section in the chat response to see which instructions files were used") |
| H | Give a vague idea ("make it friendlier") | Agent restates interpretation in plain language and asks before editing (reflect-then-edit) — guidance-level, may fail; record rate |
| I | Session with >30 captured ideas across 3 days | Injection contains only the capped tail; no context blowup |
| T5 (headless, executable) | Pipe documented SessionStart stdin JSON into `inject-context.ps1` | stdout is valid JSON with `hookSpecificOutput.hookEventName == "SessionStart"` and `additionalContext` containing the brief, ideas tail, and diff-stat |

## 5. Empirical results (2026-08-10, pilot repo)

All files scaffolded into `pilot/`; infra committed and pushed to `origin/main` so only the Business User's UI work remains uncommitted (faithful to the real setup).

| Test | Evidence (actual terminal output) | Verdict |
|---|---|---|
| T5 first run | **FAILED — real bug found.** The em-dash in `active-brief.md` came through as `â?"` and the mangled bytes broke the JSON (`ConvertFrom-Json`: "':' or '}' expected" at char 249). Two PS 5.1 encoding defects: `Get-Content` without `-Encoding UTF8` misreads BOM-less UTF-8 as ANSI, and default stdout uses the OEM codepage | ✅ Defect proven, fixed in script |
| T5 retry | exit 0; `valid JSON: True`; `hookEventName: SessionStart`; brief (OPC-1234) ✓; verbatim idea "make the header blue with white text" ✓; new file `search-box.html` in diff-stat ✓; em-dash intact ✓; context = 1432 chars | ✅ Pass |
| F, G, H, I | Whether VS Code fires SessionStart, injects the stdout, applies both instructions files (References section), and whether the model follows reflect-then-edit | ⚠️ **Not executed** — require a live agent session with `pilot/` as workspace root |

Pattern worth naming: this is the **third** PS 5.1 encoding bug caught only by execution (`>` → UTF-16LE patches; `Get-Content` ANSI misread; OEM stdout). On Windows PowerShell 5.1, every byte boundary (redirect, file read, stdout) must state its encoding explicitly. How VS Code decodes hook stdout is undocumented — the script emits UTF-8 (the standard choice); test F must confirm the em-dash survives the live path.



What happens, step by step, with what each piece contributes:

                                  ┌──────────────────────────────┐
                                  │   Her idea, plain English    │◄─────────────────┐
                                  └──────────────┬───────────────┘                  │
                                                 │                                  │
                                                 ▼                                  │
                                  ┌──────────────────────────────┐                  │
                                  │      Agent restates it       │                  │
                                  │        (she confirms)        │                  │
                                  └──────────────┬───────────────┘                  │
                                                 │                                  │
                                                 ▼                                  │
                                  ┌──────────────────────────────┐                  │
                                  │    Agent writes the code     │                  │
                                  │ (built-in VS Code capability)│                  │
                                  └──────────────┬───────────────┘                  │
                                                 │                                  │
                                                 ▼                                  │
                                  ┌──────────────────────────────┐                  │
                       ┌──────────│    She looks at the page     │                  │
                       │          └──────────────┬───────────────┘                  │
                       │                         │                                  │
              "not what I meant"         "yes, that's it"                           │
                       │                         │                                  │
                       │                         ▼                                  │
                       │          ┌──────────────────────────────┐                  │
                       │          │  Captured: prompts + diff    │                  │
                       │          └──────────────┬───────────────┘                  │
                       │                         │                                  │
                       │             next session, auto-injected                    │
                       │                         │                                  │
                       │                         └──────────────────────────────────┤
                       │                                                            │
                       └────────────────────────────────────────────────────────────┘

The two loops read as:

Inner loop ("not what I meant"): she rejects the visual result → refines her idea in plain English → agent restates → edits again. This repeats within one session until the page matches her intent.
Outer loop ("next session, auto-injected"): at session end her prompts (ideas.jsonl) and the diff (session-diff.patch) are captured by hooks; the next session's SessionStart injection feeds them back, so tomorrow's agent starts already knowing what she said and built today.


┌────────────────────────────────────────────────────────────────────┐
│ THE ASSEMBLED PROMPT (what the model actually sees)                │
├────────────────────────────────────────────────────────────────────┤
│ 1. Injected context (above, automatic, SessionStart hook)         │
│    → brief + her past ideas verbatim + work in progress           │
│ 2. Standing rules (automatic, copilot-instructions.md)            │
│    → where UI code lives, restate-before-edit, never commit/push  │
│ 3. UI conventions (automatic when touching src/ui/**)             │
│    → ui.instructions.md via applyTo glob                          │
│ 4. HER NEW IDEA, typed in plain English                           │
│    → e.g. "make the search button match the header color"         │
├────────────────────────────────────────────────────────────────────┤
│ ▼ model output: the agent EDITS THE CODE                          │
│   Proof (chat docs): "The agent analyzes your code, makes the     │
│   changes, and responds with a summary."                          │
└────────────────────────────────────────────────────────────────────┘


Step	Who/what acts	What my design adds (and its proof)
1. First prompt of the session	SessionStart hook fires → inject-context.ps1 output enters the conversation	Agent already knows: form OPC-1234, her goal, her past ideas verbatim, what's half-done. Proof: additionalContext — "Context added to the agent's conversation" (hooks reference). Tested headlessly (T5 passed)
2. Same prompt, standing rules attach	VS Code auto-attaches copilot-instructions.md (+ ui.instructions.md when touching src/ui/**)	Agent knows: UI lives in src/ui/, plain HTML/CSS, read the brief, restate before editing. Proof: "applies the instructions in this file to all chat requests"
3. Reflect-then-edit	The agent (following the instructions) replies: "You want the page header background changed to blue with white text — I'll edit the .header style in src/ui/index.html. Correct?"	This is the misunderstanding-catcher, in language she can judge. Honest caveat: this is guidance, not enforcement — test H measures compliance
4. She says "yes" → the agent edits the code	Built-in agent capability — nothing of mine	Proof: "The agent analyzes your code, makes the changes." This is the idea→code conversion you asked about
5. She verifies visually	Opens the page (npm run dev is allow-listed) — is the header the blue she meant?	If not: she says "darker blue" and the loop repeats from step 4. Docs support: "Request revisions: send a follow-up prompt"; checkpoints can revert a bad edit
6. Session ends	Capture hooks record her prompts (ideas.jsonl) + the diff (session-diff.patch)	Already tested (T1b, T2 passed)
7. Tuesday, new session	Step 1 injects Monday's ideas + diff-stat → "continue with the search box" just works	Without this, Tuesday's agent would know nothing about Monday

