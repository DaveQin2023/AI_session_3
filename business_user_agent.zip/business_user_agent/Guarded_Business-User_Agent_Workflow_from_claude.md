# Guarded Business-User Agent Workflow

**Objective:** Let a non-developer Business User design UI locally in VS Code (with GitHub Copilot) while an agent converts her edits into reviewable plans, changelogs, and business-readable requirements — with direct commits/pushes structurally impossible. Prove out the guardrails on her work before scaling to other business users.

**Scope:** Two OPS repositories; no schema repo yet. Intake forms logged in the OPC Y system before conversion processing starts.

**Date:** 2026-08-09 · Prepared with Claude (Anthropic)

---

## 1. Core Design Principle (this determines everything else)

The single most important architectural fact: **local guardrails can never be the enforcement layer.** Git's client-side hooks live in `.git/hooks`, can be bypassed with `git commit --no-verify`, and do not travel with the repository when you commit and push — so any blocking done in VS Code is convenience/UX only. Real enforcement must live on the GitHub server side.

The design is therefore two-tier:

- **Tier 1 (authoritative): GitHub-side controls** — she *cannot* push even if every local control fails.
- **Tier 2 (advisory): VS Code-side controls** — she gets a friendly local experience and never *accidentally* hits the server wall.

## 2. Tier 1 — Server-Side Enforcement on the Two OPS Repos

### Option A (recommended, simplest): Read-only repository access

Give Business User the **Read** role on both OPS repositories. She can clone and pull, but Git will reject any push with a 403 — there is nothing to bypass. The doc-generation agent gets its own identity (a GitHub App or machine account with a fine-grained token scoped to only these two repos, with `Contents: write` and `Pull requests: write`). All commits enter GitHub under the *agent's* identity, never hers.

### Option B (if she must push scratch branches herself later): Write access + rulesets

Branch protection lets you enforce workflows — including requiring a pull request merge — before a collaborator can push changes to a branch. These rules can prevent direct pushes, force-pushes, and deletions, and can require PR reviews, status checks, and CODEOWNERS approval.

- Apply a ruleset to `main` (and any release branches) requiring PRs + at least one developer review.
- Check **"Do not allow bypassing the above settings"** so the rules apply to everyone, including administrators.
- Add a `CODEOWNERS` file mapping UI paths to the developer team so her feature area always routes to the right reviewers.

**Decision:** Given the requirement says "never direct commits," start with **Option A**. It is the only configuration where the guarantee is structural rather than rule-based.

## 3. Tier 2 — Local VS Code Experience

Since she works locally with Copilot, her clone should be configured so the "wall" is invisible in daily use:

1. A workspace-level **pre-commit hook** — installed via `core.hooksPath` pointing at a versioned `.githooks/` folder, or the pre-commit framework's `no-commit-to-branch` hook (blocks `main`/`master` by default) — that exits non-zero with a message like: *"Your changes are captured by the doc agent — no commit needed."*
2. VS Code **workspace settings** that de-emphasize the Source Control commit UI (it cannot be fully removed without an extension, and the design should not pretend otherwise).

**Honest framing for the team:** Tier 2 is etiquette, not security. Git lets you bypass most hooks with `--no-verify`, and even `core.hooksPath` can be overridden per-command — which is exactly why Tier 1 exists.

## 4. The Documentation Agent (the actual prototype)

### Capture

A local Node process (or VS Code extension) watches her working tree — VS Code's `FileSystemWatcher` or chokidar — and on save/debounce runs `git diff origin/main` plus `git status --porcelain` to snapshot her uncommitted edits.

> **Note:** Since she never commits, the working-tree diff *is* the change record. The agent must diff against the **remote tracking branch**, not HEAD.

### Generate

Feed the diff + file context + the OPC Y intake form ID into an LLM to produce three Markdown artifacts:

| Artifact | Purpose |
|---|---|
| `docs/agent/impl-plan-<feature>.md` | Technical implementation plan for developers |
| `docs/agent/changelog-<date>.md` | Per-session change log with file/hunk references |
| `docs/agent/requirements-<feature>.md` | Business-readable requirements, each linked back to the intake form ID and the specific UI files touched |

Two viable LLM paths:

1. **Via her Copilot subscription** — VS Code's Language Model API (`vscode.lm`): select models with `vscode.lm.selectChatModels({vendor: 'copilot'})` and call `sendRequest`. Copilot's models require **user consent** via an authentication dialog, so `selectChatModels` should be called as part of a user-initiated action. This means "click a button to generate docs," not fully unattended background generation. Requests can also fail on quota limits.
2. **Via a direct API key** (GitHub Models, OpenAI, Anthropic) in the Node service — fully automatable on every save, but separate billing and a key to manage. For an unattended agent, this is the more robust path.

**Pilot recommendation:** Implement the VS Code extension with an explicit **"Generate docs & submit"** command — it matches the consent model, gives her a clear mental action, and avoids generating docs on every half-finished keystroke.

### Deliver

On that command, the agent (using its own token):

1. Creates branch `bu/<feature>/<date>`
2. Commits her diff as a patch **plus** the three Markdown files
3. Opens a **draft PR** labeled `business-user-origin`

Developers review the docs and the diff together; nothing merges without their approval, enforced by the ruleset/CODEOWNERS from Tier 1.

## 5. Test Plan (validating the guardrails)

1. **Bypass attempts:** From her machine, try `git push`, `git push --no-verify`, push from the VS Code GUI, push via GitHub Desktop. Expected: 403 (Option A) or ruleset rejection on protected branches (Option B). *This is the pass/fail test for the whole objective.*
2. **Hook bypass:** Confirm `--no-verify` does defeat the local hook — and document that this is expected and harmless because Tier 1 still blocks.
3. **Doc fidelity:** Make a set of known UI edits, run generation, and have a developer score the plan/changelog/requirements against the actual diff. LLM output must be treated as fallible — "developer verifies against diff" belongs in the PR checklist, not as an optional step.
4. **Traceability:** Verify every requirement line links to a real file path and the OPC Y intake ID.
5. **Identity audit:** Confirm every commit in the repo history is authored by the agent identity or a developer — never Business User.

## 6. Self-Criticism and Verification Status

**Verified against documentation:**
- Client-side hooks are bypassable (`--no-verify`) and do not propagate to remotes — Git Book, "Customizing Git – Git Hooks" (git-scm.com); Adam Johnson, "Git: How to skip hooks."
- GitHub branch protection/rulesets can block direct pushes and require PRs, including for admins — GitHub Docs, "About protected branches" and "Available rules for rulesets."
- The `vscode.lm` API exists, can access Copilot models, and requires user-initiated consent — VS Code Extension API, "Language Model API" (code.visualstudio.com).

**Design judgment, not verified fact:** the recommendation of Read-only over Write+rulesets; draft PRs as the delivery mechanism; button-triggered rather than fully-automatic generation. Defensible trade-offs, not the only correct answers.

**Cannot verify / open items:**
- No information about the internals of the "OPS repositories," "OPC Y," or "conversion processing." The design treats OPC Y as an opaque source of intake-form IDs. If OPC Y has an API the agent should query for form metadata, that integration needs its spec.
- **Plan check:** On GitHub Free, protected branches are only available in *public* repositories; private repos need Pro, Team, or Enterprise. Verify which plan the OPS repos are on before relying on Option B. (Option A's read-only permissions work on any plan.)

**Ambiguity flagged for an explicit decision:** The requirement says her changes should reach developers as docs, but doesn't say whether her actual *code diff* may enter the repo at all. This design includes the diff in the agent's PR because a plan without the diff isn't reviewable. If policy forbids her code entering git even via the agent, replace the committed diff with a `.patch` file attached to the docs, and developers re-implement.

## 7. Next Steps

1. Decide: GitHub plan / Option A vs B, and whether the raw diff is allowed into the agent's PR.
2. Produce the concrete artifacts: ruleset JSON, `.githooks` scripts, and the VS Code extension skeleton.
3. Run the five-part test plan with Business User's real workflow before scaling to additional business users.
