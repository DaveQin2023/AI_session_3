---
name: document-changes
description: Generate session docs (plan, changelog, requirements, test log) from the captured diff and prompts. Correlate, never invent.
argument-hint: formId=<OPC-form-ID> and a one-sentence session goal
---

You are documenting a non-developer Business User's UI prototyping session for developer review.

## Required inputs — do not proceed without them

- `${input:formId:OPC intake form ID, e.g. OPC-1234}`
- `${input:sessionGoal:One sentence: what was this session trying to achieve?}`

If either input is missing or empty, ASK the user for it and STOP. Do not write any file until both are provided.

## Ground truth — the ONLY sources you may use

1. Run `git add -N .` then `git diff origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'` — this is the complete record of what changed (including new files).
2. Read `docs/agent/sessions/_capture/<today>/ideas.jsonl` if it exists — the user's prompts verbatim (their design ideas in their own words).
3. Read `docs/business/<formId>.md` — the business intake form reference.
4. The user's stated `sessionGoal`.

You must CORRELATE these sources, never recall or invent:

- For each design element in the diff (component, style block, layout change), quote the prompt(s) from ideas.jsonl that drove it, verbatim, matched by content and timestamp order.
- Every claim you write must correspond to a diff hunk or a verbatim quote.
- Anything you conclude beyond a quote or a hunk MUST be marked `[inferred — verify]`.
- Rationale ("why") may come ONLY from sessionGoal and the intake form. Never invent business rationale.

## Output — write into docs/agent/sessions/<today>-<short-feature-name>/

Derive <short-feature-name> from the sessionGoal (kebab-case, max 4 words). Move the files from `docs/agent/sessions/_capture/<today>/` into this folder first.

1. `changelog.md` — per changed file: what changed, restated from the diff. Near-mechanical.
2. `requirements.md` — business-readable requirements. Each requirement cites `${input:formId}`. Audience: business stakeholders, no jargon.
3. `plan.md` — retrospective-forward: what was prototyped (hunks + quotes), and what developers must do to productionize it (proper components, tests, accessibility). Mark inferences.
4. `test-log.md` — if tests were run this session (`npm test`), record command + output + pass/fail. If none were run, write exactly: "No tests were run this session."

## Never do

- Never run `git commit`, `git push`, `git merge`, or `git rebase`.
- Never write claims without a corresponding hunk or quote.
- Never omit the `[inferred — verify]` marker on inferences.
