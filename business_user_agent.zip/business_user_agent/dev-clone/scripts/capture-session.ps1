# capture-session.ps1 - Stop hook: snapshot the design-as-built at session end
# Writes session-diff.patch (git add -N first, so NEW files are included) and diff-stat.txt
# IMPORTANT: uses git's own --output option, NOT PowerShell '>' redirection.
# In Windows PowerShell 5.1, '>' writes UTF-16LE, which git apply cannot read.
# No AI involved. Exit 0 = success.
$ErrorActionPreference = "Stop"
try {
    $dir = "docs/agent/sessions/_capture/$(Get-Date -Format yyyy-MM-dd)"
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    git add -N . 2>$null
    git diff --output="$dir/session-diff.patch" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
    git diff --stat --output="$dir/diff-stat.txt" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
    # session-skeleton: mechanical file list + timestamp (no AI)
    $skeleton = @("# Session skeleton ($(Get-Date -Format s))", "", "## Changed files (vs origin/main)")
    $skeleton += (git diff --name-status origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff')
    Set-Content -Path "$dir/session-skeleton.md" -Value $skeleton -Encoding UTF8
    exit 0
} catch {
    Write-Error $_
    exit 1
}
