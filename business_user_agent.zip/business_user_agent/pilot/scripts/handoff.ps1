# handoff.ps1 - produce the developer handoff package: code patch + session docs zip
# Patch excludes generated folders via documented ':(exclude)' pathspec magic.
# Uses git --output (NOT '>') to avoid PowerShell 5.1 UTF-16 redirection breaking git apply.
param([string]$SessionName = (Get-Date -Format yyyy-MM-dd))
$ErrorActionPreference = "Stop"

New-Item -ItemType Directory -Force -Path handoff | Out-Null

# 1. Make newly created files visible to diff (documented: git add --intent-to-add)
git add -N . 2>$null

# 2. Generate the code patch (excludes generated docs and prior handoffs)
$patch = "handoff/$SessionName-changes.patch"
git diff --output="$patch" origin/main -- . ':(exclude)docs/agent' ':(exclude)handoff'
if ((Get-Item $patch).Length -eq 0) {
    Write-Warning "Patch is empty - no changes vs origin/main. Nothing to hand off."
    exit 1
}

# 3. Collect session docs (named session folders + raw capture + design docs) for the zip
$items = @($patch)
$sessionsRoot = "docs/agent/sessions"
if (Test-Path $sessionsRoot) {
    Get-ChildItem $sessionsRoot -Directory | ForEach-Object { $items += $_.FullName }
}
if (Test-Path "docs/agent/designs") { $items += (Get-Item "docs/agent/designs").FullName }

# 4. Zip it
$zip = "handoff/$SessionName-handoff.zip"
Compress-Archive -Path $items -DestinationPath $zip -Force

# 5. Sync intent history to the intent repo so the handoff moment is always persisted
try { & "$PSScriptRoot\sync-intent.ps1" -Message "handoff sync: $SessionName" } catch { Write-Warning "intent sync skipped: $_" }

Write-Host "Handoff package ready: $zip"
Write-Host "Contains: code patch + session docs + raw capture (ideas.jsonl / session-diff.patch)"
exit 0
