﻿# company-widgets

Reusable UI widgets for OPC web apps: quick-search box, branded header, form controls.

Used by the policy portal and the annuity quote tool.
