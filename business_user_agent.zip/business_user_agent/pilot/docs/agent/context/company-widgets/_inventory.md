﻿# company-widgets - mechanical inventory (2026-08-10T14:15:08)

Source: C:\Users\qinxi\business_user_agent\company-widgets.git (shallow clone in external/company-widgets)

package.json: name=company-widgets version=1.2.0 description=Shared OPC UI widget library

## File tree
- package.json
- README.md
- docs\usage.md
- src\searchbox.js

## Function names in .js files (regex heuristic `function\s+(\w+)` - not a full parse)
- initSearchBox  (src\searchbox.js)
