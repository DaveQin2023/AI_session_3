﻿# Usage

Import searchbox.js and call initSearchBox(elementId).
