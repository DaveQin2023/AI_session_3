﻿# Session skeleton (2026-08-10T07:13:03)

## Changed files (vs origin/main)
M	src/ui/index.html
A	src/ui/search-box.html
