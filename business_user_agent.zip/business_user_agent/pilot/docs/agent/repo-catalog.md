﻿# Company repo catalog

Generated 2026-08-10T14:14:56 by scan-repos.ps1. Mechanical excerpts only.

## company-widgets
- url: C:\Users\qinxi\business_user_agent\company-widgets.git
- package: company-widgets - Shared OPC UI widget library
- README excerpt:
  ```
  # company-widgets
  
  Reusable UI widgets for OPC web apps: quick-search box, branded header, form controls.
  
  Used by the policy portal and the annuity quote tool.
  ```

## annuity-calc
- url: C:\Users\qinxi\business_user_agent\annuity-calc.git
- README excerpt:
  ```
  # annuity-calc
  
  Annuity payout calculation library (fixed, indexed, immediate). Pure functions, no UI.
  ```

