﻿function initSearchBox(id) { /* attaches quick-search */ }
