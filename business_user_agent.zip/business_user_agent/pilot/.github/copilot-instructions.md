# Project instructions

This repository is a UI prototyping workspace for a Business User (non-developer) in insurance/annuity marketing. Her design ideas must drive every code change.

## Where things live

- UI code: `src/ui/` — plain HTML/CSS prototypes.
- Business intake forms: `docs/business/<formId>.md` — the business context for every change.
- Current work brief: `docs/agent/active-brief.md` — the active form ID, her goal, and accepted decisions.

## Before making any UI change (reflect-then-edit)

1. Read `docs/agent/active-brief.md` and the intake form it references, because the "why" of every change lives there, not in the code.
2. Restate the user's idea in one or two plain, non-technical sentences and list the files you plan to touch. Wait for her confirmation before editing, because she is not a developer and this restatement is her only chance to catch a misunderstanding before code changes.
3. If her request conflicts with the active brief or intake form, say so and ask — do not silently pick one.

## After making a UI change

- Tell her in plain language what changed and how to see it (`npm run dev` or opening the file), because she verifies visually, not by reading code.

## Never

- Never run `git commit`, `git push`, `git merge`, or `git rebase` — this workspace hands changes off via patches, and the repository role does not permit pushing.
- Never invent business rationale. If the reason for a change is not in the brief, the form, or her words, ask her.
