# Implementation Plan (FINAL): Guarded Business-User Agent Workflow

> Target environment: **VS Code with GitHub Copilot** (as specified in the requirement document).
> Date of verification against official docs and VS Code source code: **2026-08-09**.
> This is v2 (final). It incorporates the cross-review by a second agent (Claude) and corrections found by verifying both documents against primary sources. Decision already made by the team: **the Business User gets the Read-only role — that is the enforcement layer.**

## 1. Restating the objective (from the requirement document)

1. Business user edits UI locally; **never commits/pushes directly**.
2. An agent converts her edits into **plans, changelogs, and business-readable requirement docs**, linking UI edits back to business documents (OPC Y intake forms).
3. Developers review; guardrails are proven locally before scaling to other business users.

## 2. The one honest architectural truth first

**Anything that runs on her machine is advisory, not enforcement.** Git hooks are bypassable with `git commit --no-verify` / `git push --no-verify` (proof: [githooks(5)](https://git-scm.com/docs/githooks)), VS Code settings are editable by the user, approval prompts can be clicked through, and Copilot instructions are natural-language guidance, not a security boundary. The **only guaranteed enforcement is server-side permissions** — and that decision is made (Read role).

So the design is layered: **Layer 0 is the guarantee; Layers 1–3 are accident prevention and ergonomics.**

## 3. Layered design

### Layer 0 — Server-side enforcement (decided: Read-only role)

| Control | Mechanism | Proof |
|---|---|---|
| She cannot push at all | **Read** role on both OPS repos (Read allows clone/pull and opening issues, not push) | [GitHub docs: Repository roles for an organization](https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories/managing-repository-roles/repository-roles-for-an-organization) |
| Even developers can't push straight to main | Branch protection **ruleset**: require pull request before merging, restrict who can push | [GitHub docs: Rulesets](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-rulesets/about-rulesets) |
| Her diffs enter the repo only via a developer | Developer applies her patch on a branch and opens a PR under *their* identity; optionally `CODEOWNERS` on `src/ui/**` | [GitHub docs: CODEOWNERS](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners) |

The objective is **structurally satisfied** by the Read role — she has no credential path to write. (Corrected from v1's "mathematically satisfied": the guarantee holds only after verifying it, so it comes with a checklist.)

**One-time verification checklist (prerequisites):**

1. Check her **effective permission** in each repo's *Settings → Manage access* view — GitHub permissions are additive through team memberships; a direct Read role can be silently upgraded by a team grant.
2. From her machine, run `git push` — must fail with a 403/permission error. **This is the test that must never fail.**
3. Plan-tier check for the rulesets row (caught by the cross-review, missed in v1): on **GitHub Free, branch protection/rulesets work only on public repos; private repos need Pro/Team/Enterprise**, and "restrict who can push" requires an organization-owned repo (proof: [About protected branches — "Restrict who can push to matching branches"](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/about-protected-branches)). The Read-role row works on any plan.

Local commits on her clone remain technically possible and are **harmless** — nothing she commits locally can reach the shared codebase. Per the team decision, Layers 1–2 below are optional polish, not requirements.

### Layer 1 — Local polish (optional, all bypassable, all fine)

1. **VS Code workspace settings** (`.vscode/settings.json`): `"git.enabled": false` removes the built-in Git integration, so the accidental "Commit" button doesn't exist.
   **Proof it works at workspace scope**: the Git extension's source declares `"git.enabled": { "scope": "resource" }` — resource scope is workspace/folder-settable ([microsoft/vscode extensions/git/package.json](https://github.com/microsoft/vscode/blob/main/extensions/git/package.json)).
   **Honest caveats** (from the cross-review, accepted): it also disables diff decorations she might find useful for reviewing her own work, and she can trivially edit the setting back. UX, not enforcement.
2. **Keep `git.allowNoVerifyCommit` at its default `false`** — VS Code's commit UI then never even offers "no-verify" commit commands (verified in the same source file: default is `false`).
3. **Optional extras** (skip for minimum moving parts, since the server already rejects): bogus push URL (`git remote set-url --push origin PUSH_DISABLED_USE_HANDOFF`) and unconditional `.githooks/pre-commit`/`pre-push` via `core.hooksPath`. Caveats stated honestly: hooks are skipped by `--no-verify` ([githooks(5)](https://git-scm.com/docs/githooks)), and the push-URL trick is bypassed by pushing to an explicit URL (`git push https://…` — the repository argument "can be either a URL or the name of a remote", [git-push docs](https://git-scm.com/docs/git-push)). Both are accident prevention only.

### Layer 2 — Agent guardrails (constrain what Copilot itself can do)

All features below are documented (proof: [VS Code AI security docs](https://code.visualstudio.com/docs/copilot/security), [agent customization docs](https://code.visualstudio.com/docs/copilot/customization/overview), [agent hooks docs](https://code.visualstudio.com/docs/agent-customization/hooks), all verified 2026-08-09). This layer covers the threat the cross-review's own first design missed: *the agent itself* running git commands on her behalf.

1. **Agent hooks — the deterministic control.** `.github/hooks/guard-git.json` with a `PreToolUse` hook that denies any terminal command matching `git (commit|push|merge|rebase)`. Hooks "execute your code at specific lifecycle points with guaranteed outcomes" and can "block dangerous commands … regardless of how the agent was prompted"; `PreToolUse` output supports `permissionDecision` allow/deny/ask, and when multiple mechanisms combine, **the most restrictive wins**.
   Hooks also power Layer 3's deterministic capture: the documented event list includes `UserPromptSubmit` (fires when the user submits a prompt — documented use case: "Audit user requests"; documented input field `prompt`), `PostToolUse` (after each tool call), and `Stop` (agent session ends), and the hooks page explicitly names "Create audit trails: Log every tool invocation" as a use case — `.github/hooks/audit-log.json` uses all three (see Layer 3).
   **Implementation trap (correction to v1, found in the exit-code table):** exit code `2` = blocking error, but **any other non-zero exit is a non-blocking warning** — a hook that exits `1` does NOT block. The deny hook must exit `2` or emit `permissionDecision: "deny"`.
   **Preview caveats (from the cross-review, accepted):** the feature page is titled "(Preview)" and says format/behavior may change — pin VS Code versions for the pilot. Timeout behavior (default 30 s) is **not documented as fail-open or fail-closed for VS Code** — treat as unknown and test it (test #8). Copilot CLI's hooks reference says timeouts fail open; do not assume VS Code matches.
2. **Terminal approval rules.** By default the agent asks approval for terminal commands; auto-approval uses configurable per-command rules (including regex). Allow-list only safe commands: `npm run dev`, `npm test`, and the read-only git commands the doc pipeline needs (`git diff`, `git status`, `git add -N` — index-only, no commit) — never git write commands (consistent with the deny regex in item 1, which blocks `commit|push|merge|rebase`). **Honest caveat:** the docs call this best-effort — command parsing "has known limitations with shell aliases, quote concatenation, and complex shell syntax" — and bypass modes (Bypass Approvals / Autopilot) exist. Layer 0 is the safety net.
3. **Protected file edits — corrected glob set.** v1 protected the wrong files (`.githooks/`, `.vscode/`) while leaving the agent free to edit its own leash. The cross-review caught this, and VS Code's own hooks-page *Safety* section confirms it: "If the agent has access to edit scripts run by hooks, then it has the ability to modify those scripts during its own run … We recommend using `chat.tools.edits.autoApprove` to disallow the agent from editing hook scripts without manual approval." Corrected configuration:

   ```jsonc
   "chat.tools.edits.autoApprove": {
     "**/.github/hooks/**": false,
     "**/.github/agents/**": false,
     "**/.github/copilot-instructions.md": false,
     "**/.github/prompts/**": false,
     "**/.vscode/**": false,
     "**/.githooks/**": false,
     "**/scripts/**": false
   }
   ```

   **Semantics caveat (from the cross-review, accepted):** `false` means *ask for confirmation*, not *block* — she can still click Approve. Training + Layer 0 cover the gap.
4. **`.github/copilot-instructions.md`** — behavioral guidance: "You are assisting a non-developer business user. Never run git commit/push. After every editing session, regenerate the session docs in `docs/agent/sessions/`. Edits allowed only under `src/ui/**` and `docs/**`." Weakest control (prose), still worth having.
5. **Custom agent** `.github/agents/ui-designer.agent.md` with a restricted tool set (file edit/read; terminal governed by the hook above) — custom agents with tool restrictions in YAML frontmatter are documented. (The cross-review's claim that the same `.github/agents` folder works in Visual Studio 18.4 is **unverified** — its source was a Medium post. Not load-bearing here; the requirement specifies VS Code.)
6. If the org manages VS Code centrally: enterprise policies `ChatToolsAutoApprove` (blocks global auto-approve / Bypass Approvals / Autopilot) and `ChatToolsTerminalEnableAutoApprove` — these exact identifiers are named on the [VS Code security page](https://code.visualstudio.com/docs/copilot/security) (the cross-review couldn't verify them; I did). Re-confirm against the [enterprise policies page](https://code.visualstudio.com/docs/enterprise/policies) at rollout time.

### Layer 3 — Automated documentation pipeline

**Minimal pilot cut (start here — v2.3).** Stripped to what the requirement actually needs on day one, the pipeline is three pieces: (1) the **Read role** (already decided — the whole guarantee, zero build effort); (2) **one prompt file** `/document-changes` that runs `git add -N . && git diff origin/main` and writes the session docs; (3) **one handoff script** producing patch + zip. Everything else in this layer — audit hooks, `session-skeleton.md`, `_capture/` staging — is **deferred hardening**: it solves real but secondary failure modes ("she forgets to run the command", "prove what the agent did") and uses a Preview feature; add it only if the pilot shows the need. Two elements of the minimal cut are *not* droppable, both provable: `git add -N` before diffing (bare `git diff` silently omits newly created files — see the diff-base correction below) and her two typed inputs (`formId`, one-sentence goal), because ideas/intent are **not in the diff** — a diff is content, not motive, and extracting "design intent" from hunks alone means the LLM invents it.

The full structure below is the scale-up version; the pilot builds the subset marked minimal.

Repo structure to add:

```
.github/
  copilot-instructions.md
  hooks/guard-git.json                 # PreToolUse deny hook (exit 2 / permissionDecision deny)
  hooks/audit-log.json                 # UserPromptSubmit + PostToolUse + Stop: deterministic capture (her ideas verbatim + audit + skeleton)
  agents/ui-designer.agent.md
  prompts/document-changes.prompt.md   # "/document-changes" slash command
.vscode/
  settings.json                        # git.enabled=false + corrected autoApprove globs
docs/
  business/                            # OPC Y intake form references (source of truth)
  agent/
    sessions/
      _capture/2026-08-09/             # hook staging — date-based, because hooks fire before any
        ideas.jsonl                    #   feature name exists and shell scripts can't know it
        audit.jsonl                    # ideas.jsonl = UserPromptSubmit hook: her chat prompts verbatim (her design ideas, no AI)
        session-diff.patch             # Stop hook: add -N + diff snapshot at session end (design-as-built, no AI)
        session-skeleton.md            # written by Stop hook — file list + diff stats, no AI involved
      2026-08-09-<feature>/            # per-session folder (corrected from v1)
        audit.jsonl                    # moved here from _capture/ by /document-changes
        session-skeleton.md
        plan.md
        changelog.md
        requirements.md
        test-log.md
handoff/                               # generated patches + zips (excluded from the patch itself)
scripts/
  setup-guardrails.ps1                 # VS Code version check + optional Layer 1 setup
  handoff.ps1                          # produces handoff package (Windows assumed — stated explicitly)
```

**Corrections from the cross-review (accepted):**

- **Per-session dated folders replace v1's single accumulating `PLAN.md`/`CHANGELOG.md`/`REQUIREMENTS.md`** — shared accumulating files are a merge-conflict trap: every session's patch touches the same files, out-of-order patches fail `git apply`, and two business users (the stated scaling goal) guarantee conflicts. A *living* consolidated requirements doc still has business value — developers consolidate it post-merge; the agent never rewrites a shared file.
- **Explicit diff base — with the untracked-file correction (v2.2):** the prompt file instructs the agent to run `git add -N .` then `git diff origin/main` — not bare `git diff` against an implicit HEAD. Two reasons, both documented git behavior: (a) since she never commits, the working tree diffed against the remote tracking branch *is* the change record, and it stays correct even if a stray local commit exists; (b) **`git diff` alone omits untracked files entirely** — and a business user prototyping UI will routinely *create new files*, which would silently vanish from both the docs and the handoff patch. `git add --intent-to-add` (`-N`) is the documented fix: "Record only the fact that the path will be added later … useful for, among other things, showing the unstaged content of such files with `git diff`" ([git-add docs](https://git-scm.com/docs/git-add)). It touches only the local index — no commit, harmless under the Read role.
- **`.ps1` scripts assume Windows** — stated explicitly. If that changes, agent hooks support per-OS `windows`/`linux`/`osx` command overrides (documented on the hooks page).

**Two-layer pipeline — because "AI-driven" and "reliable log" conflict.** A single LLM step that both records what changed *and* narrates it is the wrong design: if the LLM hallucinates, the only record is the hallucination. The derivation chain separates them:

```
her edits → git diff origin/main (deterministic, lossless)
          → + audit.jsonl from PostToolUse hook (deterministic)
          → LLM narrative over those inputs (draft, human-reviewed)
```

**Layer A — deterministic capture (fully automatic, no AI):** `.github/hooks/audit-log.json` captures to the date-based staging folder `docs/agent/sessions/_capture/<date>/`: (1) **her design ideas verbatim** — a `UserPromptSubmit` hook appends each chat prompt she types (the documented `prompt` input field, plus documented `timestamp`/`session_id` common fields) to `ideas.jsonl`; the docs name "Audit user requests" as this event's use case, and warn that the alternative `transcript_path` "is not a stable hook API" — so the design uses the stable `prompt` field; (2) one JSONL line per agent tool call (tool, file, timestamp) via `PostToolUse` → `audit.jsonl`; (3) on `Stop`, `session-diff.patch` (`git add -N` + excluded-pathspec diff — the design-as-built snapshot) and `session-skeleton.md` (file list, diff stats, timestamp). **Why both sources, provably:** the diff shows only the *final* state — if she tried red then settled on blue, the diff says "blue" and the exploration is invisible; `ideas.jsonl` preserves the iteration path in her own words. Staging is date-based, **not** the named session folder, which cannot exist yet: hooks fire from the first prompt, before any feature name is known (v2.2 correction). Honest limits: `ideas.jsonl` captures only ideas routed through chat — manual edits without chat leave it empty for that change (the diff and her typed goal still cover the *what* and *why*); whether `UserPromptSubmit` fires for **inline chat** (Ctrl+I) is not documented — pilot test, not assumption (test #13). Even if she forgets the slash command, a session is never *undocumented*, only *un-narrated*. The model is never asked to recall what changed; it is handed the ground truth and asked to explain it.

**Layer B — the narrative loop** (using documented [prompt files](https://code.visualstudio.com/docs/copilot/customization/prompt-files) reusable as `/` commands):

1. She edits UI files with the `ui-designer` agent (or manually).
2. She runs `/document-changes formId=OPC-1234` with a one-sentence session goal. The prompt file **requires two human inputs before writing anything** — `${input:formId}` and `${input:sessionGoal}` — and instructs the agent to ask if either is missing. This closes the **intent gap**: a diff proves *what* changed, never *why*; without her stated goal, the LLM would invent her business rationale — exactly the fabrication this workflow must prevent. Rationale may come only from her stated goal plus the referenced intake form; anything else must be marked `[inferred — verify]`. (Proof the input mechanism exists: prompt files document `${input:variableName}` and passing arguments at invocation. Docs' own hedge, kept: "*Most* language models understand this syntax" — hence the ask-if-missing instruction.)
3. The agent runs `git add -N .` then `git diff origin/main` (so newly created files are included — see the diff-base correction above), moves the `_capture/<date>/` files into the dated session folder, then **correlates, not recalls**: for each design element in the diff (component, style block, layout change) it quotes the prompt(s) from `ideas.jsonl` that drove it, verbatim, matched by content and timestamp order; anything beyond a quote or a hunk is marked `[inferred — verify]`. Output per element: *what* (hunk) + *her words* (quote) + *why* (typed goal + form ID). It then writes `plan.md`, `changelog.md`, `requirements.md`, `test-log.md`. **Honesty about the seams:** quotes and hunks are ground truth; the prompt↔hunk *pairing* is LLM judgment — draft quality, reviewed like all narrative; the raw files travel in the handoff zip so a developer can re-derive the pairing from scratch. Intake-form linkage is **explicit input, not LLM guesswork**: form ID in, form ID out — mechanically checkable by a reviewer. Tests run via allow-listed `npm test` are recorded in `test-log.md`; if none were run, it must say so. **Minimal-pilot fallback without hooks:** if she runs `/document-changes` in the *same chat session* as the work, her prior prompts are already in the model's context (prompt files run in the current session — documented invocation behavior); weaker than `ideas.jsonl` (lost on new sessions or context compaction), which is why idea capture is first in the hardening queue.
4. `scripts/handoff.ps1` runs `git add -N .` then `git diff origin/main -- . ':(exclude)docs/agent/**' ':(exclude)handoff/**' > handoff/<date>-changes.patch` — the `:(exclude)` pathspec (documented [pathspec magic](https://git-scm.com/docs/gitglossary#Documentation/gitglossary.txt-aiddefpathspecapathspec)) keeps generated docs and prior patches out of the code patch; the session docs travel in the zip alongside it, not inside it. Package goes to developers.
5. A developer reviews docs **against the diff** (every claim must correspond to a hunk — mandatory PR checklist item), runs `git apply`, opens a PR under their identity → normal review, CI, branch protection.

**Per-artifact derivability, honestly graded:**

| Artifact | Derivation from her edits | Confidence |
|---|---|---|
| `changelog.md` | Near-mechanical restatement of the diff | High — lowest inference distance |
| `requirements.md` | Diff + explicit form ID + `docs/business/` references | Medium-high — linkage is explicit input; prose needs review |
| `plan.md` | Diff (*what*) + her stated goal (*why*) → what developers must do to productionize | Medium — rationale bounded by required inputs |

**Semantic note on `plan.md`:** since her edits already exist when it is generated, it is necessarily *retrospective-forward* — "here is what was prototyped; here is what developers must do to productionize it (proper components, tests, accessibility)." That matches the requirement's workflow (bare-bones UI → developer review); if stakeholders expect a *pre-edit* planning document instead, that is a different artifact — flag it in the pilot review rather than quietly reinterpret.

**Honesty about "automatically":** only Layer A is fully automatic. The narrative requires one manual trigger per session, because the prompt files docs state plainly: "Unlike custom instructions that are applied automatically, you invoke prompt files manually in chat." There is no documented zero-click LLM-generation path in VS Code chat (a `Stop` hook runs shell scripts, not LLM calls — hence it generates the mechanical skeleton only). Accurate label: **autonomous capture, one-click narration.** If stakeholders require literally zero clicks, the honest answer is a custom extension (`vscode.lm`) or a server-side pipeline — say so, don't pretend.

**Handoff transport — pilot vs. scale:** the patch handoff keeps **zero write credentials on her machine** (the decisive argument against the alternative bot-PR design: a write-capable token on her machine *is* push access, quietly defeating the read-only guarantee). Accepted trade-off from the cross-review: patches lack a threaded audit trail. If handoffs become frequent, the escalation path preserving both properties is: she opens a GitHub **issue** with the patch attached (the Read role permits opening issues), and a **GitHub Action** (credentials live server-side only) converts it into a draft PR labeled `business-user-origin`.

### Layer 4 — Local validation test plan

| # | Test | Expected |
|---|---|---|
| 1 | `git push` (normal, `--no-verify`, and to an explicit URL) | Server rejects with 403 (Read role) — **the test that must never fail** |
| 2 | Effective-permission audit | Her role shows Read in both repos' Manage access; no team grants Write |
| 3 | Commit via SCM UI | UI absent (`git.enabled: false`) — also verifies workspace-scope behavior empirically |
| 4 | `git commit` in terminal (if Layer 1 hooks installed) | Blocked with guidance message; `--no-verify` bypasses it → documented known limitation, harmless under Read role |
| 5 | Ask Copilot agent "commit and push my changes" | PreToolUse hook denies (exit 2 / `permissionDecision: "deny"`); agent explains the handoff workflow |
| 6 | Sample UI edit + `/document-changes` | Agent prompts for `formId`/`sessionGoal` if missing; new dated session folder with 4 docs; every claim in the docs corresponds to a diff hunk; form ID cited correctly — human-reviewed |
| 7 | Developer applies `changes.patch` — sample edit **must include a newly created file**, not just modifications | Patch contains the new file (proves the `git add -N` fix works); applies cleanly; PR opens; branch protection enforces review |
| 8 | **Hung PreToolUse hook** (script that sleeps past timeout) | Determine empirically whether VS Code fails open or closed on hook timeout — undocumented; record the result |
| 9 | **Agent asked to edit `.github/hooks/` or `.github/agents/`** | Edit requires manual approval (corrected globs); confirm the prompt appears |
| 10 | **Bypass Approvals / Autopilot mode enabled** | Confirm what it defeats (terminal approval, edit approval) and that Layer 0 still blocks push |
| 11 | **Identity audit** (from the cross-review) | Every commit in repo history is authored by a developer — never the Business User |
| 12 | **Deterministic capture** (end an agent session without running `/document-changes`) | `_capture/<date>/` contains `ideas.jsonl` (one line per prompt she typed), `audit.jsonl` (one line per tool call), `session-diff.patch`, and `session-skeleton.md` — session is documented even without narration |
| 13 | **Inline chat capture** (make an edit via inline chat, Ctrl+I) | Determine empirically whether `UserPromptSubmit` fires for inline chat — undocumented; record the result and train accordingly |

## 4. Honest limitations and open items

1. **Doc quality is not guaranteed.** LLM-generated changelogs/requirements can be wrong or incomplete. Developer review before merge is mandatory — put "verify docs against the diff" in the PR checklist, not as an optional step. The mitigation is structural: the deterministic diff + `audit.jsonl` always exist as ground truth to check the prose against. Residual risk: if she supplies the wrong `formId`, the docs will confidently link to the wrong business document — reviewer verifies against `docs/business/`; acknowledged, not eliminated.
2. **Local commits cannot be absolutely blocked** — hooks are bypassable by documented git behavior. Integrity is protected by Layer 0 (Read role), which the team has already chosen. Test 4's bypass "failing" is expected and harmless.
3. **Prompt injection risk**: an agent reading untrusted content can be steered — which is exactly why git-blocking rests on deterministic hooks and server permissions, not instructions. VS Code's security docs explicitly say not to rely on auto-approval rules alone.
4. **Feature currency**: agent hooks are **Preview**; terminal auto-approve rules are recent. Pin VS Code versions for the pilot; `setup-guardrails.ps1` should check the VS Code version. On older VS Code, Layer 2 degrades to items 4–5 (instructions only) — Layer 0 is unaffected. One additional prompt-file caveat from the docs: prompt files run with local agents in the VS Code extension host, not on the "Agent Host" — her documented setup is the former, but test #6 confirms empirically.
5. **Verified vs. unverified — full disclosure:**
   - *Verified against primary sources (2026-08-09)*: GitHub roles/rulesets/CODEOWNERS and plan-tier limits; githooks bypassability; `git push` explicit-URL behavior; **`git diff` omitting untracked files and `git add --intent-to-add` as the documented fix (git-add docs); `:(exclude)` pathspec magic (gitglossary)**; agent hooks (Preview status, `PreToolUse`/`PostToolUse`/`Stop` events, audit-trail use case, `permissionDecision`, exit-code semantics, file locations, Safety-section self-protection guidance, per-OS commands); prompt files (manual invocation quote, `${input:variableName}` syntax with the docs' own "most language models" hedge, argument passing at invocation); `chat.tools.edits.autoApprove` ask-semantics; terminal auto-approve best-effort caveats; enterprise policy identifiers; `git.enabled` resource scope and `git.allowNoVerifyCommit` default (both from VS Code source code).
   - *Unverified / open*: VS Code hook-timeout fail-open/fail-closed (test #8); Visual Studio 18.4 `.github/agents` support (weak source, not load-bearing); OPC Y internals and the OPS repos' GitHub plan tier (organizational facts — confirm before relying on rulesets).
6. **Not invented**: the OPC Y system, the two OPS repos, and the handoff transport are the organization's specifics — the design works around them without assuming details the requirement document does not give.

## 5. Revision history

- **v1 (2026-08-09):** initial layered design.
- **v2 final (2026-08-09):** incorporated cross-review by a second agent. Accepted: effective-permission check, plan-tier prerequisite, `git.enabled` caveats, hook Preview/timeout caveats, corrected `autoApprove` glob set (self-protection gap), ask-vs-block semantics, per-session doc folders, explicit `origin/main` diff base, Windows assumption, tests 8–11. Corrected v1 errors: "mathematically satisfied" wording, exit-code trap (exit 1 does not block a PreToolUse hook), guardrail self-edit gap. Rebutted with proof: enterprise policy identifiers are documented. Kept with justification: patch-based handoff (no write token on her machine), with issue→Action→draft-PR as the scale-up path.
- **v2.1 (2026-08-09):** Layer 3 rebuilt as a two-layer pipeline after self-review of the "automatically generate docs" requirement. Added: deterministic capture (`PostToolUse` audit hook → `audit.jsonl`, `Stop` hook → `session-skeleton.md`); required prompt inputs `${input:formId}` + `${input:sessionGoal}` closing the intent gap (explicit linkage instead of LLM inference — this corrected v2, which had the weaker inference-based wording); `[inferred — verify]` marking rule; per-artifact derivability grading; `plan.md` retrospective-forward semantics; "autonomous capture, one-click narration" honesty (prompt files are manually invoked, per docs); Agent Host caveat; test #12 and strengthened test #6.
- **v2.2 (2026-08-09):** full end-to-end audit pass found and fixed three defects all prior reviews (mine and the cross-reviewer's) missed. (1) **Untracked-file gap**: `git diff origin/main` omits newly created files — the most likely output of UI prototyping — so they would silently vanish from docs and patch; fixed with `git add -N` before diffing (documented git-add behavior) and `:(exclude)` pathspecs for generated folders; test #7 strengthened to require a new file. (2) **Hook chicken-and-egg**: capture files were shown inside the feature-named session folder, but hooks fire before any feature name exists; fixed with date-based `_capture/` staging that `/document-changes` moves. (3) **Allow-list inconsistency**: Layer 2 allowed only npm commands while Layer 3 called `git diff` allow-listed; Layer 2 now explicitly allow-lists read-only git commands. Also fixed a typo ("Tests 4's").
- **v2.3 (2026-08-09):** added the **minimal pilot cut** after a fair over-engineering challenge from the user. Core admission: the pipeline's essence is (add -N + diff) + (her stated goal + form ID) → LLM narrates → zip to developers — three pieces (Read role, one prompt file, one handoff script). Audit hooks/skeleton/staging reclassified as deferred hardening (secondary failure modes, Preview feature), consistent with the requirement's own "test locally first, then scale" instruction. The two non-droppable elements are retained with proof: `git add -N` (untracked-file correctness) and the typed inputs (intent is not in the diff).
- **v2.4 (2026-08-09):** answered "where are her design *ideas* captured?" and upgraded the design with a verified mechanism: a **`UserPromptSubmit` hook** logging her chat prompts verbatim to `ideas.jsonl` — the documented event ("User submits a prompt — Audit user requests") with the documented `prompt` input field; `transcript_path` rejected as unstable per the docs' own warning. Ideas now have three sources: the code diff (design as built, automatic), her prompts (ideas in her own words, automatic via hook — or same-session chat context as the minimal-pilot fallback), and her typed one-sentence goal (intent, deliberately manual — the only manual step, keeping her the author of the "why"). Self-criticism recorded: earlier versions captured what the *agent* did but not what *she said*; the user's question exposed it.
- **v2.5 (2026-08-09):** made both design sources zero-click and added the correlation step. `Stop` hook now snapshots `session-diff.patch` (add -N + excluded-pathspec diff) so the design-as-built is captured automatically at session end, not only at narration time. Documented *why both sources are needed*: the diff shows only the final state (exploration invisible); `ideas.jsonl` preserves the iteration path verbatim. `/document-changes` now explicitly correlates prompt↔hunk with verbatim quotes, marking everything else `[inferred — verify]` — quotes and hunks are ground truth, the pairing is reviewed draft. New honest unknown: whether `UserPromptSubmit` fires for inline chat is undocumented → test #13.
- **v2.6 (2026-08-10):** **first empirical validation.** The scripts were scaffolded into a real repo (`pilot/` + bare `pilot-origin.git`) and the executable test subset was run. Results — see §6 below and `Design_Capture_Plan_from_copilot.md` §8 for terminal evidence: negative control confirmed (bare `git diff` really omits the new file); prompt capture, session capture, exclusion pathspec, and end-to-end patch apply on a fresh clone all passed. **One real defect found in the documented scripts and fixed:** in Windows PowerShell 5.1, `>` redirection writes UTF-16LE, and `git apply` rejects such patches ("No valid patches in input", exit 128 — proven empirically); the scripts now use git's own `--output=<file>` option. Second workflow lesson from a test failure: stray untracked files in the working tree are swept into the patch by `git add -N .` — the handoff patch's file list must be reviewed (it is printed by the script). Hook *firing* tests (A/B/D) and narration test (C) remain not executable headlessly — they need a live VS Code agent session with `pilot/` as workspace root.

## 6. Empirical test results (v2.6, 2026-08-10)

Executed in `pilot/` (Windows PowerShell 5.1, real git repo with bare origin). Full script contents and proof tables: [Design_Capture_Plan_from_copilot.md](Design_Capture_Plan_from_copilot.md).

| Test | What it proves | Result |
|---|---|---|
| T1a negative control | Bare `git diff origin/main` omits the newly created `search-box.html` (only `M index.html` shown; new file is `??` in status only) | ✅ Confirmed — the v2.2 untracked-file fix addresses a real bug |
| T1b prompt capture | `capture-prompt.ps1` fed documented stdin JSON appends both prompts verbatim to `ideas.jsonl` | ✅ Passed |
| T2 session capture | `capture-session.ps1` patch **includes** the new file (after `add -N`) and **excludes** `docs/agent` | ✅ Passed |
| T2b encoding proof | PS 5.1 `>` redirect patch starts with bytes `255,254` (UTF-16LE BOM); `--output` patch starts with `100,105,102,102` (ASCII `diff`) | ✅ Defect proven; scripts fixed to `--output` |
| T3 handoff | `handoff.ps1` produces patch + zip | ✅ Passed |
| T4a corrupt patch | `git apply` rejects the UTF-16 patch (exit 128) | ✅ Failure mode proven |
| T4b end-to-end | Fresh clone from bare origin + `git apply` handoff patch → new file exists, header edit present, exit 0 | ✅ Passed (after fixing two test-harness bugs: bare-repo HEAD pointed at `master` not `main`; a stray temp file contaminated the patch via `add -N .`) |
| A/B/D hook firing, C narration | Whether VS Code actually invokes the hooks and how the LLM narrates | ⚠️ **Not executed** — requires a live agent session with `pilot/` opened as workspace root |

Detailed capture-subsystem design (sources rationale, script contents, per-field proof tables): see [Design_Capture_Plan_from_copilot.md](Design_Capture_Plan_from_copilot.md) §0–§2.

**Forward direction — captured ideas as context for correct code changes:** see [Design_Context_Plan_from_copilot.md](Design_Context_Plan_from_copilot.md) (v1, 2026-08-10). Verified mechanisms: always-on `.github/copilot-instructions.md` + `applyTo`-scoped `ui.instructions.md` (standing knowledge + reflect-then-edit rule), `SessionStart` hook with documented `hookSpecificOutput.additionalContext` output injecting the active brief + verbatim ideas tail + diff-stat into each new session, and `docs/agent/active-brief.md` refreshed by `/document-changes`. Verified negative: `UserPromptSubmit` "uses the common output format only" — no per-prompt injection exists; the design does not pretend otherwise. Headless test T5 passed after finding and fixing a third PS 5.1 encoding bug (ANSI file read + OEM stdout corrupted the JSON); live tests F–I pending.

## §3 — the one-click correlation step: correlate-not-recall rules, mandatory formId/goal inputs, [inferred — verify] marking, and the two honesty statements ("autonomous capture, one-click narration"; pairing is draft, quotes/hunks are ground truth).

## §4 — self-protection of the capture subsystem (hooks-page Safety recommendation, with the ask-not-block caveat).

## §5 — validation tests A–E, cross-referenced to the main document's numbering.

## §6–7 — the self-criticism list and explicit scope boundaries.



####  The minimal pilot (what actually gets built first) — three pieces
#	Piece	What it does
#### 1	Read role	The entire "can't commit" guarantee. Zero build effort — already decided
#### 2	One prompt file — /document-changes	Runs git add -N . && git diff origin/main, takes two typed inputs (formId, one-sentence goal), writes changelog/requirements/plan into a dated session folder
#### 3	One handoff script	git diff origin/main (with :(exclude) pathspecs for generated folders) → changes.patch, zipped with the docs, sent to developers, who git apply and open the PR under their identity

## Two elements of this minimum are not droppable, both with proof:

. git add -N before diffing — bare git diff omits untracked files, and new files are what UI prototyping produces; without this they silently vanish from docs and patch. Documented fix: --intent-to-add is "useful for, among other things, showing the unstaged content of such files with git diff" (git-add). Found in my v2.2 audit — missed by every earlier review, including the other agent's.

. Her two typed inputs — a diff is content, not motive; "extracting the design intent" from hunks alone means the LLM invents it. Her goal sentence + form ID make the business linkage explicit input, mechanically checkable by a reviewer (form ID in → form ID out). Mechanism proof: ${input:variableName} and invocation arguments are documented in prompt files — with the docs' own hedge ("most language models understand this syntax"), so the prompt says ask-if-missing.

#### Deferred hardening (built only if the pilot shows need)
. Agent-side git blocking: PreToolUse hook denying git (commit|push|merge|rebase) — real, documented, deterministic (agent hooks), but Preview, with a known trap (deny requires exit code 2 or permissionDecision:"deny" — exit 1 does not block) and undocumented timeout behavior (pilot test #8).
. Deterministic capture: PostToolUse audit log + Stop-hook session skeleton, staged in a date-based _capture/ folder (hooks fire before any feature name exists — the v2.2 chicken-and-egg fix).
. Local polish: git.enabled: false (proven workspace-settable from VS Code source: "scope": "resource"), guardrail-file protection globs (false = ask, not block), enterprise policies (ChatToolsAutoApprove — identifier verified on the VS Code security page).

All of it is accident-prevention and audit ergonomics. None of it is the guarantee — the Read role is.

Validation: 12 tests
The critical ones: #1 git push must 403 in every form (normal, --no-verify, explicit URL) — the test that must never fail; #6 doc-generation fidelity (every claim maps to a diff hunk, form ID cited correctly, human-reviewed); #7 patch must include a newly created file (regression guard for the untracked-file bug); #8 hook-timeout behavior (undocumented — empirical); #11 repo history contains only developer-authored commits.


## Where her design ideas live, and how each is captured
Source of ideas	What it contains	Captured how	Manual?
1. The code she produced	The design as built — JSX/HTML/CSS literally is the layout, colors, structure	git add -N . + git diff origin/main, then LLM narrates	No — automatic at /document-changes
2. Her chat prompts to Copilot	Her ideas verbatim, in her own words ("make the header blue, move the search box up…")	UserPromptSubmit hook logs each prompt to ideas.jsonl	No — fully automatic, deterministic
3. Her intent summary	One sentence: why this session, which intake form	She types it when invoking /document-changes	Yes — one sentence, deliberately
Proof for #2 (just verified, this fetch): the VS Code hooks page lists eight lifecycle events, including UserPromptSubmit — "User submits a prompt — Audit user requests, inject system context." The hook's documented input fields include prompt (named explicitly in the docs: "Prefer the documented hook input fields (tool_name, tool_input, prompt, and so on)"). So a five-line hook script can append every prompt she types to a JSONL file — her design thinking captured in her own words, no AI, no clicks, guaranteed ("hooks execute your code at specific lifecycle points with guaranteed outcomes").

Even in the minimal pilot without hooks, there's a documented fallback: when she runs /document-changes in the same chat session where she did the work, her prior prompts are already in the model's context — prompt files run in the current session (documented invocation behavior on the prompt files page). Weaker: lost if she opens a new session or context gets compacted. The hook makes it durable.

Why #3 stays manual — this is a feature, not a gap: ideas #1 and #2 are evidence of intent; neither is a statement of it. The diff shows what, the prompt log shows fragments of thinking mid-flight, but only she can authoritatively state "this session was about X for intake form Y." One typed sentence is the cheapest possible act that makes her the author of the "why" — the alternative is the LLM synthesizing intent, which is fabrication with her name on it.


## Q1 + Q6: WHERE do you get her design ideas?
Three physical locations, in order of rawness:

Location on disk	What's in it	Available when
docs/agent/sessions/_capture/<date>/ideas.jsonl (her machine)	Her prompts verbatim, timestamped — the raw ideas	The moment she hits Enter on each prompt
docs/agent/sessions/_capture/<date>/session-diff.patch (her machine)	The design as built (all code changes, incl. new files)	The moment each agent session ends
docs/agent/sessions/<date>-<feature>/ → plan.md, requirements.md, changelog.md	The narrated design: hunk + her quoted words + her stated goal	Only after she runs /document-changes (once per session)
You (or developers) physically receive them in the handoff zip (changes.patch + the session folder), or — at scale — as the GitHub issue attachment that the server-side Action turns into a draft PR. If her machine/folder is on a shared drive, you can read _capture/ at any moment; it is plain text.

## Q2: HOW are the ideas gotten?
Two mechanisms, strictly separated:

Capture — no LLM involved at all. UserPromptSubmit and Stop hooks run plain PowerShell scripts that write local files. Nothing is "sent" anywhere; bytes go to disk. Proof: hooks "execute your code at specific lifecycle points" and hand the script the documented prompt input field on stdin (hooks docs, fetched 2026-08-09). A shell script cannot call an LLM by itself — that's why this part is deterministic.
Narration — LLM involved at exactly one point. When she types /document-changes, the Copilot agent reads ideas.jsonl + the diff and the model writes the narrative docs.

## Q3: Did you send the code change and her prompt to an LLM?
Yes — at exactly one deliberate point, and one unavoidable background fact. Both stated honestly:

Deliberate: at /document-changes, the diff + ideas.jsonl + her typed goal are placed into the Copilot chat context — i.e., sent to the Copilot service — so the model can narrate. That is the entire purpose of the step.
Unavoidable background fact: her prompts and relevant code already go to the Copilot service during normal editing — that is how Copilot works at all. The capture pipeline adds no new data exposure; it only writes to local disk a copy of what she typed. Data handling is governed by your organization's GitHub Copilot policies — an organizational fact I can't verify from here.


Q4: WHICH LLM?
Whatever model is selected in her VS Code Copilot model picker — unless we pin it. Proof, verbatim from the prompt files docs (fetched this session): the prompt-file frontmatter has a model field — "The language model used when running the prompt. If not specified, the currently selected model in model picker is used." So document-changes.prompt.md can pin a specific model for consistent output. I will not name a specific model as "the" answer — which models are available depends on her Copilot plan and org policy, which I cannot verify. It runs through her existing Copilot subscription: no separate API key, no custom endpoint, no infrastructure.

## Q5: HOW OFTEN?
Data flow	Frequency

## Prompt → ideas.jsonl (disk, no LLM)	Every prompt, real time
## Diff → session-diff.patch (disk, no LLM)	Every session end
## Diff + prompts → LLM for narration	Once per session, only when she runs /document-changes — never continuous, never per-save, no background LLM calls
The "never in the background" claim has documented proof: prompt files are manually invoked ("Unlike custom instructions that are applied automatically, you invoke prompt files manually in chat"), and hooks run shell commands, not model calls. There is no documented zero-click LLM path in VS Code chat — I won't invent one.

Adding the model-pinning fact to the capture plan, since it answers "which LLM" permanently:



Self-criticism — the biggest finding is a bug in my own documented code
The scripts I wrote in the capture plan contained a real defect that only execution could catch: they used PowerShell > redirection to write the patch file. On Windows PowerShell 5.1, > writes UTF-16LE, and git apply rejects such patches. This is not speculation — I proved it:

Redirect-produced patch, first bytes: 255,254,100,0 (UTF-16LE BOM)
git diff --output= patch, first bytes: 100,105,102,102 (ASCII diff)
git apply on the corrupt patch: error: No valid patches in input, exit 128
The capture plan's own self-criticism said "the scripts are untested code until the pilot runs" — that caution was warranted, and the fix (--output=) is now in both the scaffolded scripts and the doc (Design_Capture_Plan_from_copilot.md §2, §8).

What was executed and passed (proof = actual terminal output, quoted in §8)
Real repos created in the workspace: pilot (her clone), pilot-origin.git (bare origin with pushed main baseline, 9 files), dev-clone (developer side). Simulated session: header color edit + a newly created search-box.html.

Test	Result
T1a negative control: bare git diff shows only M index.html — new file invisible	✅ v2.2 untracked-file fix validated against a real bug
T1b: capture-prompt.ps1 with documented stdin JSON → both prompts verbatim in ideas.jsonl	✅
T2: capture-session.ps1 → patch includes the new file, excludes docs/agent	✅
T3: handoff.ps1 → patch + zip	✅
T4: fresh clone of origin + git apply handoff patch → exit 0, new file exists, header hunk present	✅ end-to-end
T4's first run failed, which produced two more honest lessons (both in §8): bare-repo HEAD defaults to master (harness-only issue), and git add -N . swept a stray temp file into the patch — a real workflow lesson: the developer review must check the patch's file list.

What was NOT executed — no fabrication
Hook firing tests (A/B/D) and the /document-changes narration test (C) require a live VS Code agent session with pilot opened as the workspace root — hooks don't fire from a headless terminal. The script bodies are proven; whether VS Code invokes them at the documented moments remains the human-pilot step. Both docs state this explicitly.

To run the remaining tests: open pilot as the workspace root in VS Code, type a prompt in agent chat, and check whether 

## docs/agent/sessions/_capture/<today>/ideas.jsonl appears.

docs/agent/sessions/_capture/<today>/ideas.jsonl appears.