"""
Minimal Working 5-Layer Example
===============================

This version focuses on demonstrating the architecture without 
requiring the latest LangGraph features.
"""

from typing import Dict, Any, Callable, List, TypedDict
from dataclasses import dataclass

# ============================================================================
# SIMPLIFIED LANGGRAPH-STYLE COMPONENTS (For demo purposes)
# ============================================================================

@dataclass
class Message:
    content: str
    type: str = "ai"

class SimpleState(TypedDict):
    """Simplified state for demonstration"""
    messages: List[Message]
    document_content: str
    is_valid: bool
    extracted_text: str
    summary: str

class SimpleStateGraph:
    """Simplified version of StateGraph for demonstration"""
    
    def __init__(self, state_schema):
        self.state_schema = state_schema
        self.nodes = {}
        self.edges = []
        self.compiled = False
    
    def add_node(self, node_id: str, node_func: Callable):
        self.nodes[node_id] = node_func
    
    def add_edge(self, from_node: str, to_node: str):
        self.edges.append((from_node, to_node))
    
    def compile(self):
        self.compiled = True
        return self
    
    def invoke(self, initial_state: Dict) -> Dict:
        """Simple execution - runs nodes in order"""
        current_state = dict(initial_state)
        
        # Simple execution: run nodes in the order they were added
        for node_id, node_func in self.nodes.items():
            print(f"Executing node: {node_id}")
            try:
                updates = node_func(current_state)
                if updates:
                    current_state.update(updates)
            except Exception as e:
                print(f"Error in node {node_id}: {e}")
        
        return current_state

class SimpleToolNode:
    """Simplified ToolNode for demonstration"""
    
    def __init__(self, tools: List[Callable]):
        self.tools = tools
    
    def __call__(self, state: Dict) -> Dict:
        """Execute tools and return results"""
        results = []
        for tool in self.tools:
            try:
                result = tool("dummy_input")  # Simplified tool execution
                results.append(result)
            except Exception as e:
                results.append(f"Tool error: {e}")
        
        # Add results to messages
        message = Message(content=f"Tool execution complete: {'; '.join(results)}")
        return {"messages": state.get("messages", []) + [message]}

# ============================================================================
# LAYER 1: YAML CONFIGURATION
# ============================================================================

WORKFLOW_CONFIG = {
    "workflow": {
        "name": "document_processing",
        "state_schema": "SimpleState"
    },
    "nodes": [
        {
            "id": "validate_document",
            "component_type": "function",
            "function_ref": "docprocessing.validation.validate_document"
        },
        {
            "id": "extract_content", 
            "component_type": "tool_node",
            "tools": ["docprocessing.tools.text_extractor"]
        },
        {
            "id": "summarize_document",
            "component_type": "function", 
            "function_ref": "docprocessing.summarization.summarize_content"
        }
    ],
    "edges": [
        {"from": "START", "to": "validate_document"},
        {"from": "validate_document", "to": "extract_content"},
        {"from": "extract_content", "to": "summarize_document"},
        {"from": "summarize_document", "to": "END"}
    ]
}

# ============================================================================
# LAYER 2: PATTERN MAPPER
# ============================================================================

class SimpleComponentMapper:
    """Maps configuration to simplified components"""
    
    def __init__(self, function_registry, tool_registry):
        self.function_registry = function_registry
        self.tool_registry = tool_registry
    
    def build_component(self, component_type: str, config: Dict[str, Any]):
        """Convert config into actual component"""
        
        if component_type == "function":
            function_ref = config["function_ref"]
            actual_function = self.function_registry.get(function_ref)
            return actual_function
            
        elif component_type == "tool_node":
            tool_refs = config["tools"]
            actual_tools = [self.tool_registry.get(ref) for ref in tool_refs]
            return SimpleToolNode(actual_tools)
            
        else:
            raise ValueError(f"Unknown component type: {component_type}")

# ============================================================================
# LAYER 3: GRAPH BUILDER
# ============================================================================

class SimpleGraphBuilder:
    """Builds simplified StateGraph from configuration"""
    
    def __init__(self):
        self.function_registry = SimpleFunctionRegistry()
        self.tool_registry = SimpleToolRegistry()
        self.mapper = SimpleComponentMapper(
            self.function_registry, 
            self.tool_registry
        )
    
    def build_graph(self, config: Dict[str, Any]) -> SimpleStateGraph:
        """Create executable graph"""
        
        # Create graph with state schema
        graph = SimpleStateGraph(SimpleState)
        
        # Add nodes
        for node_config in config["nodes"]:
            node_id = node_config["id"]
            component_type = node_config["component_type"]
            
            actual_component = self.mapper.build_component(component_type, node_config)
            graph.add_node(node_id, actual_component)
        
        # Add edges (simplified)
        for edge_config in config["edges"]:
            if edge_config["from"] != "START" and edge_config["to"] != "END":
                graph.add_edge(edge_config["from"], edge_config["to"])
        
        return graph.compile()

# ============================================================================
# LAYER 4: REGISTRIES
# ============================================================================

def validate_document(state: Dict) -> Dict:
    """Validate document format and content"""
    content = state.get("document_content", "")
    is_valid = len(content) > 10 and content.strip() != ""
    
    message = Message(content=f"Document validation: {'PASSED' if is_valid else 'FAILED'}")
    
    return {
        "messages": state.get("messages", []) + [message],
        "is_valid": is_valid
    }

def summarize_content(state: Dict) -> Dict:
    """Summarize extracted document content"""
    extracted_text = state.get("extracted_text", "")
    words = extracted_text.split()
    summary = f"Document contains {len(words)} words. Key content: {' '.join(words[:5])}"
    
    message = Message(content=f"Summary: {summary}")
    
    return {
        "messages": state.get("messages", []) + [message],
        "summary": summary
    }

def text_extractor(document_path: str) -> str:
    """Extract text from document"""
    return "This is extracted text from the document with important business information."

class SimpleFunctionRegistry:
    """Store and retrieve business functions"""
    
    def __init__(self):
        self._functions = {
            "docprocessing.validation.validate_document": validate_document,
            "docprocessing.summarization.summarize_content": summarize_content,
        }
    
    def get(self, function_ref: str) -> Callable:
        return self._functions[function_ref]

class SimpleToolRegistry:
    """Store and retrieve tools"""
    
    def __init__(self):
        self._tools = {
            "docprocessing.tools.text_extractor": text_extractor,
        }
    
    def get(self, tool_ref: str):
        return self._tools[tool_ref]

# ============================================================================
# LAYER 5: EXECUTION ENGINE
# ============================================================================

class SimpleWorkflowExecutor:
    """Execute workflows"""
    
    def __init__(self):
        self.builder = SimpleGraphBuilder()
        self._compiled_workflows = {}
    
    def execute_workflow(self, config: Dict[str, Any], initial_state: Dict[str, Any]) -> Dict[str, Any]:
        """Execute workflow with real data"""
        
        workflow_name = config["workflow"]["name"]
        
        if workflow_name not in self._compiled_workflows:
            self._compiled_workflows[workflow_name] = self.builder.build_graph(config)
        
        workflow = self._compiled_workflows[workflow_name]
        
        # Execute the workflow
        result = workflow.invoke(initial_state)
        
        return result

# ============================================================================
# DEMONSTRATION
# ============================================================================

def demonstrate_5_layers():
    """Show how all 5 layers work together"""
    
    print("=== 5-Layer Architecture Demonstration ===\n")
    
    print("Layer 1: YAML Configuration")
    print("✓ Business-friendly workflow definition")
    print("✓ No technical knowledge required\n")
    
    print("Layer 2: Component Mapper") 
    print("✓ Maps config to actual components")
    print("✓ Handles function and tool resolution\n")
    
    print("Layer 3: Graph Builder")
    print("✓ Creates executable workflow")
    print("✓ Assembles nodes and edges\n")
    
    print("Layer 4: Function Registry")
    print("✓ Provides business logic functions")
    print("✓ Manages tool and schema references\n")
    
    print("Layer 5: Execution Engine")
    print("✓ Runs workflow with real data")
    print("✓ Manages state and flow control\n")
    
    print("=" * 50)
    print("EXECUTING WORKFLOW")
    print("=" * 50)
    
    # Create executor
    executor = SimpleWorkflowExecutor()
    
    # Prepare initial state
    initial_state = {
        "document_content": "This is a sample business document with important contract information that needs processing.",
        "messages": [Message(content="Starting document processing", type="user")],
        "is_valid": False,
        "extracted_text": "",
        "summary": ""
    }
    
    print(f"Input document: {len(initial_state['document_content'])} characters")
    
    # Execute workflow
    result = executor.execute_workflow(WORKFLOW_CONFIG, initial_state)
    
    print(f"\nResults:")
    print(f"✓ Document valid: {result.get('is_valid', False)}")
    print(f"✓ Summary: {result.get('summary', 'Not generated')}")
    print(f"✓ Messages processed: {len(result.get('messages', []))}")
    
    print(f"\nWorkflow execution trace:")
    for i, msg in enumerate(result.get('messages', []), 1):
        print(f"  {i}. {msg.content}")
    
    print("\n" + "=" * 50)
    print("ARCHITECTURE BENEFITS:")
    print("• Business users only see Layer 1 (YAML)")
    print("• Each layer has single responsibility") 
    print("• Clean separation enables easy changes")
    print("• Can swap to real LangGraph components easily")
    print("• Scalable and maintainable design")

if __name__ == "__main__":
    demonstrate_5_layers()