# 03_human_in_the_loop_command.py
"""
Version-agnostic Command approach for HITL
"""
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver
import pdb

# Try to import Command from various locations
Command = None
try:
    from langgraph.graph import Command
    print("Imported Command from langgraph.graph")
except ImportError:
    try:
        from langgraph.types import Command
        print("Imported Command from langgraph.types")
    except ImportError:
        try:
            from langgraph import Command
            print("Imported Command from langgraph")
        except ImportError:
            print("Command not available in this LangGraph version")
            print("Using interrupt-based approach instead")

class State(TypedDict, total=False):
    draft: str
    approved: bool
    response: str

def draft_email(state: State) -> State:
    draft = "Dear customer, this is an auto-generated email draft. Please approve."
    print("[draft_email] Draft created.")
    return {"draft": draft}

def need_approval(state: State):
    print("[need_approval] Waiting for human approval...")
    if Command:
        # Use Command if available
        return Command(resume={"expected": "approved"})
    else:
        # Fallback: use NodeInterrupt
        from langgraph.errors import NodeInterrupt
        raise NodeInterrupt("Waiting for approval of draft email")

def send_email(state: State) -> State:
    approved = state.get("approved", False)
    if not approved:
        print("[send_email] Not approved. Aborting send.")
        return {"response": "Not approved. Aborting send."}
    print("[send_email] Sent!")
    return {"response": "Email sent successfully!"}

def main():
    memory = MemorySaver()
    g = StateGraph(State)
    g.add_node("draft_email", draft_email)
    g.add_node("need_approval", need_approval)
    g.add_node("send_email", send_email)

    g.add_edge(START, "draft_email")
    g.add_edge("draft_email", "need_approval")
    g.add_edge("need_approval", "send_email")
    g.add_edge("send_email", END)

    # Compile with appropriate settings
    if Command:
        app = g.compile(checkpointer=memory)
    else:
        # If no Command, use interrupt_before as fallback
        app = g.compile(checkpointer=memory, interrupt_before=["send_email"])

    config = {"configurable": {"thread_id": "demo-hitl"}}

    print("=" * 60)
    print("HUMAN-IN-THE-LOOP EMAIL APPROVAL DEMO")
    print("=" * 60)

    print("\nStep 1: Starting workflow...")
    try:
        result = app.invoke({}, config=config)
        print("Unexpected: Workflow completed without interruption")
        print("Result:", result)
    except Exception as e:
        print(f"Workflow paused as expected: {e}")
    pdb.set_trace()

    print("\nStep 2: Checking current state...")
    current_state = app.get_state(config)
    print("Current state:", current_state.values)
    if hasattr(current_state, 'next') and current_state.next:
        print("Next node(s):", current_state.next)
    pdb.set_trace()


    print("\nStep 3: Approving and resuming...")
    result = app.invoke({"approved": True}, config=config)
    print("Final result:", result)
    pdb.set_trace()

    # Test rejection scenario
    print("\n" + "=" * 60)
    print("TESTING REJECTION SCENARIO")
    print("=" * 60)
    
    config_reject = {"configurable": {"thread_id": "demo-hitl-reject"}}
    
    print("\nCreating new draft...")
    try:
        app.invoke({}, config=config_reject)
    except:
        pass  # Expected interruption
    pdb.set_trace()
    
    print("\nRejecting draft...")
    result_reject = app.invoke({"approved": False}, config=config_reject)
    print("Rejection result:", result_reject)
    pdb.set_trace()

if __name__ == "__main__":
    main()